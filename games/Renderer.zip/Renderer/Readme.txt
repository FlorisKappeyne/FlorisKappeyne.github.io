Renderer readme

This renderer is a hobby project of mine, edited to be eligable as code sample for my internship application at Guerrilla Games.
It is a path tracer that contains:
 - physically based rendering using monte carlo integration to estimate the rendering equation
 - three shading models, two of which are difficult to do using traditional rendering methods (rasterization0
   these are:
	- diffuse (light is scattered in all directions)
	- mirror/specular (light is reflected in a single direction)
	- transparent (light is either refracted (using Snell's Law) or reflected, based on Fresnel's Law
 - An acceleration structure (BVH optimized with SAH) to improve scalability)
 - Multithreading, implemented using std::thread, hidden in a behind a single function (ParallelForLoop)
 - Custom math classes (3D and 2D vector, 4 by 4 matrix)
 - several debugging utilities (timer, data tracker and logging, several special debug tracers)
 - an input file that gives the user control over what the renderer renders

I output graphics and handle input using a framework made by a youtuber, ChiliTomatoNoodle. I learned the basics of C++ from him.



The program works as follows:

The program loads and parses parameters.json. Based on that information it loads a scene, builds the BVH and starts rendering. When 
enough samples per pixel have been rendered, the resulting image is printed to a png file. When rendering, the program first generates samples.
These samples are then passed to the correct Tracer, which turns them into Rays using the camera. These rays are then do intersection tests with
the scene, and shaded based on the information that is returned.



How to use:

When debugging is true (set it to true in Data/parameters.json), you will have access to the following key commands:
When debugging, I recommend setting the spp to 1 and setting show_per_line and quit_when_done to false.
A lower resolution also helps to speed up the program.

 Movement:
   WASD -> rotate camera
   Arrows -> move camera
   R -> move camera up
   F -> move camera down

 Debugging options:
   J -> cycle through renderers
   I -> toggle drawing full frame or per tile
   T -> toggle display tracking
   left mouse click + hold + dragging -> only render selected portion
   right mouse click -> render full screen (resets screen selection rendering)




Important files:
The 10 most important files for you to look at (they show off the structure, complexity, Efficiency and Coding style/standards)
Files can be found in Renderer/Engine/Source/Tracer
1.  Tracers/PathTracer.cpp and .h
2.  Tracers/ITracer.h
3.  Utilities/Math/Vec3.h
4.  Utilities/Misc/Distribution1D.cpp and .h 
5.  Utilities/Misc/RNG.h 
6.  SceneTraversal/Transform.cpp and .h
7.  SceneTraversal/Ray.h
8.  SceneTraversal/BVH/BVH.h and .cpp
9.  SceneTraversal/Primitives/Triangle.h and .cpp
10. Shading/Materials/TransparentMaterial.h and .cpp

I believe the best way to understand how everything works is to follow the program's flow. It starts in Game.cpp, where it
constructs everything in the constructor. In the Load function the factory does its work, in SetUp() the BVH is build.
Next, Render() is called every frame, followed by Draw(). Draw() draws the rendered image to the screen, but Render is
interesting: it creates a SampleBuffer which is then passed to the renderer, which it renders and outputs to the film.

If you have any questions, please don't hesitate to ask. My email is floris.kappeyne@gmail.com.