/******************************************************************************************
*	Chili DirectX Framework Version 16.07.20											  *
*	Colors.h																			  *
*	Copyright 2016 PlanetChili <http://www.planetchili.net>								  *
*																						  *
*	This file is part of The Chili DirectX Framework.									  *
*																						  *
*	The Chili DirectX Framework is free software: you can redistribute it and/or modify	  *
*	it under the terms of the GNU General Public License as published by				  *
*	the Free Software Foundation, either version 3 of the License, or					  *
*	(at your option) any later version.													  *
*																						  *
*	The Chili DirectX Framework is distributed in the hope that it will be useful,		  *
*	but WITHOUT ANY WARRANTY; without even the implied warranty of						  *
*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the						  *
*	GNU General Public License for more details.										  *
*																						  *
*	You should have received a copy of the GNU General Public License					  *
*	along with The Chili DirectX Framework.  If not, see <http://www.gnu.org/licenses/>.  *
******************************************************************************************/
#pragma once
#include "Typedefs.h"
#include "Utilities/MathUtilities.h"

class ARGBc
{
public:
	uint32 dword;
public:
	constexpr ARGBc() : dword() {}
	constexpr ARGBc(const ARGBc& col)
		:
		dword(col.dword)
	{}
	constexpr ARGBc(uint32 dw)
		:
		dword(dw)
	{}
	constexpr ARGBc(unsigned char x, unsigned char r, unsigned char g, unsigned char b)
		:
		dword((x << 24u) | (r << 16u) | (g << 8u) | b)
	{}
	constexpr ARGBc(unsigned char r, unsigned char g, unsigned char b)
		:
		dword((r << 16u) | (g << 8u) | b)
	{}
	constexpr ARGBc(ARGBc col, unsigned char x)
		:
		ARGBc((x << 24u) | col.dword)
	{}
	ARGBc& operator =(ARGBc color)
	{
		dword = color.dword;
		return *this;
	}
	ARGBc operator*(Float value)
	{
		ARGBc res;
		res.SetA((char)((Float)GetA() * value));
		res.SetR((char)((Float)GetR() * value));
		res.SetG((char)((Float)GetG() * value));
		res.SetB((char)((Float)GetB() * value));
		return res;
	}
	ARGBc& operator*=(Float value)
	{
		SetA((char)((Float)GetA() * value));
		SetR((char)((Float)GetR() * value));
		SetG((char)((Float)GetG() * value));
		SetB((char)((Float)GetB() * value));
		return *this;
	}
	ARGBc operator*(ARGBc& rhs)
	{
		ARGBc res;
		Float inv255 = 1.0f / 255.0f;
		res.SetA((char)((((Float)GetA() * inv255) * ((Float)rhs.GetA() * inv255)) * 255.0f));
		res.SetR((char)((((Float)GetR() * inv255) * ((Float)rhs.GetR() * inv255)) * 255.0f));
		res.SetG((char)((((Float)GetG() * inv255) * ((Float)rhs.GetG() * inv255)) * 255.0f));
		res.SetB((char)((((Float)GetB() * inv255) * ((Float)rhs.GetB() * inv255)) * 255.0f));
		return res;
	}
	ARGBc& operator*=(ARGBc& rhs)
	{
		Float inv255 = 1.0f / 255.0f;
		SetA((char)((((Float)GetA() * inv255) * ((Float)rhs.GetA() * inv255)) * 255.0f));
		SetR((char)((((Float)GetR() * inv255) * ((Float)rhs.GetR() * inv255)) * 255.0f));
		SetG((char)((((Float)GetG() * inv255) * ((Float)rhs.GetG() * inv255)) * 255.0f));
		SetB((char)((((Float)GetB() * inv255) * ((Float)rhs.GetB() * inv255)) * 255.0f));
		return *this;
	}
	ARGBc GammaCorrect()
	{
		return ARGBc(
			(unsigned char)(pow((Float((Float)GetR()) / Float(255)), (kOneF / Float(2.2))) * Float(255)),
			(unsigned char)(pow((Float((Float)GetG()) / Float(255)), (kOneF / Float(2.2))) * Float(255)),
			(unsigned char)(pow((Float((Float)GetB()) / Float(255)), (kOneF / Float(2.2))) * Float(255)));
	}
	constexpr unsigned char GetX() const
	{
		return dword >> 24u;
	}
	constexpr unsigned char GetA() const
	{
		return GetX();
	}
	constexpr unsigned char GetR() const
	{
		return (dword >> 16u) & 0xFFu;
	}
	constexpr unsigned char GetG() const
	{
		return (dword >> 8u) & 0xFFu;
	}
	constexpr unsigned char GetB() const
	{
		return dword & 0xFFu;
	}
	void SetX(unsigned char x)
	{
		dword = (dword & 0xFFFFFFu) | (x << 24u);
	}
	void SetA(unsigned char a)
	{
		SetX(a);
	}
	void SetR(unsigned char r)
	{
		dword = (dword & 0xFF00FFFFu) | (r << 16u);
	}
	void SetG(unsigned char g)
	{
		dword = (dword & 0xFFFF00FFu) | (g << 8u);
	}
	void SetB(unsigned char b)
	{
		dword = (dword & 0xFFFFFF00u) | b;
	}
};

namespace ChiliColors
{
  static constexpr ARGBc MakeRGB(unsigned char r, unsigned char g, unsigned char b)
  {
    return (r << 16) | (g << 8) | b;
  }
  static constexpr ARGBc White = MakeRGB(255u, 255u, 255u);
  static constexpr ARGBc Black = MakeRGB(0u, 0u, 0u);
  static constexpr ARGBc Gray = MakeRGB(0x80u, 0x80u, 0x80u);
  static constexpr ARGBc LightGray = MakeRGB(0xD3u, 0xD3u, 0xD3u);
  static constexpr ARGBc Red = MakeRGB(255u, 0u, 0u);
  static constexpr ARGBc Green = MakeRGB(0u, 255u, 0u);
  static constexpr ARGBc Blue = MakeRGB(0u, 0u, 255u);
  static constexpr ARGBc Yellow = MakeRGB(255u, 255u, 0u);
  static constexpr ARGBc Cyan = MakeRGB(0u, 255u, 255u);
  static constexpr ARGBc Magenta = MakeRGB(255u, 0u, 255u);
}
