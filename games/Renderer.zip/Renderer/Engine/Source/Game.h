/******************************************************************************************
 *	Chili DirectX Framework Version 16.07.20											  *
 *	Game.h																				  *
 *	Copyright 2016 PlanetChili.net <http://www.planetchili.net>							  *
 *																						  *
 *	This file is part of The Chili DirectX Framework.									  *
 *																						  *
 *	The Chili DirectX Framework is free software: you can redistribute it and/or modify	  *
 *	it under the terms of the GNU General Public License as published by				  *
 *	the Free Software Foundation, either version 3 of the License, or					  *
 *	(at your option) any later version.													  *
 *																						  *
 *	The Chili DirectX Framework is distributed in the hope that it will be useful,		  *
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of						  *
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the						  *
 *	GNU General Public License for more details.										  *
 *																						  *
 *	You should have received a copy of the GNU General Public License					  *
 *	along with The Chili DirectX Framework.  If not, see <http://www.gnu.org/licenses/>.  *
 ******************************************************************************************/
#pragma once

// chili
#include "Keyboard.h"
#include "Mouse.h"
#include "Graphics.h"

// scene rep
#include "SceneTraversal/Scene.h"
#include "Cameras/Camera.h"
#include "Screen/Screen.h"
#include "Screen/Film.h"

 // renderers
#include "Tracers/PathTracer.h"
#include "Tracers/RayTracer.h"
#include "Tracers/DebugTracerNormals.h"
#include "Tracers/DebugTracerBVHDepth.h"

// samplers
#include "Samplers/StratisfiedSampler.h"
#include "Samplers/JitteredSampler.h"

// utilities
#include "Utilities/Misc/DataTracker.h"
#include "Utilities/Math/Vec2.h"

class ITracer;
class ISampler;
class IMaterial;
class Film;
class Transform;
class Parameters;

/*
* Game
*
*   A class that handles input and makes sure that every object is
*   initialized, updated and destroyed properly
*
*   it holds a Screen, Camera, Film, Scene, Sampler and Renderer objects
*
*   It's named game because the framework I'm using was made
*     for (small) games
*/

class Game
{
public:
  Game(class MainWindow& wnd, Parameters& params);
  Game(const Game&) = delete;
  Game& operator=(const Game&) = delete;
  ~Game();
  void Go();
  bool Done()
  {
    return is_done_;
  }

private:
  //chili
  void ComposeFrame();
  void UpdateModel();

  // loads all assets according to input file
  void Load();
  // sets up the system to be render ready (accelerate)
  void SetUp();

  // handle input
  void HandleInput();
  // render a frame
  void Render();
  // draw total render to screen_
  void Draw();

private:
  // chili
  MainWindow & wnd;
  Graphics gfx;

  // execution flow
  bool is_done_;

  // render parameters
  Parameters& params_;

  // scene rep variables
  Screen screen_;
  Camera camera_;
  Film film_;
  Scene scene_;

  //input variables
  static constexpr int32 NUM_INPUT_BOOLS = 255;
  bool input_bools_[NUM_INPUT_BOOLS];
  bool left_mouse_click_;
  bool right_mouse_click_;

  // debug data tracking
  DataTracker tracker;
  bool display_tracking_;

  // rendering info
  bool draw_full_frame_;
  bool rendering_section_;
  Vec2I section_start_;
  Vec2I section_cur_;

  // renderers
  ITracer* renderer_; // current renderer
  ITracer* renderers_[ITracer::TracerType::SUM]; // handles to all renderers
  PathTracer path_tracer_;
  RayTracer ray_tracer_;
  DebugTracerNormals normals_tracer_;
  DebugTracerBVHDepth bvh_depth_tracer_;

  // samplers
  ISampler* multidepth_sampler_;
  StratisfiedSampler strat_sampler_;
  JitteredSampler jitt_sampler_;
};
