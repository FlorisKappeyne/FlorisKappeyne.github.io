#pragma once
#include "ITracer.h"

struct SampleBuffer;

/*
* IRayTracer - base class for single sample renders
*   child of the ITracer class
* 
* it serves as an abstraction layer for all renderers
*   that only require one sample per pixel, which
*   now only need to implement the constructor and TraceRay
*/

class IRayTracer : public ITracer
{
public:
  IRayTracer(const Screen& screen, Film* film, TracerType type);
  ~IRayTracer() override;

private:
  // these functions render the given sample buffer
  void ProcessSampleBufferMultithreaded(const SampleBuffer& sample_buff,
    const Scene& scene, const Camera& cam) override;
  void ProcessSampleBufferSinglethreaded(const SampleBuffer& sample_buff,
    const Scene& scene, const Camera& cam) override;

protected:
  // traces a single ray, returns the calculated color
  virtual RGBf TraceRay(Ray& ray, const Scene& scene, uint32 a_depth) = 0;
};
