#include "IRayTracer.h"
#include "Samplers/ISampler.h"
#include "Samplers/Data/SampleBuffer.h"
#include "Cameras/Camera.h"
#include "Screen/Screen.h"
#include "Screen/Film.h"
#include "Shading/rgbf.h"
#include "Utilities/Misc/RNG.h"
#include "Utilities/Misc/ParallelForLoop.h"
#include "Samplers/StratisfiedSampler.h"
#include "SceneTraversal/Ray.h"


///////////////////////////////////////////////////////////////////////////////
// class functions

IRayTracer::IRayTracer(const Screen& screen, Film * film, TracerType type)
  :
  ITracer(screen, film, type)
{
}

IRayTracer::~IRayTracer()
{
}


///////////////////////////////////////////////////////////////////////////////
// render functions

void IRayTracer::ProcessSampleBufferMultithreaded(const SampleBuffer & sample_buff, 
  const Scene& scene, const Camera& cam)
{
  // trace all rays multithreaded
  std::function<void(int32)> func = [&](int32 i)
  {
    for (uint32 j = sample_buff.sample_chunks[i].start;
      j < sample_buff.sample_chunks[i].end; ++j)
    {
      Sample& s = sample_buff.samples[j];
      Ray r = cam.GenerateRay(s);
      RGBf c = TraceRay(r, scene, 0u);
      film_->OverwritePixel(s, c);
    }
  };
  ParallelFor(func, sample_buff.num_chunks, 1); // 1 chunk per thread
}

void IRayTracer::ProcessSampleBufferSinglethreaded(const SampleBuffer & sample_buff,
  const Scene& scene, const Camera&  cam)
{
  // trace all rays
  for (uint32 i = 0; i < sample_buff.num_samples; ++i)
  {
    Sample& s = sample_buff.samples[i];
    Ray r = cam.GenerateRay(s);
    RGBf c = TraceRay(r, scene, 0u);
    film_->OverwritePixel(s, c);
  }
}
