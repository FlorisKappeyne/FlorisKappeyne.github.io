#include "ITracer.h"
#include "Screen/Screen.h"
#include "SceneTraversal/Scene.h"
#include "Cameras/Camera.h"
#include "Samplers/ISampler.h"
#include "Samplers/JitteredSampler.h"
#include "Samplers/Data/SampleBuffer.h"


///////////////////////////////////////////////////////////////////////////////
// Class functions

ITracer::ITracer(const Screen& screen, Film* film, TracerType type, bool is_single_depth)
  :
  scr_(screen),
  film_(film),
  type_(type), 
  is_single_depth_(is_single_depth)
{
}

ITracer::~ITracer()
{
}


///////////////////////////////////////////////////////////////////////////////
// render type management function

ITracer::TracerType ITracer::GetType()
{
  return type_;
}

bool ITracer::GetIsSingleDepth()
{
  return is_single_depth_;
}


///////////////////////////////////////////////////////////////////////////////
// the render function that renders a given batch of samples

void ITracer::RenderSampleBuffer(const Scene & scene, const Camera & cam, SampleBuffer & buff)
{
  // process the sample buffer with multiple threads or just one
  if (USE_MULTITHREADING)
  {
    ProcessSampleBufferMultithreaded(buff, scene, cam);
  }
  else
  {
    ProcessSampleBufferSinglethreaded(buff, scene, cam);
  }

  // delete the allocated memory
  buff.Clear();
}
