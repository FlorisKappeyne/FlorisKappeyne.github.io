#pragma once
#include "ITracer.h"

struct SampleBuffer;

/**
* PathTracer - child of ITracer
*   a multi sample renderer that implements monte carlo integration
*
* uses multiple samples per pixel to create an accurate representation of global
* illumination in the scene
*  
* This renderer uses monte carlo integration, and some techniques
*   to speed it up such as russian roulette and Next Event Estimation
*/
class PathTracer : public ITracer
{
public:
  PathTracer(const Screen& screen, Film* film)
    :
    ITracer(screen, film, TracerType::PT, false)
  {
  }
  ~PathTracer() override
  {
  }

private:
  // render functions
  void ProcessSampleBufferMultithreaded(const SampleBuffer& sample_buff,
    const Scene& scene, const Camera& cam) override;
  void ProcessSampleBufferSinglethreaded(const SampleBuffer& sample_buff,
    const Scene& scene, const Camera& cam) override;

  // traces a single ray and returns the color
  RGBf TraceRay(Ray& ray, const Scene& scene, uint32 depth) override;

private:
  static constexpr bool kUseNEE = false; // use next event estimation or not
  static constexpr bool kUseRR = true; // use russian roulette
  static constexpr uint32 kMinDepth = 4;
  static constexpr uint32 kSamples = 4;
};