#include "RayTracer.h"
#include "SceneTraversal/Ray.h"
#include "SceneTraversal/Intersection.h"
#include "SceneTraversal/Primitives/Primitive.h"
#include "Shading/Materials/IMaterial.h"


///////////////////////////////////////////////////////////////////////////////
// class functions

RayTracer::RayTracer(const Screen& screen, Film* film)
    :
    IRayTracer(screen, film, TracerType::RT)
{}

RayTracer::~RayTracer()
{
}

///////////////////////////////////////////////////////////////////////////////
// Trace Ray function

RGBf RayTracer::TraceRay(Ray& ray, const Scene& scene, uint32 a_depth)
{
    Intersection hit;
    // if the ray hit nothing, return black
    if (scene.IntersectScene(ray, hit) == false)
    {
        return Colors::Black;
    }
    // return this surface's color
    Ray ray_out;
    Float pdf;
    RGBf le, lm;
    hit.prim->mat_->EvaluateMaterial(hit, ray_out, &ray_out, &pdf, &le, &lm);
    return lm;
}
