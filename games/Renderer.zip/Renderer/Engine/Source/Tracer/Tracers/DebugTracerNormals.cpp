#include "DebugTracerNormals.h"
#include "SceneTraversal/Intersection.h"
#include "Shading/rgbf.h"


///////////////////////////////////////////////////////////////////////////////
// class functions

DebugTracerNormals::DebugTracerNormals(const Screen& screen, Film* film)
    :
    IRayTracer(screen, film, TracerType::DN)
{}

DebugTracerNormals::~DebugTracerNormals()
{
}

///////////////////////////////////////////////////////////////////////////////
// TraceRay function

RGBf DebugTracerNormals::TraceRay(Ray& ray, const Scene&scene, uint32 a_depth)
{
    // if the ray hit nothing, return black
    Intersection hit;
    if (scene.IntersectScene(ray, hit) == false)
    {
        return Colors::Black;
    }

    // return the total color
    Vec3 normCol = (hit.n + Vec3(kOneF)) * kHalfF;
    return RGBf(normCol.x, normCol.y, normCol.z);
}