#pragma once
#include "SceneTraversal/Scene.h"
#include "Utilities/Math/Vec2.h"

#ifdef _DEBUG
static constexpr bool USE_MULTITHREADING = true;
#else
static constexpr bool USE_MULTITHREADING = true;
#endif

class Camera;
class ISampler;
class Film;
class RGBf;
struct Screen;
struct SampleBuffer;

/*
* ITracer - base class for all renderers
*
*  The ITracer class is the interface of all renderers,
*     and also defines some functions that are the same for each renderer
*
*   usage: Create a renderer using it's constructor. Now, you can:
*     - change what sampler you want to use by calling SetSampler()
*     - see what type this renderer is by calling GetType()
*     - Render a buffer of samples, outputting them to the given Film
*/

class ITracer
{
public:
  enum TracerType : uint32
  {
    RT, // Ray Tracer
    PT, // Path Tracer
    DN, // Debug Normals
    DD, // Debug (BVH) Depth
    SUM // total number of types
  };

public:
  ITracer(const Screen& screen, Film* film, TracerType type, bool is_single_depth = true);
  virtual ~ITracer();

  // render type management functions
  TracerType GetType();
  bool GetIsSingleDepth();

  // render function
  void RenderSampleBuffer(const Scene& scene, const Camera& cam, SampleBuffer& buff);

protected:
  // processes the given samplebuffer. will be implemented by child renderers
  virtual void ProcessSampleBufferMultithreaded(const SampleBuffer& sample_buff,
    const Scene& scene, const Camera& cam) = 0;
  virtual void ProcessSampleBufferSinglethreaded(const SampleBuffer& sample_buff,
    const Scene& scene, const Camera& cam) = 0;

  // Trace a single ray, returns a color. Will be implemented by child renderers
  virtual RGBf TraceRay(Ray& ray, const Scene& scene, uint32 a_depth) = 0;

protected:
  // handles to external objects for easy referencing
  const Screen& scr_;
  Film* film_;

  // this renderer's type_ to distinguish children
  TracerType type_;
  bool is_single_depth_;
};
