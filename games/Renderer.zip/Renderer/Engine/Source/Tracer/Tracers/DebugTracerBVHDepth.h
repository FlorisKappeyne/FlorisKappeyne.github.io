#pragma once
#include "IRayTracer.h"

struct SampleBuffer;

/*
* DebugTracerBVHDepth - child of IRaytracer
*
* this class implements the TraceRay function to return a visualization
*   of how deep the bvh goes at this pixel, for debugging purposes
*/

class DebugTracerBVHDepth : public IRayTracer
{
public:
	DebugTracerBVHDepth(const Screen& screen, Film* film);
	~DebugTracerBVHDepth() override;

private:
  RGBf TraceRay(Ray& ray, const Scene& scene, uint32 a_depth) override;

private:
	int32 maxDepth;
	int32 minDepth;
};
