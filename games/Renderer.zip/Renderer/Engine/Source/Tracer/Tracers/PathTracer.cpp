#include "PathTracer.h"
#include "SceneTraversal/Ray.h"
#include "SceneTraversal/Intersection.h"
#include "SceneTraversal/Primitives/Primitive.h"
#include "Cameras/Camera.h"
#include "Screen/Screen.h"
#include "Screen/Film.h"
#include "Samplers/Data/SampleBuffer.h"
#include "Shading/Materials/IMaterial.h"
#include "Utilities/Misc/RNG.h"
#include "Utilities/Misc/ParallelForLoop.h"
#include <assert.h>


///////////////////////////////////////////////////////////////////////////////
// Render sample batch functions

void PathTracer::ProcessSampleBufferMultithreaded(
  const SampleBuffer& sample_buff, const Scene& scene,
  const Camera& cam)
{
  // trace all rays multithreaded
  std::function<void(int32)> func = [&](int32 i)
  {
    for (uint32 j = sample_buff.sample_chunks[i].start;
      j < sample_buff.sample_chunks[i].end; ++j)
    {
      Sample& s = sample_buff.samples[j];
      Ray r = cam.GenerateRay(s);
      RGBf c = TraceRay(r, scene, 0u);
      film_->AddWeightedPixel(s, c);
    }
  };
  ParallelFor(func, sample_buff.num_chunks, 1); // 1 chunk per thread
}

void PathTracer::ProcessSampleBufferSinglethreaded(
  const SampleBuffer& sample_buff, const Scene& scene,
  const Camera& cam)
{
  // trace all rays on this thread
  for (uint32 i = 0; i < sample_buff.num_samples; ++i)
  {
    Sample& s = sample_buff.samples[i];
    Ray r = cam.GenerateRay(s);
    RGBf c = TraceRay(r, scene, 0u);
    film_->AddWeightedPixel(s, c);
  }
}


///////////////////////////////////////////////////////////////////////////////
// Trace Ray function

RGBf PathTracer::TraceRay(Ray& ray, const Scene& scene, uint32 depth)
{
  // intersect the scene
  Intersection hit;
  if (scene.IntersectScene(ray, hit) == false)
  {
    return Colors::Black;
  }

  // compute shading at intersection point
  Ray ray_out;
  Float pdf;
  RGBf le, lm;
  hit.prim->mat_->EvaluateMaterial(hit, ray, &ray_out, &pdf, &le, &lm);

  // return if you are a light
  if (hit.prim->mat_->IsLight())
  {
    return le;
  }

  // Russian Roulette
  if (kUseRR)
  {
    Float chance_to_kill = Min(Float(0.95), Max(lm.r, Max(lm.g, lm.b)));
    if (depth >= kMinDepth)
    {
      if (rng::Float() < chance_to_kill)
      {
        pdf *= chance_to_kill;
      }
      else
      {
        // scale becomes 0, but that would be the same as returning black
        return Colors::Black;
      }
    }
  }

  // trace a ray for incoming illumination
  RGBf li = TraceRay(ray_out, scene, depth + 1) / pdf;

  // handle specular surfaces
  if (hit.prim->mat_->GetFlags() & (
    IMaterial::MaterialType::REFLECTION |
    IMaterial::MaterialType::TRANSMISSION))
  {
    return li * lm;
  }

  // handle diffuse surfaces
  return li * Dot(ray_out.d, hit.n) * lm;
}
