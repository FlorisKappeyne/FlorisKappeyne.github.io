#include "DebugTracerBVHDepth.h"
#include "SceneTraversal/Intersection.h"
#include "Shading/rgbf.h"

///////////////////////////////////////////////////////////////////////////////
// Class functions

DebugTracerBVHDepth::DebugTracerBVHDepth(const Screen& screen, Film* film)
	:
	IRayTracer(screen, film, TracerType::DD),
	maxDepth(11), // start with a small value to ensure correct calculations
	minDepth(10)  // start at a smaller number than maxDepth, but higher than zero to ensure accuracy
{
}

DebugTracerBVHDepth::~DebugTracerBVHDepth()
{
}

///////////////////////////////////////////////////////////////////////////////
// TraceRay function

RGBf DebugTracerBVHDepth::TraceRay(Ray& ray, const Scene&scene, uint32 a_depth)
{
	// get the bvh_ depth for this ray
	bool intersectedMesh;
	int32 numPrimitivesIntersected, numLeafNodes, numBranchNodes;
	int32 res = scene.IntersectSceneBVHDepth(ray, intersectedMesh,
		numPrimitivesIntersected, numLeafNodes, numBranchNodes);

	// update min and max depth
	minDepth = Min(res, minDepth);
	maxDepth = Max(res, maxDepth);

	// calculate normalized value
	Float diff = Float(maxDepth - minDepth);
	Float normValue = Float(res - minDepth) / diff;

	// calculate color and return it
	return RGBf(normValue, 1.0f - normValue, kZeroF);
}