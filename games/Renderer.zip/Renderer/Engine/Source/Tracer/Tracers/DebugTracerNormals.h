#pragma once
#include "IRayTracer.h"

struct SampleBuffer;

/*
* DebugTracerNormals - child of IRaytracer
*
* this class implements the TraceRay function to return a visualization
*   of the normal of the primitive at this pixel, for debugging purposes
*/

class DebugTracerNormals : public IRayTracer
{
public:
    DebugTracerNormals(const Screen& screen, Film* film);
    ~DebugTracerNormals() override;

private:
    RGBf TraceRay(Ray& ray, const Scene& scene, uint32 a_depth) override;
};
