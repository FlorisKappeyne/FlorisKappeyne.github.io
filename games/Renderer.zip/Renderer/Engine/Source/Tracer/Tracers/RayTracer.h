#pragma once
#include "IRayTracer.h"

/**
* RayTracer - Child of IRayTracer
*  a simple depth renderer that returns the color of the object
*  at the given pixel
*
* Trace Ray is implemented so that it ignores lighting and returns
*   the base color of the object for debugging purposes
*/

class RayTracer : public IRayTracer
{
public:
  RayTracer(const Screen& scr_, Film* film);
  ~RayTracer() override;

private:
  RGBf TraceRay(Ray& ray, const Scene& scene, uint32 a_depth) override;
};
