#pragma once
#include "argbc.h"
#include "Utilities/MathUtilities.h"
#include "Utilities/Misc/RNG.h"

/*
* RGBf
*
*   A class that represents colors which holds r g and b values stored as Floats
*
*   colors are stored in linear space, but will be transformed to sRGB space when
*   converting to 32 bit
*/

class RGBf
{
public:
  // construcctors
  RGBf()
    :
    r(kZeroF),
    g(kZeroF),
    b(kZeroF)
  {}
  RGBf(const RGBf& col)
    :
    r(col.r),
    g(col.g),
    b(col.b)
  {}
  RGBf(Float value)
    :
    r(value),
    g(value),
    b(value)
  {}
  RGBf(Float a_r, Float a_g, Float a_b)
    :
    r(a_r),
    g(a_g),
    b(a_b)
  {}
  RGBf(unsigned char a_r, unsigned char a_g, unsigned char a_b)
    :
    r((Float)a_r * kByteToOne),
    g((Float)a_g * kByteToOne),
    b((Float)a_b * kByteToOne)
  {}

  // relative luminance
  Float GetIntensity() const
  {
    return Float(0.2126) * r + Float(0.7152) * g + Float(0.0722) * b;
  }

  // range limiters
  void Limit(Float value)
  {
    r = Min(r, value);
    b = Min(b, value);
    g = Min(g, value);
  }
  void Clamp(Float low = kZeroF, Float high = kOneF)
  {
    Limit(high);
    r = Max(r, low);
    b = Max(b, low);
    g = Max(g, low);
  }
  RGBf GetClamped(Float low = kZeroF, Float high = kOneF) const
  {
    RGBf res = *this;
    res.Limit(high);
    res.r = Max(r, low);
    res.b = Max(b, low);
    res.g = Max(g, low);
    return res;
  }

  // transforms from linear color space to sRGB color space
  ARGBc To32Bit() const
  {
    uint32 res = 0u;
    res |= 255u << 24;
    res |= LinearToSRGB(r) << 16;
    res |= LinearToSRGB(g) << 8;
    res |= LinearToSRGB(b);
    return res;
  }

  // multiplication
  RGBf operator*(const Float rhs) const
  {
    RGBf res;
    res.r = r * rhs;
    res.g = g * rhs;
    res.b = b * rhs;
    return res;
  }
  RGBf& operator*=(const Float rhs)
  {
    r *= rhs;
    g *= rhs;
    b *= rhs;
    return *this;
  }
  RGBf operator*(const RGBf& rhs) const
  {
    RGBf res;
    res.r = r * rhs.r;
    res.g = g * rhs.g;
    res.b = b * rhs.b;
    return res;
  }
  RGBf& operator*=(const RGBf& rhs)
  {
    r *= rhs.r;
    g *= rhs.g;
    b *= rhs.b;
    return *this;
  }

  // addition
  RGBf operator+(const Float rhs) const
  {
    RGBf res;
    res.r = r + rhs;
    res.g = g + rhs;
    res.b = b + rhs;
    return res;
  }
  RGBf& operator+=(const Float rhs)
  {
    r += rhs;
    g += rhs;
    b += rhs;
    return *this;
  }
  RGBf operator+(const RGBf& rhs) const
  {
    RGBf res;
    res.r = r + rhs.r;
    res.g = g + rhs.g;
    res.b = b + rhs.b;
    return res;
  }
  RGBf& operator+=(const RGBf& rhs)
  {
    r += rhs.r;
    g += rhs.g;
    b += rhs.b;
    return *this;
  }

  // subtraction
  RGBf operator-(const Float rhs) const
  {
    RGBf res;
    res.r = r - rhs;
    res.g = g - rhs;
    res.b = b - rhs;
    return res;
  }
  RGBf& operator-=(const Float rhs)
  {
    r -= rhs;
    g -= rhs;
    b -= rhs;
    return *this;
  }
  RGBf operator-(const RGBf& rhs) const
  {
    RGBf res;
    res.r = r - rhs.r;
    res.g = g - rhs.g;
    res.b = b - rhs.b;
    return res;
  }
  RGBf& operator-=(const RGBf& rhs)
  {
    r -= rhs.r;
    g -= rhs.g;
    b -= rhs.b;
    return *this;
  }

  // division
  RGBf operator/(const Float rhs) const
  {
    RGBf res;
    Float invrhs = kOneF / rhs;
    res.r = r * invrhs;
    res.g = g * invrhs;
    res.b = b * invrhs;
    return res;
  }
  RGBf& operator/=(const Float rhs)
  {
    Float invrhs = kOneF / rhs;
    r *= invrhs;
    g *= invrhs;
    b *= invrhs;
    return *this;
  }
  RGBf operator/(const RGBf& rhs) const
  {
    RGBf res;
    res.r = r / rhs.r;
    res.g = g / rhs.g;
    res.b = b / rhs.b;
    return res;
  }
  RGBf& operator/=(const RGBf& rhs)
  {
    r /= rhs.r;
    g /= rhs.g;
    b /= rhs.b;
    return *this;
  }

  // Comparison
  bool operator<(const Float rhs) const
  {
    return (r < rhs && g < rhs && b < rhs);
  }
  bool operator<(const RGBf& rhs) const
  {
    return GetIntensity() < rhs.GetIntensity();
  }


private:
  // color space transformation
  uint32 LinearToSRGB(Float x) const
  {
    return uint32((x <= Float(0.0031308) ?
      x * Float(12.92) :
      Float(1.055) * pow(x, Float(1.0 / 2.4)) - Float(0.055)) * kOneToByte);
  }
  Float SRGBToLinear(uint32 x) const
  {
    Float t = Float(x) * kOneToByte;
    return t <= Float(0.04045) ?
      t / Float(12.92) :
      Pow((t + Float(0.055)) / Float(1.055), Float(2.4));
  }

public:
  Float r, g, b;

private:
  static constexpr Float kOneToByte = Float(256) - kEpsilon;
  static constexpr Float kByteToOne = kOneF / Float(255);
};

// helper functions
inline RGBf Sqrt(const RGBf& color)
{
  return RGBf(
    Sqrt(color.r),
    Sqrt(color.g),
    Sqrt(color.b));
}

inline RGBf RandColor(Float min_value = Float(0.3))
{
  assert(min_value >= kZeroF && min_value < kOneF);
  Float r = rng::Float() * (kOneF - min_value) + min_value;
  Float g = rng::Float() * (kOneF - min_value) + min_value;
  Float b = rng::Float() * (kOneF - min_value) + min_value;
  return RGBf(r, g, b).GetClamped();
}

namespace Colors
{
  static RGBf Black = RGBf(Float(0.0), Float(0.0), Float(0.0));
  static RGBf White = RGBf(Float(1.0), Float(1.0), Float(1.0));
  static RGBf Gray = RGBf(Float(0.3), Float(0.3), Float(0.3));
  static RGBf LightGray = RGBf(Float(0.8), Float(0.8), Float(0.8));
  static RGBf Red = RGBf(Float(1.0), Float(0.0), Float(0.0));
  static RGBf Green = RGBf(Float(0.0), Float(1.0), Float(0.0));
  static RGBf Blue = RGBf(Float(0.0), Float(0.0), Float(1.0));
  static RGBf Yellow = RGBf(Float(1.0), Float(1.0), Float(0.0));
  static RGBf Cyan = RGBf(Float(0.0), Float(1.0), Float(1.0));
  static RGBf Magenta = RGBf(Float(1.0), Float(0.0), Float(1.0));
}
