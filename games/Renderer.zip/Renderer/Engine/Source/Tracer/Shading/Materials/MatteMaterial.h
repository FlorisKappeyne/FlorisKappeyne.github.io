#pragma once
#include "Shading/Materials/IMaterial.h"


/**
* MatteMaterial
*   child of IMaterial
*
*   A MatteMaterial models a perfect diffuse surface, and reflects rays randomly
*   in the hemisphere around the normal of the surface
*/

class MatteMaterial : public IMaterial
{
public:
    MatteMaterial(const RGBf& albedo, Float luminosity)
      :
      IMaterial(albedo, luminosity, IMaterial::MaterialType::DIFFUSE)
    {
    }

    void EvaluateMaterial(const Intersection& hit, const Ray& ray_in,
      Ray* ray_out, Float* pdf, RGBf* le, RGBf* lm) const override;
};
