#include "Shading/Materials/MatteMaterial.h"
#include "Utilities/MonteCarloUtilities.h"
#include "SceneTraversal/Intersection.h"
#include "SceneTraversal/Ray.h"


///////////////////////////////////////////////////////////////////////////////
// material function

void MatteMaterial::EvaluateMaterial(const Intersection& hit, const Ray& ray_in,
  Ray* ray_out, Float* pdf, RGBf* le, RGBf* lm) const
{
  // incoming vector
  Vec3 rand = CosineSampleHemisphere(Vec2(rng::Float(), rng::Float()));
  Vec3 tang, bitang;
  CoordinateSystem(hit.n, &tang, &bitang);
  Vec3 wi = Vec3(
    rand.x * bitang.x + rand.y * tang.x + rand.z * hit.n.x,
    rand.x * bitang.y + rand.y * tang.y + rand.z * hit.n.y,
    rand.x * bitang.z + rand.y * tang.z + rand.z * hit.n.z).Normalized();
  
  *ray_out = Ray(wi, hit.p + hit.n * kEpsilon);

  Float cos_theta = Dot(wi, hit.n);

  // pdf is the same over all possible outcomes
  *pdf = CosineHempispherePDF(cos_theta);

  // material color
  *lm = albedo_ * kInvPi;

  // material light
  *le = albedo_ * luminosity;
}
