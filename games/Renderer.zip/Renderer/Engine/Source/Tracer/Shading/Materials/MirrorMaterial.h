#pragma once
#include "Shading/Materials/IMaterial.h"


/**
* MirrorMaterial
*   child of IMaterial
*
*   A MirrorMaterial models a perfect mirrors, and reflects rays around
*   the normal of the surface
*/

class MirrorMaterial : public IMaterial
{
public:
    MirrorMaterial(const RGBf& albedo, Float luminosity)
      :
      IMaterial(albedo, luminosity, IMaterial::MaterialType::REFLECTION)
    {
    }

    void EvaluateMaterial(const Intersection& hit, const Ray& ray_in,
      Ray* ray_out, Float* pdf, RGBf* le, RGBf* lm) const override;
};
