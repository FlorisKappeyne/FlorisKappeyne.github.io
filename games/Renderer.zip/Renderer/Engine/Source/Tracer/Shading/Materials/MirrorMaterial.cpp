#include "Shading/Materials/MirrorMaterial.h"
#include "Utilities/MonteCarloUtilities.h"
#include "Utilities/BSDFUtilities.h"
#include "SceneTraversal/Intersection.h"
#include "SceneTraversal/Ray.h"


///////////////////////////////////////////////////////////////////////////////
// material function

void MirrorMaterial::EvaluateMaterial(const Intersection& hit, const Ray& ray_in,
  Ray* ray_out, Float* pdf, RGBf* le, RGBf* lm) const
{
  // a perfect bounce
  Vec3 wi = Reflect(ray_in.d, hit.n);

  // make sure the bias is applied to the correct side of the object
  Vec3 n = Dot(hit.n, wi) > kZeroF ? hit.n : -hit.n;

  // construct the ray
  *ray_out = Ray(wi, hit.p + n * kEpsilon);

  // for a mirror, there's only one possible ray, for which the chance is zero
  *pdf = kOneF;

  // mirrors can't emit, so zero
  *le = RGBf(kZeroF);

  // simply the color, will usually be white for a mirror
  *lm = albedo_;
}