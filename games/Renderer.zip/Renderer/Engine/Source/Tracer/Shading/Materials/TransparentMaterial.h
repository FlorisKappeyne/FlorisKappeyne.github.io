#pragma once
#include "Shading/Materials/IMaterial.h"
#include "Utilities/Math/Vec3.h"


/**
* MirrorMaterial
*   child of IMaterial
*
*   A MirrorMaterial models a perfect mirrors, and reflects rays around
*   the normal of the surface
*/

class TransparentMaterial : public IMaterial
{
public:
  TransparentMaterial(const RGBf& albedo, Float luminosity,
    Float refraction_index, const Vec3& absorb_coef)
    :
    IMaterial(albedo, luminosity,
      IMaterial::MaterialType::REFLECTION | 
      IMaterial::MaterialType::TRANSMISSION ),
    ior_(refraction_index),
    absorb_coef_(absorb_coef)
  {
  }

  void EvaluateMaterial(const Intersection& hit, const Ray& ray_in,
    Ray* ray_out, Float* pdf, RGBf* le, RGBf* lm) const override;

private:
  // index of refraction
  Float ior_;
  Vec3 absorb_coef_;
  

  /*
  Indices of refraction:
    vacuum        - 1.0
    air           - 1.000277
    water         - 4/3
    ice           - 1.31
    Crown glass   - 1.50 - 1.62
    Flint glass   - 1.57 - 1.75
    Sapphire      - 1.77
    Diamond       - 2.417
  */
};
