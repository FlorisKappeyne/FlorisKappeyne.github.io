#pragma once
#include "Shading/rgbf.h"

/*
* IMaterial 
*   A IMaterial models the way light behaves when it hits a surface
*
*   Children of this class only overwrite one function, which returns all necessary shading information   
*/

struct Intersection;
struct Ray;

class IMaterial
{
public:
  enum MaterialType
  {
    REFLECTION = 1 << 0,
    TRANSMISSION = 1 << 1,
    DIFFUSE = 1 << 2,
    ALL = REFLECTION | TRANSMISSION | DIFFUSE
  };

public:
    IMaterial(const RGBf& albedo, Float luminosity, uint32 flags)
      :
      albedo_(albedo),
      luminosity(luminosity),
      type_flags_(flags)
    {
    }

    // combined shading functions. 
    // in: an intersection point, an RNG object and an outgoing vector,
    // out: a possible incoming vector and corresponding pdf,
    //    emitted light color, material light color
    virtual void EvaluateMaterial(const Intersection& hit, const Ray& ray_in,
      Ray* ray_out, Float* pdf, RGBf* le, RGBf* lm) const = 0;

    bool IsLight() const
    {
      return luminosity != kZeroF;
    }

    void RandomizeColor()
    {
      albedo_ = RandColor();
    }

    uint32 GetFlags()
    {
      return type_flags_;
    }

protected:
    RGBf albedo_;
    Float luminosity;
    uint32 type_flags_;
};