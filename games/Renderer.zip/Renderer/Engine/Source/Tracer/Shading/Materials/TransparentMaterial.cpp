#include "Shading/Materials/TransparentMaterial.h"
#include "Utilities/MonteCarloUtilities.h"
#include "Utilities/BSDFUtilities.h"
#include "SceneTraversal/Intersection.h"
#include "SceneTraversal/Ray.h"


///////////////////////////////////////////////////////////////////////////////
// material function

void TransparentMaterial::EvaluateMaterial(const Intersection& hit, const Ray& ray_in,
  Ray* ray_out, Float* pdf, RGBf* le, RGBf* lm) const
{
  // set up variables
  Vec3 wo = ray_in.d;
  Vec3 wi;
  Float eta_i = ray_in.ior == kZeroF ? kEtaAir : ray_in.ior;
  Float eta_t = ior_;
  Float cos_theta_i = Dot(wo, hit.n);
  
  // fresnel for dielectric surfaces to determine if we reflect or refract
  Float pr = FrDielectric(cos_theta_i, eta_i, eta_t);
  
  // randomly choose between refracting and reflecting based on pr = 1 - pt
  Float u = rng::Float();
  if (u < pr) // reflect the light
  {
    // a perfect bounce
    wi = Reflect(wo, hit.n);
    *pdf = kOneF; // pr;
  }
  else // refract it
  {
    if (Refract(wo, hit.n, eta_i, eta_t, &wi) == false)
    {
      // this never happens, because than pr would be > 1
      // if you can't refract, internal reflection occurs
      wi = Reflect(wo, hit.n);
    }
    *pdf = kOneF;// kOneF - pr;
  }

  // make sure the bias is applied to the correct side of the object
  bool leaving = Dot(hit.n, wi) > kZeroF;
  Vec3 n = leaving ? hit.n : -hit.n;
  Float depth = ray_in.depth_in_medium + ray_in.t;
  // construct the outward ray
  *ray_out = Ray(wi, hit.p + n * kEpsilon);
  ray_out->depth_in_medium =  (leaving == false) && (ray_in.ior == ior_) ?
    depth : kZeroF;
  ray_out->ior = leaving ? kEtaAir : ior_;

  // glass can't emit, so zero
  *le = RGBf(kZeroF);

  if (leaving)
  {
    // apply beer's law 
    *lm = albedo_ * BeerLambert(absorb_coef_, depth);
  }
  else
  {
    *lm = RGBf(kOneF);
  }
}