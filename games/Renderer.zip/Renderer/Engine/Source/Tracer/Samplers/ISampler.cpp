#include "ISampler.h"
#include "Utilities/SamplerUtilities.h"
#include "Data/SampleBuffer.h"
#include "Screen/Screen.h"
#include "Screen/ScreenTile.h"
#include "Utilities/Misc/ParallelForLoop.h"


///////////////////////////////////////////////////////////////////////////////
// Sample functions

SampleBuffer ISampler::GetSamplesScreen(uint32 spp)
{
  // find top left and right bottom corners
  Vec2I min = Vec2I(0, 0);

  // calculate the right bottom corner
  Vec2I max = Vec2I(scr_.width - 1, scr_.height - 1);

  return GetSamplesSection(min, max, spp);
}

SampleBuffer ISampler::GetSamplesLines(uint32 num_lines, uint32 spp)
{
  // calculate the left top corner
  Vec2I min = Vec2I(0, next_grid_line_ * ScreenTile::kTileSize);

  // increment the line idx
  next_grid_line_ += num_lines;

  // calculate the right bottom corner
  Vec2I max = Vec2I(scr_.width - 1, next_grid_line_ * ScreenTile::kTileSize - 1);

  // handle the case where the number of lines crosses the bottom of the screen
  if (next_grid_line_ >= scr_.grid_height)
  {
    max.y = scr_.height - 1;

    // start at 0 again, ignoring the leftover lines
    next_grid_line_ = 0;
  }

  return GetSamplesSection(min, max, spp);
}

SampleBuffer ISampler::GetSamplesSection(const Vec2I & min, const Vec2I & max, uint32 spp)
{
  // prepare the child class's functionality
  Prepare();

  // calculate the boundaries of the tiles
  uint32
    start_tile_x = min.x / ScreenTile::kTileSize,
    start_tile_y = min.y / ScreenTile::kTileSize,
    end_tile_x = max.x / ScreenTile::kTileSize + 1,
    end_tile_y = max.y / ScreenTile::kTileSize + 1;

  // find out how many samples to make
  uint32 tot_num_samples = 0;
  uint32 num_tiles = 0;
  for (uint32 y = start_tile_y; y < end_tile_y; ++y)
  {
    for (uint32 x = start_tile_x; x < end_tile_x; ++x)
    {
      ScreenTile& tile = scr_.tiles[y * scr_.grid_width + x];
      tot_num_samples += tile.GetNumPixels();
      num_tiles++;
    }
  }

  // remember to account for the number of samples per pixel
  tot_num_samples *= spp;

  // allocate sample buffer memory
  SampleBuffer res;
  res.Init(tot_num_samples, num_tiles);

  // precalculate ndc scale values
  Float invX = scr_.inv_x, invY = scr_.inv_y;

  // indices for samples and chunks
  uint32 sample_idx = 0;
  uint32 chunk_idx = 0;

  // loop over all tiles
  for (uint32 y = start_tile_y; y < end_tile_y; ++y)
  {
    for (uint32 x = start_tile_x; x < end_tile_x; ++x, ++chunk_idx)
    {
      // get a reference to the tile for easy acces
      uint32 i = y * scr_.grid_width + x;
      ScreenTile& tile = scr_.tiles[i];

      // remember the start idx
      uint32 sample_idx_start = sample_idx;

      // generate samples
      GenerateSamplesForTile(tile, res, sample_idx, spp);

      // increment sample idx
      sample_idx += tile.GetNumPixels() * spp;

      // update the chunk in the sample buffer      
      res.sample_chunks[chunk_idx].start = sample_idx_start;
      res.sample_chunks[chunk_idx].end = sample_idx;
    }
  }

  return res;

  //SampleBuffer res;
  //res.Init(scr_.num_pixels, scr_.num_tiles);
  //
  //// loop over all tiles
  //std::function<void(int32)> func = [&](int32 i)
  //{
  //  ScreenTile& tile = scr_.tiles[i];
  //
  //  // calculate the current sample's idx
  //  uint32 sample_idx = tile.grid_y * ScreenTile::kTileSize * scr_.width +
  //    tile.grid_x * tile.height * tile.width;
  //
  //  // remember the tile_start_idx
  //  uint32 tile_start_idx = sample_idx;
  //
  //  // generate samples
  //  GenerateSamplesForTile(tile, res, scr_, sample_idx);
  //
  //  // update chunk in the sample buffer
  //  UpdateSampleChunkCounters(res.sample_chunks[i], tile, tile_start_idx);
  //};
  //ParallelFor(func, scr_.num_tiles, 4);
  //
  //return res;
}
