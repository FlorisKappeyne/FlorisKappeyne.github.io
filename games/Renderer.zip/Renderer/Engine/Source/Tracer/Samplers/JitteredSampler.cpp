#include "JitteredSampler.h"
#include "utilities/SamplerUtilities.h"
#include "Data/SampleBuffer.h"
#include "Screen/Screen.h"
#include "Screen/ScreenTile.h"


///////////////////////////////////////////////////////////////////////////////
// sample generation function

void JitteredSampler::GenerateSamplesForTile(ScreenTile& tile, SampleBuffer& sample_buff,
  uint32 sample_idx, uint32 spp)
{
  // calculate the boundaries
  uint32
    start_x = tile.grid_x * ScreenTile::kTileSize,
    start_y = tile.grid_y * ScreenTile::kTileSize;

  uint32
    end_x = start_x + tile.width,
    end_y = start_y + tile.height;

  // generate samples per pixel
  for (uint32 y = start_y; y < end_y; ++y)
  {
    for (uint32 x = start_x; x < end_x; ++x)
    {
      for (uint32 i = 0; i < spp; ++i)
      {
        sample_buff.samples[sample_idx++] = GetJitteredSample(x, y, scr_.inv_x, scr_.inv_y);
      }
    }
  }
}