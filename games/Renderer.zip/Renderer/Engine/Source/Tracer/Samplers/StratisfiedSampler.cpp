#include "StratisfiedSampler.h"
#include "utilities/SamplerUtilities.h"
#include "Data/SampleBuffer.h"
#include "Screen/Screen.h"
#include "Screen/ScreenTile.h"
#include "Utilities/Misc/ParallelForLoop.h"


///////////////////////////////////////////////////////////////////////////////
// sample generation function

void StratisfiedSampler::GenerateSamplesForTile(ScreenTile& tile, SampleBuffer& sample_buff, uint32 sample_idx, uint32 spp)
{
  // precalculate ndc scale values
  Float invX = scr_.inv_x, invY = scr_.inv_y;
  Float halfInvX = kHalfF * invX, halfInvY = kHalfF * invY;

  // calculate the boundaries
  uint32
    start_x = tile.grid_x * ScreenTile::kTileSize,
    start_y = tile.grid_y * ScreenTile::kTileSize;

  uint32
    end_x = start_x + tile.width,
    end_y = start_y + tile.height;

  // generate the samples
  for (uint32 y = start_y; y < end_y; ++y)
  {
    Float ndcy = (Float)y * invY + halfInvY;
    for (uint32 x = start_x; x < end_x; ++x)
    {
      // ignore spp, it doesn't make sense for a Stratisfied sampler

      Float ndcx = (Float)x * invX + halfInvX;
      sample_buff.samples[sample_idx++] = Sample(x, y, ndcx, ndcy);
    }
  }
}
