#pragma once
#include "Typedefs.h"

/**
* Sample
*
*  A struct that represents the location of a pixel on the screen
*   it holds the x and y index, and the normalized device
*   coordinates of to where on the viewplane
*/

struct Sample
{
  Sample()
  {
  }
  Sample(uint32 a_x, uint32 a_y)
    :
    x(a_x),
    y(a_y)
  {
  }
  Sample(uint32 a_x, uint32 a_y,
    Float a_ndcX, Float a_ndcY)
    :
    x(a_x),
    y(a_y),
    ndcX(a_ndcX),
    ndcY(a_ndcY)
  {
  }

public:
  uint32 x, y;
  Float ndcX, ndcY;
};