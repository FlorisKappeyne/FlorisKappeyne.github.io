#pragma once
#include "Typedefs.h"
#include "Sample.h"

/**
* SampleBuffer
*
* A struct that holds a buffer of samples, which can be passed to
* a renderer
*/
struct SampleBuffer
{
  SampleBuffer()
    :
    samples(nullptr),
    sample_chunks(nullptr),
    num_samples(0),
    num_chunks(0)
  {}

  // a chunk of samples representing a tile in the buffer
  struct SampleChunk
  {
    uint32 start;
    uint32 end;

    uint32 GetSize()
    {
      return end - start;
    }
  };

  // initializes the chunk with enough memory so it can be filled by a sampler
  void Init(uint32 sample_count, uint32 chunk_count)
  {
    num_samples = sample_count;
    num_chunks = chunk_count;

    samples = new Sample[num_samples];
    sample_chunks = new SampleChunk[num_chunks];
  }

  // deletes the memory. No destructor because this is passed around a lot
  void Clear()
  {
    delete[] samples;
    delete[] sample_chunks;
  }

  // public data that holds the chunks and their samples
  Sample* samples;
  SampleChunk* sample_chunks;
  uint32 num_samples;
  uint32 num_chunks;
};