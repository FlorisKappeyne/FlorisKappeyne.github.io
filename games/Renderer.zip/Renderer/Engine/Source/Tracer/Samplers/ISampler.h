#pragma once
#include "Typedefs.h"
#include "Utilities/Math/Vec2.h"

struct Screen;
struct ScreenTile;
struct SampleBuffer;

/**
* ISampler - Sampler base class
*
* A sampler is a class that generates samples, which will then be used
*  by the renderer to to generate rays. Child samplers can generate
*  samplers for different situations.
*
* Samples can be generated for the entire frame, for a number of tiles or
*   for a section of the frame
*/

class ISampler
{
public:
  enum SamplerType
  {
    STRATISFIED,
    JITTERED,
    DENOISING,
    SUM
  };

public:
  ISampler(const Screen& screen, SamplerType type)
    :
    scr_(screen),
    next_grid_line_(0),
    type(type)
  {
  }
  virtual ~ISampler() {}
  
  // type management
  SamplerType GetType()
  {
    return type;
  }

  // program execution flow utility
  bool FinishedScreen()
  {
    return next_grid_line_ == 0;
  }

  // generate samples for a specified part of the frame
  SampleBuffer GetSamplesScreen(uint32 spp = 1);
  SampleBuffer GetSamplesLines(uint32 num_lines, uint32 spp = 1);
  SampleBuffer GetSamplesSection(const Vec2I& min, const Vec2I& max, uint32 spp = 1);

protected:
  // notifies the child sampler that a new frame has begun
  virtual void Prepare() {};

  // generate samples for a given tile
  virtual void GenerateSamplesForTile(ScreenTile& tile, SampleBuffer& sample_buff,
    uint32 sample_idx, uint32 spp) = 0;

protected:
  const Screen& scr_;
  SamplerType type;

private:
  uint32 next_grid_line_;
};