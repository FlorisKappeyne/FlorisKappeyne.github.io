#pragma once
#include "Samplers\ISampler.h"


/**
* JitteredSampler - child of Sampler
*
* Generates samples randomly in the pixel, not just
*  in its centre, resulting in anti-aliasing*
*/

class JitteredSampler : public ISampler
{
public:
  JitteredSampler(const Screen& screen)
    :
    ISampler(screen, SamplerType::JITTERED)
  {
  }

private:
  void GenerateSamplesForTile(ScreenTile& tile, SampleBuffer& sample_buff,
    uint32 sample_idx, uint32 samples_per_pixel) override;
};
