#pragma once
#include "Samplers\ISampler.h"

/**
* StratisfiedSampler - child of ISampler
*
* Generates samples that always point to the centre of a pixel
*  Useful for ray tracers for which one sample per pixel is enough
*/
class StratisfiedSampler : public ISampler
{
public:

  StratisfiedSampler(const Screen& screen)
    :
    ISampler(screen, SamplerType::STRATISFIED)
  {
  }

private:
  void GenerateSamplesForTile(ScreenTile& tile, SampleBuffer& sample_buff,
    uint32 sample_idx, uint32 spp) override;
};