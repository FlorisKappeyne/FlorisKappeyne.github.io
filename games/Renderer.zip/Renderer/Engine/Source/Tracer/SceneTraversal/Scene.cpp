#include "Scene.h"
#include "BVH/BVH.h"
#include "Loading/Factory.h"
#include "Primitives/Model.h"
#include "Primitives/Mesh.h"
#include "Primitives/Triangle.h"
#include "Shading/Materials/IMaterial.h"
#include "Utilities/Misc/ParallelForLoop.h"

// global variable
extern thread_local int32 thread_index;

///////////////////////////////////////////////////////////////////////////////
// class functions
///////////////////////////////////////////////////////////////////////////////
Scene::Scene()
  :
  bvh_(nullptr)
{
  // allocate and init one RayCount struct per thread
  int32 thread_count = SystemThreadCount();
  rays_counts_ = new RayCount[thread_count];
  for (int32 i = 0; i < thread_count; ++i)
  {
    rays_counts_[i].count = 0;
  }
}

Scene::~Scene()
{
  for (size_t i = 0; i < models_.size(); ++i)
  {
    delete models_[i];
  }
  for (auto& it : mesh_data_)
  {
    delete it.second;
  }
  for (auto& it : mat_data_)
  {
    delete it.second;
  }
  delete bvh_;
  delete[] rays_counts_;
}


///////////////////////////////////////////////////////////////////////////////
// model management
///////////////////////////////////////////////////////////////////////////////

Model* Scene::AddModel(const std::string& name, const Transform& m2w,
  IMaterial* mat)
{
  auto res = mesh_data_.find(name);
  if (res != mesh_data_.end())
  {
    Model* mesh = new Model(name, m2w, mat, res->second);
    models_.push_back(mesh);

    if (mat->IsLight())
    {
      lights_.push_back(mesh);
    }

    return mesh;
  }
  else
  {
    assert(false && "no mesh found at name");
    return nullptr;
  }
}


///////////////////////////////////////////////////////////////////////////////
// mesh management
///////////////////////////////////////////////////////////////////////////////

bool Scene::HasMesh(const std::string& name) const
{
  return HasType(mesh_data_, name);
}

bool Scene::AddMesh(const std::string& name, Mesh* mesh)
{
  return AddType(mesh_data_, name, mesh);
}

Mesh* Scene::GetMesh(const std::string& name) const
{
  return GetType(mesh_data_, name);
}


///////////////////////////////////////////////////////////////////////////////
// material management
///////////////////////////////////////////////////////////////////////////////

bool Scene::HasMat(const std::string& name) const
{
  return HasType(mat_data_, name);
}

bool Scene::AddMat(const std::string& name, IMaterial* mat)
{
  return AddType(mat_data_, name, mat);
}

IMaterial* Scene::GetMat(const std::string & name) const
{
  return GetType(mat_data_, name);
}


///////////////////////////////////////////////////////////////////////////////
// Scene optimization
///////////////////////////////////////////////////////////////////////////////

void Scene::Accelerate()
{
  // clear the ray count
  ResetRayCount();

  triangles_.clear();
  for (size_t i = 0, n = models_.size(); i < n; ++i)
  {
    std::vector<Triangle> trans_tris = models_[i]->GetTransformedTriangles();
    for (size_t j = 0, m = trans_tris.size(); j < m; ++j)
    {
      trans_tris[j].pModel_ = models_[i];
    }
    triangles_.insert(triangles_.end(), trans_tris.begin(), trans_tris.end());
  }

  // call the BVH constructor to create a bvh from the scene
  bvh_ = new BVH(triangles_);

  // create a distribution function out of all of the lights' 1d distribution function, use it for NEE
  std::vector<Float> light_areas;
  light_areas.reserve(lights_.size());
  for (int32 i = 0; i < lights_.size(); ++i)
  {
    Float area = lights_[i]->GetSurfaceArea();
    light_areas.push_back(lights_[i]->GetSurfaceArea());
    sum_surface_area_light_ += area;
  }
  light_distribution_function_ = Distribution1D(light_areas.data(), light_areas.size());
}


///////////////////////////////////////////////////////////////////////////////
// scene intersection functions
///////////////////////////////////////////////////////////////////////////////

bool Scene::IntersectScene(Ray & ray, Intersection & hit) const
{
  // count the rays
  IncrementRayCount();
  return bvh_->Intersect(ray, hit);
}

bool Scene::IntersectSceneShadow(Ray & ray) const
{
  // count the rays
  IncrementRayCount();
  return bvh_->IntersectShadow(ray);
}

int32 Scene::IntersectSceneBVHDepth(Ray& ray, bool& intersectedMesh,
  int32& numPrimsIntersected, int32& numLeafNodes, int32& numBranchNodes) const
{
  // count the rays
  IncrementRayCount();
  return bvh_->IntersectDepth(ray, 0);
}


///////////////////////////////////////////////////////////////////////////////
// shading utility functions
///////////////////////////////////////////////////////////////////////////////

const Model* Scene::GetUniformRandomLight() const
{
  assert(lights_.size() > 0);
  return lights_[rng::Uint() % lights_.size()];
}

const Model* Scene::GetWeightedRandomLight() const
{
  Float pdf, u_remapped;

  // get a random triangle from the mesh (sampled uniformly based on surface area)
  size_t idx = light_distribution_function_.SampleDiscrete(rng::Float(), &pdf, &u_remapped);

  // get a random hit from the triangle
  return lights_[idx];
}

Float Scene::GetRandomHitOnLight(Intersection& hit) const
{
  // get a random light distributed on it's surface area and get a random hit on its surface
  GetWeightedRandomLight()->GetRandomHitOnSurface(hit);

  return sum_surface_area_light_;
}

const std::vector<Model*>& Scene::GetAllLights() const
{
  return lights_;
}


///////////////////////////////////////////////////////////////////////////////
// performance tracking utility functions
///////////////////////////////////////////////////////////////////////////////

int64 Scene::GetRayCount() const
{
  int64 sum = 0;
  for (int i = 0; i < 8; ++i)
  {
    sum += rays_counts_[i].count;
    rays_counts_[i].count = 0;
  }
  return sum;
}

void Scene::ResetRayCount() const
{
  for (int i = 0; i < 8; ++i)
  {
    rays_counts_[i].count = 0;
  }
}

void Scene::IncrementRayCount() const
{
  rays_counts_[thread_index].count++;
}


