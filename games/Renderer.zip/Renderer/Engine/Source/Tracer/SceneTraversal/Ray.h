#pragma once
#include "Utilities/Math/Vec3.h"
#include "Utilities/MathUtilities.h"

/**
* Ray 
*
*   a ray has a point, a direction and a length
*
*   The ray represents the light particle in our pathtraces. It can collide with objects
*   to check what color they have.
*/

struct Ray
{
public:
  Ray()
  {
    t = INFINITY;
  }
  Ray(const Vec3& D, const Vec3& O, Float T = INFINITY)
    :
    d(D),
    o(O),
    t(T),
    rd4(mm_set(kZeroF, kOneF / D.z, kOneF / D.y, kOneF / d.x)),
    depth_in_medium(kZeroF),
    ior(kZeroF)
  {
    dir_is_neg[0] = d[0] < kZeroF;
    dir_is_neg[1] = d[1] < kZeroF;
    dir_is_neg[2] = d[2] < kZeroF;
  }

public:
  // origin and reciprocal direction can be accessed as a QuadFloat (__mm128 or __mm256d) and Vec3
  union
  {
    struct
    {
      Vec3 o;
      Float padding;
    };
    QF o4;
  };

  Vec3 d;
  Float t;

  union
  {
    struct
    {
      Vec3 rd;
      Float padding2;
    };
    QF rd4;
  };

  // to speed up BVh traversal
  int32 dir_is_neg[3];

  // extra shading info
  Float depth_in_medium;
  Float ior;
};