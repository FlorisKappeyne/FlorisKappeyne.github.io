#pragma once
#include "Utilities/Math/Mat44.h"
#include "Utilities/Math/Vec3.h"

class AABB;
struct Ray;

/**
* Transform
*
*  a class that represents the transformation of an
*  object in 3D space.
*
*  it holds a matrix and its inverse for easy
*/

class Transform
{
public:
  Transform() {}
  Transform(const Mat44& mat, const Mat44& matInv)
    :
    m_(mat),
    m_inv_(matInv)
  {}

  // returns the inverse of this transform
  Transform GetInverse() const
  {
    return (Transform(m_inv_, m_));
  }

  // comparison functions
  bool IsIdentity() const
  {
    // get an identity matrix
    Mat44 I = Mat44();
    for (int32 i = 0; i < 4; ++i)
    {
      for (int32 j = 0; j < 4; ++j)
      {
        if (I.m[i][j] != m_.m[i][j])
        {
          return false;
        }
      }
    }
    return true;
  }
  bool operator==(const Transform& rhs) const
  {
    for (int32 i = 0; i < 4; ++i)
    {
      for (int32 j = 0; j < 4; ++j)
      {
        if (m_.m[i][j] != rhs.m_.m[i][j])
        {
          return false;
        }
      }
    }
    return true;
  }
  bool operator!=(const Transform& rhs) const
  {
    return !(*this == rhs);
  }

  // multiplication
  Transform operator*(const Transform& rhs) const
  {
    Mat44 res = m_ * rhs.m_;
    Mat44 invRes;
    Inverse(res, &invRes);
    return Transform(res, invRes);
  }
  Transform operator*= (const Transform& rhs)
  {
    return *this = operator*(rhs);
  }

  // transform object types
  Vec3 TransformPoint(const Vec3& p) const;
  void TransformPoint(const Vec3& p, Vec3* pPOut) const;
  Vec3 TransformVector(const Vec3& v) const;
  void TransformVector(const Vec3& v, Vec3* pVOut) const;
  Vec3 TransformNormal(const Vec3& n) const;
  void TransformNormal(const Vec3& n, Vec3* pNOut) const;
  Ray TransformRay(const Ray& r) const;
  void TransformRay(const Ray& r, Ray* pROut) const;
  AABB TransformAABB(const AABB& box) const;
  void TransformAABB(const AABB& box, AABB* pBOut) const;

  // utility functions
  bool SwapsHandedness() const
  {
    Float det = (
      (m_.m[0][0] * (m_.m[1][1] * m_.m[2][2] - m_.m[1][2] * m_.m[2][1])) -
      (m_.m[0][1] * (m_.m[1][0] * m_.m[2][2] - m_.m[1][2] * m_.m[2][0])) +
      (m_.m[0][2] * (m_.m[1][0] * m_.m[2][1] - m_.m[1][1] * m_.m[2][0])));
    return det < 0.0f;
  }

  // getters
  Mat44& GetM()
  {
    return m_;
  }
  Mat44& GetMInv()
  {
    return m_inv_;
  }

private:
  Mat44 m_, m_inv_;
};

// functions that create transforms with specific properties
Transform CreateTransform(const Vec3& scale, const Vec3& rot, const Vec3& pos);
Transform CreateTranslate(const Float x, const Float y, const Float z);
Transform CreateTranslate(const Vec3& a_offSet);
Transform CreateScale(const Float x, const Float y, const Float z);
Transform CreateScale(const Vec3& a_scale);
Transform CreateRotateX(Float degrees);
Transform CreateRotateY(Float degrees);
Transform CreateRotateZ(Float degrees);
Transform CreateRotateXYZ(const Float x, const Float y, const Float z);
Transform CreateRotateXYZ(const Vec3& degrees);
Transform CreateAxisAngle(const Vec3& axis, Float degrees);

