#pragma once
#include "Utilities/Math/Vec3.h"
#include "Utilities/MathUtilities.h"

struct Ray;

/*
* AABB
*
*   class that contains the Axis Aligned Bounding Box of an object
*   the object inside fits precisely in this box, which has its edges
*   aligned with the x, y and z axes
*/

class AABB
{
public:
  // constructors
  AABB()
  {
    min = Vec3(INFINITY, INFINITY, INFINITY);
    max = Vec3(-INFINITY, -INFINITY, -INFINITY);
  }
  AABB(Vec3 p)
  {
    min = p;
    max = p;
  }
  AABB(Vec3 p1, Vec3 p2)
  {
    min = Vec3(Min(p1.x, p2.x), Min(p1.y, p2.y), Min(p1.z, p2.z));
    max = Vec3(Max(p1.x, p2.x), Max(p1.y, p2.y), Max(p1.z, p2.z));
  }
  AABB(const AABB& rhs)
    :
    min(rhs.min),
    max(rhs.max)
  {
  }

  // add something to the volume
  AABB Union(const Vec3& a_p) const;
  AABB Union(const AABB& a_aabb2) const;
  void Expand(Float delta);

  // intersection functions
  bool Intersect(const Ray& ray) const;
  inline bool Overlaps(const AABB& rhs) const
  {
    bool x = (max.x >= rhs.min.x) && (min.x <= rhs.max.x);
    bool y = (max.y >= rhs.min.y) && (min.y <= rhs.max.y);
    bool z = (max.z >= rhs.min.z) && (min.z <= rhs.max.z);
    return x && y && z;
  }
  inline bool Inside(const Vec3& p) const
  {
    bool x = (max.x >= p.x) && (min.x <= p.x);
    bool y = (max.y >= p.y) && (min.y <= p.y);
    bool z = (max.z >= p.z) && (min.z <= p.z);
    return x && y && z;
  }
  inline bool Contains(const AABB& rhs) const
  {
    return
      min.x < rhs.min.x && min.y < rhs.min.y && min.z < rhs.min.z &&
      max.x > rhs.max.x && max.y > rhs.max.y && max.z > rhs.max.z;
  }
  
  // utilities
  Float SurfaceArea() const
  {
    Vec3 d = max - min;
    return kTwoF * (d.x * d.y + d.x * d.z + d.y * d.z);
  }
  Float Volume() const
  {
    Vec3 d = max - min;
    return d.x * d.y * d.z;
  }
  int32 MaxExtent() const
  {
    Vec3 d = max - min;
    if (d.x > d.y && d.x > d.z)
    {
      return 0;
    }
    else if (d.y > d.z)
    {
      return 1;
    }
    else
    {
      return 2;
    }
    return 0;
  }
  inline Vec3 Corner(int32 i) const
  {
    return Vec3(
      (*this)[i & 1].x,
      (*this)[i & 2 ? 1 : 0].y,
      (*this)[i & 4 ? 1 : 0].z);
  }
  Vec3 Lerp(Float tx, Float ty, Float tz) const
  {
    return Vec3(
      ::Lerp(min.x, max.x, tx),
      ::Lerp(min.y, max.y, ty),
      ::Lerp(min.z, max.z, tz));
  }
  Vec3 Offset(const Vec3& v) const
  {
    return Vec3(
      (v.x - min.x) / (max.x - min.x),
      (v.y - min.y) / (max.y - min.y),
      (v.z - min.z) / (max.z - min.z));
  }

  // get the bounding sphere of this AABB
  void BoundingSphere(Float* r, Vec3* p) const
  {
    *p = kHalfF * min + kHalfF * max;
    *r = (*p - max).Magnitude();
  }

  // operators for easy use
  inline const bool operator==(const AABB& rhs) const
  {
    AABB temp = *this;
    temp.Expand(Float(0.0001)); // apply an error margin
    bool fits_in = temp.Contains(rhs);
    temp.Expand(Float(-0.0002));
    return fits_in && rhs.Contains(temp);
  }
  inline const bool operator!=(const AABB& rhs) const
  {
    return !(*this == rhs);
  }
  inline const Vec3& operator[](const int32 i) const
  {
    assert(i < 2 && i >= 0);
    return i == 0 ? min : max;
  }
  inline Vec3& operator[](const int32 i)
  {
    assert(i < 2 && i >= 0);
    return i == 0 ? min : max;
  }

public:
  union
  {
    struct
    {
      Vec3 min;
      Float dummy1; // padding for 16 or 32 byte alignment
      Vec3 max;
      Float dummy2; // padding for 16 or 32 byte alignment
    };
    struct
    {
      QF min4; // quad floats (__mm128 or __mm256)
      QF max4; // so I can use SIMD instructions
    };
  };
};