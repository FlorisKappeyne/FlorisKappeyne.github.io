#include "Intersection.h"
#include "Shading/Materials/IMaterial.h"
#include "SceneTraversal/Primitives/Primitive.h"


///////////////////////////////////////////////////////////////////////////////
// class functions

Intersection::Intersection(
  const Vec3& P, const Vec3& DPDU, const Vec3& DPDV,
  const Vec3& N, const Vec3& DNDU, const Vec3& DNDV,
  const Vec2& UV, const Primitive* pPrim)
  :
  p(P),
  dpdu(DPDU),
  dpdv(DPDV),
  n(N),
  dndu(DNDU),
  dndv(DNDV),
  uv(UV),
  prim(pPrim)
{
  // reverse the normal if the tranny swaps handedness
  if (prim && (prim->p2w_.SwapsHandedness()))
  {
    n *= -kOneF;
  }
}

Intersection::Intersection(const Vec3 & P, const Vec3 & N, const Vec2 & UV,
  const Primitive * pPrim)
  :
  p(P),
  n(N),
  uv(UV),
  prim(pPrim)
{
  // reverse the normal if the tranny swaps handedness
  if (prim && (prim->p2w_.SwapsHandedness()))
  {
    n *= -kOneF;
  }

  // guess the dpdu and dpdv
  CoordinateSystem(p, &dpdu, &dpdv);
  // guess the dndu and dndv
  CoordinateSystem(n, &dndu, &dndv);
}
