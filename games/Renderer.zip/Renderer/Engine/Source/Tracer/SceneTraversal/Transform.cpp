#include "SceneTraversal/Transform.h"
#include "SceneTraversal/Ray.h"
#include "Utilities/MathUtilities.h"
#include "Utilities/Math/Vec3.h"
#include "Utilities/Math/Vec2.h"
#include "Ray.h"
#include "AABB.h"


///////////////////////////////////////////////////////////////////////////////
// Transform function

Vec3 Transform::TransformPoint(const Vec3& p) const
{
  Float x = p.x, y = p.y, z = p.z;
  Vec3 res;
  res.x = m_.m[0][0] * x + m_.m[0][1] * y + m_.m[0][2] * z + m_.m[0][3];
  res.y = m_.m[1][0] * x + m_.m[1][1] * y + m_.m[1][2] * z + m_.m[1][3];
  res.z = m_.m[2][0] * x + m_.m[2][1] * y + m_.m[2][2] * z + m_.m[2][3];
  Float wp = m_.m[3][0] * x + m_.m[3][1] * y + m_.m[3][2] * z + m_.m[3][3];
  if (wp == 1.0f)
  {
    return res;
  }
  return res / wp;
}

void Transform::TransformPoint(const Vec3& p, Vec3* pPOut) const
{
  Float x = p.x, y = p.y, z = p.z;
  pPOut->x = m_.m[0][0] * x + m_.m[0][1] * y + m_.m[0][2] * z + m_.m[0][3];
  pPOut->y = m_.m[1][0] * x + m_.m[1][1] * y + m_.m[1][2] * z + m_.m[1][3];
  pPOut->z = m_.m[2][0] * x + m_.m[2][1] * y + m_.m[2][2] * z + m_.m[2][3];
  Float wp = m_.m[3][0] * x + m_.m[3][1] * y + m_.m[3][2] * z + m_.m[3][3];
  if (wp != 1.0f)
  {
    *pPOut /= wp;
  }
}

Vec3 Transform::TransformVector(const Vec3& v) const
{
  Float x = v.x, y = v.y, z = v.z;
  return Vec3(
    m_.m[0][0] * x + m_.m[0][1] * y + m_.m[0][2] * z,
    m_.m[1][0] * x + m_.m[1][1] * y + m_.m[1][2] * z,
    m_.m[2][0] * x + m_.m[2][1] * y + m_.m[2][2] * z);
}

void Transform::TransformVector(const Vec3& v, Vec3* pVOut) const
{
  Float x = v.x, y = v.y, z = v.z;
  *pVOut = Vec3(
    m_.m[0][0] * x + m_.m[0][1] * y + m_.m[0][2] * z,
    m_.m[1][0] * x + m_.m[1][1] * y + m_.m[1][2] * z,
    m_.m[2][0] * x + m_.m[2][1] * y + m_.m[2][2] * z);
}

Vec3 Transform::TransformNormal(const Vec3& n) const
{
  Float x = n.x, y = n.y, z = n.z;
  return Vec3(
    m_inv_.m[0][0] * x + m_inv_.m[1][0] * y + m_inv_.m[2][0] * z,
    m_inv_.m[0][1] * x + m_inv_.m[1][1] * y + m_inv_.m[2][1] * z,
    m_inv_.m[0][2] * x + m_inv_.m[1][2] * y + m_inv_.m[2][2] * z);
}

void Transform::TransformNormal(const Vec3& n, Vec3* pNOut) const
{
  Float x = n.x, y = n.y, z = n.z;
  (*pNOut).x = m_inv_.m[0][0] * x + m_inv_.m[1][0] * y + m_inv_.m[2][0] * z;
  (*pNOut).y = m_inv_.m[0][1] * x + m_inv_.m[1][1] * y + m_inv_.m[2][1] * z;
  (*pNOut).z = m_inv_.m[0][2] * x + m_inv_.m[1][2] * y + m_inv_.m[2][2] * z;
}

Ray Transform::TransformRay(const Ray& r) const
{
  Vec3 dir, pos;
  TransformVector(r.d, &dir);
  TransformPoint(r.o, &pos);
  return Ray(dir, pos, r.t);
}

void Transform::TransformRay(const Ray& r, Ray* pROut) const
{
  Vec3 dir, pos;
  TransformVector(r.d, &dir);
  TransformPoint(r.o, &pos);
  *pROut = Ray(dir, pos, r.t);
}

AABB Transform::TransformAABB(const AABB& box) const
{
  AABB res; // start with empty result
  Vec3 corner;
  for (int i = 0; i < 8; ++i)
  {
    TransformPoint(box.Corner(i), &corner);
    res = res.Union(corner);
  }
  return res;
}

void Transform::TransformAABB(const AABB& box, AABB* pBOut) const
{
  AABB b = box; // copy to avoid the case where b and pBOut poInt to the same box
  *pBOut = AABB(); // clear the result
  for (int i = 0; i < 8; ++i)
  {
    *pBOut = pBOut->Union(TransformPoint(b.Corner(i)));
  }
}


///////////////////////////////////////////////////////////////////////////////
// create functions

Transform CreateTransform(const Vec3& scale, const Vec3& rot, const Vec3& pos)
{
  return
    CreateTranslate(pos) *
    CreateRotateXYZ(rot) *
    CreateScale(scale);;
}

Transform CreateTranslate(const Float x, const Float y, const Float z)
{
  return CreateTranslate(Vec3(x, y, z));
}

Transform CreateTranslate(const Vec3& a_offSet)
{
  Mat44 mat = Mat44(
    1.0f, 0.0f, 0.0f, a_offSet.x,
    0.0f, 1.0f, 0.0f, a_offSet.y,
    0.0f, 0.0f, 1.0f, a_offSet.z,
    0.0f, 0.0f, 0.0f, 1.0f);
  Mat44 matInv = Mat44(
    1.0f, 0.0f, 0.0f, -a_offSet.x,
    0.0f, 1.0f, 0.0f, -a_offSet.y,
    0.0f, 0.0f, 1.0f, -a_offSet.z,
    0.0f, 0.0f, 0.0f, 1.0f);
  return Transform(mat, matInv);
}

Transform CreateScale(const Float x, const Float y, const Float z)
{
  return CreateScale(Vec3(x, y, z));
}

Transform CreateScale(const Vec3& a_scale)
{
  Mat44 mat = Mat44(
    a_scale.x, 0.0f, 0.0f, 0.0f,
    0.0f, a_scale.y, 0.0f, 0.0f,
    0.0f, 0.0f, a_scale.z, 0.0f,
    0.0f, 0.0f, 0.0f, 1.0f);
  Mat44 matInv = Mat44(
    1.0f / a_scale.x, 0.0f, 0.0f, 0.0f,
    0.0f, 1.0f / a_scale.y, 0.0f, 0.0f,
    0.0f, 0.0f, 1.0f / a_scale.z, 0.0f,
    0.0f, 0.0f, 0.0f, 1.0f);
  return Transform(mat, matInv);
}

Transform CreateRotateX(Float degrees)
{
  Float a = Deg2Rad(degrees);
  Float s = Sin(a);
  Float c = Cos(a);

  Mat44 mat = Mat44(
    1.0f, 0.0f, 0.0f, 0.0f,
    0.0f, c, -s, 0.0f,
    0.0f, s, c, 0.0f,
    0.0f, 0.0f, 0.0f, 1.0f);
  return Transform(mat, Transpose(mat));
}

Transform CreateRotateY(Float degrees)
{
  Float a = Deg2Rad(degrees);
  Float s = Sin(a);
  Float c = Cos(a);

  Mat44 mat = Mat44(
    c, 0.0f, s, 0.0f,
    0.0f, 1.0f, 0.0f, 0.0f,
    -s, 0.0f, c, 0.0f,
    0.0f, 0.0f, 0.0f, 1.0f);
  return Transform(mat, Transpose(mat));
}

Transform CreateRotateZ(Float degrees)
{
  Float a = Deg2Rad(degrees);
  Float s = Sin(a);
  Float c = Cos(a);

  Mat44 mat = Mat44(
    c, -s, 0.0f, 0.0f,
    s, c, 0.0f, 0.0f,
    0.0f, 0.0f, 1.0f, 0.0f,
    0.0f, 0.0f, 0.0f, 1.0f);
  return Transform(mat, Transpose(mat));
}

Transform CreateRotateXYZ(const Float x, const Float y, const Float z)
{
  return CreateRotateXYZ(Vec3(x, y, z));
}

Transform CreateRotateXYZ(const Vec3& degrees)
{
  return CreateRotateX(degrees.x) * CreateRotateY(degrees.y) * CreateRotateZ(degrees.z);
}

Transform CreateAxisAngle(const Vec3& axis, Float degrees)
{
  Vec3 a = axis.Normalized();
  Float angle = Deg2Rad(degrees);
  Float s = Sin(angle);
  Float c = Cos(angle);
  Mat44 mat = Mat44();

  mat.m[0][0] = a.x * a.x + (1.0f - a.x * a.x) * c;
  mat.m[0][1] = a.x * a.y + (1.0f - c) - a.z  * s;
  mat.m[0][2] = a.x * a.z + (1.0f - c) + a.y  * s;

  mat.m[1][0] = a.x * a.y + (1.0f - c) - a.z  * s;
  mat.m[1][1] = a.y * a.y + (1.0f - a.y * a.y) * c;
  mat.m[1][2] = a.y * a.z + (1.0f - c) + a.x  * s;

  mat.m[2][0] = a.x * a.z + (1.0f - c) - a.z   * s;
  mat.m[2][1] = a.y * a.z + (1.0f - c) + a.y   * s;
  mat.m[2][2] = a.z * a.z + (1.0f - a.z * a.z) * c;

  return Transform(mat, Transpose(mat));
}
