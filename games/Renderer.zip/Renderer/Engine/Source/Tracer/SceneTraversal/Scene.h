#pragma once
#include "Utilities/Misc/Distribution1D.h"

#include <unordered_map>
#include <cassert>

class BVH;
class Triangle;
class Mesh;
class IMaterial;
class Model;
class Transform;
struct Ray;
struct Intersection;

/*
* Scene
*
*   The representation of the 3D scene. Manages resource data, 
*     model and material instances and scene intersection
*
*   Usage: call AddMesh() to add a mesh to the scene. You can then add
*     instances of this mesh by calling AddModel().
*
*     AddSphere() and AddDisk() are special versions of AddModel(), which add a sphere
*     and a disk respectively. No AddMesh() is necessary in this case.
*  
*     When all models have been added, call Accelerate() to build the BVH.
*     When this is done, intersect functions can be called.
*/

class Scene
{
public:
  Scene();
  ~Scene();

public:
  // add models to the scene
  Model* AddModel(const std::string& name, const Transform& m2w,
    IMaterial* mat);

  // add meshes to the scene
  bool HasMesh(const std::string& name) const;
  bool AddMesh(const std::string& name, Mesh* mesh);
  Mesh* GetMesh(const std::string& name) const;

  // add materials to the scene
  bool HasMat(const std::string& name) const;
  bool AddMat(const std::string& name, IMaterial* mat);
  IMaterial* GetMat(const std::string& name) const;

  // Constructs acceleration structure (BVH with SAH) and does other optimizations
  void Accelerate();
  
public:
  // intersection functions
  bool IntersectScene(Ray& ray, Intersection& hit) const;
  bool IntersectSceneShadow(Ray& ray) const;
  int32 IntersectSceneBVHDepth(Ray& ray, bool& intersectedMesh,
    int32& numPrimsIntersected, int32& numLeafNodes, int32& numBranchNodes) const;

  // shading utility functions
  const Model* GetUniformRandomLight() const;
  const Model* GetWeightedRandomLight() const;
  Float GetRandomHitOnLight(Intersection& hit) const; // returns the area of the light
  const std::vector<Model*>& GetAllLights() const;

public:
  // performance tracking utility functions
  int64 GetRayCount() const;
  void ResetRayCount() const;

private:
  // data management convenience function templates
  template <typename T>
  bool HasType(const std::unordered_map<std::string, T>& map, const std::string& name) const
  {
    auto res = map.find(name);
    return res != map.end();
  }
  template <typename T>
  bool AddType(std::unordered_map<std::string, T*>& map, const std::string& name, T* obj)
  {
    if (HasType(map, name) == false)
    {
      // constructs the MiniBVH in place
      std::pair<std::unordered_map<std::string, T*>::iterator, bool> new_element = map.emplace(std::make_pair(name, obj));
      assert(new_element.second == true);
      return true;
    }

    // else it already exists
    return false;
  }
  template <typename T>
  T* GetType(const std::unordered_map<std::string, T*>& map, const std::string& name) const
  {
    auto res = map.find(name);
    // return a nullptr if the map doesn't contain the requested object
    return (res != map.end()) ? res->second : nullptr;
  }

  // performance tracking utility function
  void IncrementRayCount() const;

private:
  // scene objects
  std::vector<Model*> models_;
  std::vector<Model*> lights_;

  // scene object data
  std::unordered_map<std::string, Mesh*> mesh_data_;
  std::unordered_map<std::string, IMaterial*> mat_data_;

  // precalculated shading info
  Distribution1D light_distribution_function_;
  Float sum_surface_area_light_;

  // scene accelaration object
  BVH* bvh_;

  // precalculated transformed triangles
  std::vector<Triangle> triangles_;

  // performance tracking struct
  struct RayCount
  {
    int64 count;
    char buff[256]; // to avoid false sharing in CPU cache
  };
  RayCount* rays_counts_; 
};