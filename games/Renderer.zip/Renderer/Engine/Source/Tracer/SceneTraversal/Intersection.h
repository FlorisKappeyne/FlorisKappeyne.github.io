#pragma once
#include "Utilities/Math/Vec3.h"
#include "Utilities/Math/Vec2.h"

class Primitive;
class IMaterial;

/**
* Intersection
*
*   a struct that holds the information needed to shade a point on a surface
*/

struct Intersection
{
  Intersection() {}
  Intersection(
    const Vec3& P, const Vec3& DPDU, const Vec3& DPDV,
    const Vec3& N, const Vec3& DNDU, const Vec3& DNDV, 
    const Vec2& UV, const Primitive* pPrim);
  Intersection(const Vec3& P, const Vec3& N, const Vec2& UV,
    const Primitive* pPrim);

public:
  // the primitive holds the material and other shading info
  const Primitive* prim;

  // UVs and derivatives
  Vec2 uv;
  Vec3 dpdu, dpdv; // vectors

  // normal and derivatives
  Vec3 n; // normal
  Vec3 dndu, dndv; // normals

  // point
  Vec3 p;
};
