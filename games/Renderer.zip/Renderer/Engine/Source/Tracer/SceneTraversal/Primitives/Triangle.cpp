#include "Triangle.h"
#include "SceneTraversal/Intersection.h"
#include "SceneTraversal/Transform.h"
#include "SceneTraversal/Ray.h"
#include "Utilities/Misc/RNG.h"
#include "Model.h"


///////////////////////////////////////////////////////////////////////////////
// class function

Triangle::Triangle(Vertex& v1, Vertex& v2, Vertex& v3)
  :
  m_verts{ v1, v2, v3 },
  pModel_(nullptr)
{}


///////////////////////////////////////////////////////////////////////////////
// intersection functions

bool Triangle::IntersectRay(Ray & a_ray, Intersection & hitInfo) const
{
  // easy point referenses
  const Vec3& p1 = m_verts[0].p;
  const Vec3& p2 = m_verts[1].p;
  const Vec3& p3 = m_verts[2].p;

  // calc data needed to compute barycentric coordinates
  Vec3 e1 = p2 - p1;
  Vec3 e2 = p3 - p1;
  Vec3 s1 = Cross(a_ray.d, e2);
  Float divisor = Dot(s1, e1);
  if (divisor == kZeroF)
  {
    return false;
  }
  Float invDivisor = kOneF / divisor;

  // compute first barycentric coordinate
  Vec3 s = a_ray.o - p1;
  Float b1 = Dot(s, s1) * invDivisor;
  if (b1 < kZeroF || b1 > kOneF)
  {
    return false;
  }

  // compute second barycentric coordinate
  Vec3 s2 = Cross(s, e1);
  Float b2 = Dot(a_ray.d, s2) * invDivisor;
  if (b2 < kZeroF || b1 + b2 > kOneF)
  {
    return false;
  }

  // compute t to hit
  Float t = Dot(e2, s2) * invDivisor;
  if (t < kZeroF || t > a_ray.t)
  {
    return false;
  }

  // a hit is now certain
  // find uvs
  Float uvs[3][2] = {
    { m_verts[0].uv.x, m_verts[0].uv.y },
    { m_verts[1].uv.x, m_verts[1].uv.y },
    { m_verts[2].uv.x, m_verts[2].uv.y } };

  Float b0 = kOneF - b1 - b2;
  Vec2 uv(
    b0 * uvs[0][0] + b1 * uvs[0][1] + b2 * uvs[2][0],
    b0 * uvs[0][1] * b1 * uvs[1][1] + b2 * uvs[2][1]);

  // find point and normal
  Vec3 p = m_verts[0].p * b0 + m_verts[1].p * b1 + m_verts[2].p * b2;
  Vec3 n = m_verts[0].n * b0 + m_verts[1].n * b1 + m_verts[2].n * b2;

  // fill intersection
  hitInfo = Intersection(p, n, uv, pModel_);

  // set ray's t
  a_ray.t = t;

  // happily return
  return true;
}

bool Triangle::IntersectShadow(Ray & a_ray) const
{
  // easy point references
  const Vec3& p1 = m_verts[0].p;
  const Vec3& p2 = m_verts[1].p;
  const Vec3& p3 = m_verts[2].p;

  // calc data needed to compute barycentric coordinates
  Vec3 e1 = p2 - p1;
  Vec3 e2 = p3 - p1;
  Vec3 s1 = Cross(a_ray.d, e2);
  Float divisor = Dot(s1, e1);
  if (divisor == kZeroF)
  {
    return false;
  }
  Float invDivisor = kOneF / divisor;

  // compute first barycentric coordinate
  Vec3 s = a_ray.o - p1;
  Float b1 = Dot(s, s1) * invDivisor;
  if (b1 < kZeroF || b1 > kOneF)
  {
    return false;
  }

  // compute second barycentric coordinate
  Vec3 s2 = Cross(s, e1);
  Float b2 = Dot(a_ray.d, s2) * invDivisor;
  if (b2 < kZeroF || b1 + b2 > kOneF)
  {
    return false;
  }

  // compute t to hit
  Float t = Dot(e2, s2) * invDivisor;
  if (t < kZeroF || t > a_ray.t)
  {
    return false;
  }
  return true;
}


///////////////////////////////////////////////////////////////////////////////
// shading utility function

void Triangle::GetRandomHitOnSurface(Intersection& hit) const
{
  // following this formula: https://math.stackexchange.com/questions/18686/uniform-random-point-in-triangle

  // random values
  Float
    sqR1 = Sqrt(rng::Float()),
    r2 = rng::Float();

  // return the random point
  hit.p =
    m_verts[0].p * sqR1 +
    m_verts[1].p * sqR1 * (kOneF - r2) +
    m_verts[2].p * sqR1 * r2;
  hit.n =
    m_verts[0].n * sqR1 +
    m_verts[1].n * sqR1 * (kOneF - r2) +
    m_verts[2].n * sqR1 * r2;
  hit.uv =
    m_verts[0].uv * sqR1 +
    m_verts[1].uv * sqR1 * (kOneF - r2) +
    m_verts[2].uv * sqR1 * r2;
}

Float Triangle::GetSurfaceArea() const
{
  return kHalfF * Cross(m_verts[1].p - m_verts[0].p, m_verts[2].p - m_verts[0].p).Magnitude();
}


///////////////////////////////////////////////////////////////////////////////
// utility function

AABB Triangle::GetAABB() const
{
  AABB aabb;
  aabb = AABB(m_verts[0].p, m_verts[1].p);
  aabb = aabb.Union(m_verts[2].p);
  return aabb;
}
