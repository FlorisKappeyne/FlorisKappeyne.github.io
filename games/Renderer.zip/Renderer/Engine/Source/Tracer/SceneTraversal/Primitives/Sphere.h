#pragma once
#include "Primitive.h"

/*
* Sphere - child of primitive
*
*   a spherical object with radius r
*
*   Surface area is in local space, not world, so avoid using scaling transforms
*/

class Sphere : public Primitive
{
public:
  Sphere(const std::string& name, const Transform& p2w, IMaterial* mat, Float radius);

  // intersection functions
  bool IntersectRay(Ray& a_ray, Intersection& hitInfo) const override;
  bool IntersectShadow(Ray& a_ray) const override;
  int32 IntersectDepth(Ray& ray, int32 depth) const override;

  // utility functions
  void GetRandomHitOnSurface(Intersection& hit) const override;
  Float GetSurfaceArea() const override;

private:
  void CalcAABB() override;

public:
  // radius
	Float r_;
};
