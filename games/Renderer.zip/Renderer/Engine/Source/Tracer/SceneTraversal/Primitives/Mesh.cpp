#include "Mesh.h"
#include "Triangle.h"
#include "Utilities/Misc/RNG.h"


///////////////////////////////////////////////////////////////////////////////
// class function

Mesh::Mesh(const std::string & name, const std::vector<Triangle>& triangles)
  :
  name_(name),
  triangles_(triangles),
  bvh_(triangles_)
{
  // allocate memory for the areas
  const size_t triangle_count = triangles_.size();
  std::vector<Float> areas;
  areas.reserve(triangle_count);

  // calcluate the area of each triangle and store it
  for (size_t i = 0; i < triangle_count; ++i)
  {
    Float area = triangles_[i].GetSurfaceArea();
    areas.push_back(area);
  }

  // instantiate the distribution function using this information
  area_distribution_function_.Init(areas.data(), triangle_count);
}


///////////////////////////////////////////////////////////////////////////////
// intersection functions

bool Mesh::IntersectRay(Ray& ray, Intersection& hitInfo) const
{
  return bvh_.Intersect(ray, hitInfo);
}

bool Mesh::IntersectShadow(Ray& ray) const
{
  return bvh_.IntersectShadow(ray);
}

int32 Mesh::IntersectDepth(Ray& r, int32 depth)
{
  return bvh_.IntersectDepth(r, depth);
}


///////////////////////////////////////////////////////////////////////////////
// utility functions

const AABB& Mesh::GetAABB()
{
  return bvh_.GetAABB();
}
const std::vector<Triangle>& Mesh::GetTriangles()
{
  return triangles_;
}


///////////////////////////////////////////////////////////////////////////////
// shading utility function

void Mesh::GetRandomHitOnSurface(Intersection & hit) const
{
  Float pdf, u_remapped;

  // get a random triangle from the mesh (sampled uniformly based on surface area)
  size_t idx = area_distribution_function_.SampleDiscrete(rng::Float(), &pdf, &u_remapped);

  // get a random hit from the triangle
  triangles_[idx].GetRandomHitOnSurface(hit);
}
