#include "Disk.h"
#include "SceneTraversal/Intersection.h"
#include "SceneTraversal/Transform.h"
#include "SceneTraversal/Ray.h"
#include "Utilities/MonteCarloUtilities.h"

#include <assert.h>


///////////////////////////////////////////////////////////////////////////////
// class function

Disk::Disk(const std::string& name, const Transform& p2w,
  IMaterial* mat, Float in_radius, Float out_radius)
  :
  Primitive(name, p2w, mat, Type::DISK),
  r_in_(in_radius),
  r_out_(out_radius)
{
  CalcAABB();
}


///////////////////////////////////////////////////////////////////////////////
// intersection functions

bool Disk::IntersectRay(Ray& a_ray, Intersection& hitInfo) const
{
  // transform ray
  Ray r;
  p2w_.GetInverse().TransformRay(a_ray, &r);
  if (r.d.z < kEpsilon && r.d.z > -kEpsilon)
  {
    return false;
  }

  // Intersect the ray with the plane (since the disk is on 0.0f, 0.0f, 0.0f 
  // and it's normal is the z axis, we can optimize the shit out of this)
  Float tHit = -r.o.z / r.d.z;
  if (tHit < kZeroF || tHit > a_ray.t)
  {
    return false;
  }

  // if there's a hit (and there almost always is), test if the poInt is within the radii
  Vec3 pHit = r.o + r.d * tHit;
  Float sqDist = pHit.x * pHit.x + pHit.y * pHit.y;
  Float outRSqr, inRSqr;
  outRSqr = r_out_ * r_out_;
  inRSqr = r_in_ * r_in_;
  if (sqDist > outRSqr || sqDist < inRSqr)
  {
    return false;
  }

  Vec2 uv = Vec2(
    (pHit.x / r_out_ + kOneF) * kHalfF,
    (pHit.y / r_out_ + kOneF) * kHalfF);

  // set original ray's t
  a_ray.t = tHit;

  // fill in Intersection with fast but bullshit values
  hitInfo = Intersection(a_ray.d * a_ray.t + a_ray.o,
    p2w_.TransformNormal(Vec3(kZeroF, kZeroF, kOneF)), uv, this);

  return true;
}

bool Disk::IntersectShadow(Ray & a_ray) const
{
  Ray r;
  p2w_.GetInverse().TransformRay(a_ray, &r);
  if (r.d.z < kEpsilon && r.d.z > -kEpsilon)
  {
    return false;
  }
  Float tHit = -r.o.z / r.d.z;
  if (tHit < kZeroF || tHit > a_ray.t)
  {
    return false;
  }
  Vec3 pHit = r.o + r.d * tHit;
  Float sqDist = pHit.x * pHit.x + pHit.y * pHit.y;
  Float outRSqr, inRSqr;
  outRSqr = r_out_ * r_out_;
  inRSqr = r_in_ * r_in_;
  if (sqDist > outRSqr || sqDist < inRSqr)
  {
    return false;
  }
  return true;
}

int32 Disk::IntersectDepth(Ray & ray, int32 depth) const
{
  assert(false && "depth test called on disk");
  return 0;
}


///////////////////////////////////////////////////////////////////////////////
// shading utility functions

void Disk::GetRandomHitOnSurface(Intersection& hit) const
{
  Vec2 random_point = UniformSampleDisk(Vec2(rng::Float(), rng::Float()));
  Vec2 dir = random_point.Normalized();
  random_point *= r_out_ - r_in_; // move the point to a place in between the in and out radius
  random_point += dir * r_in_; // move the point beyond the in radius
  Vec3 res = Vec3(random_point.x, random_point.y, kZeroF);

  // fill in hit
  p2w_.TransformPoint(res, &hit.p);
  p2w_.TransformNormal(Vec3(kZeroF, kZeroF, kOneF), &hit.n);
  hit.uv = Vec2(
    (res.x / r_out_ + kOneF) * kHalfF,
    (res.y / r_out_ + kOneF) * kHalfF);
  hit.prim = this;
}

Float Disk::GetSurfaceArea() const
{
  return kPi * (r_out_ * r_out_ - r_in_ * r_in_);
}


///////////////////////////////////////////////////////////////////////////////
// utility function

void Disk::CalcAABB()
{
  aabb_.min = Vec3(-r_out_, -r_out_, kZeroF);
  aabb_.max = Vec3(r_out_, r_out_, kZeroF);
  p2w_.TransformAABB(aabb_, &aabb_);
}