#pragma once
#include "Utilities/Math/Vec2.h"
#include "SceneTraversal/AABB.h"

class Model;
struct Ray;
struct Intersection;

/**
* Triangle
*
*   a plane between 3 points in 3d space. A mesh consists of a set of triangles.
*   
*   not a primitive, because giving each triangle a transform, 
*   material etc. would be a waste of memory. In that case, make
*   a mesh with only one triangle.  
*/

class Triangle
{
public:
  // a vertex represents a point of a model. It has a position, normal and uv coordinate
	struct Vertex
	{
		Vec3 p;
		Vec3 n;
		Vec2 uv;
	};

public:
  Triangle(Vertex& v1, Vertex& v2, Vertex& v3);

  // intersection functions
	bool IntersectRay(Ray& a_ray, Intersection& hitInfo) const;
	bool IntersectShadow(Ray& a_ray) const;

  // shading utility function
  void GetRandomHitOnSurface(Intersection& hit) const;
	Float GetSurfaceArea() const;

  // utility function
	AABB GetAABB() const;

public:
  // vertices
	Vertex m_verts[3];

  // a reference to the model that owns this triangle
  Model* pModel_;
};
