#pragma once
#include "Primitive.h"
#include "Utilities/Misc/Distribution1D.h"

class Mesh;
class Triangle;

/**
* Model, a child of the Primitive class
*
*   A model is an instance of a mesh placed in the scene*
*/

class Model : public Primitive
{
public:
	Model(const std::string& name, const Transform& p2w,
    IMaterial* mat, Mesh* mesh);

  // intersection functions
	bool IntersectRay(Ray& ray, Intersection& hitInfo) const override;
	bool IntersectShadow(Ray& ray) const override;
  int32 IntersectDepth(Ray& ray, int32 depth) const override;

  // utility functions
  void GetRandomHitOnSurface(Intersection& hit) const override;
	Float GetSurfaceArea() const override;
  std::vector<Triangle> GetTransformedTriangles();

private:
  // utility functions
  void CalcAABB() override;
	void CalcSurfaceArea();

private:
  // the mesh this model is an instance of
  Mesh* mesh_;

  // precalculated shading information (area of mesh triangles_ in world space)
  Float surface_area_total_;
  Distribution1D area_distribution_function_;
};
