#pragma once
#include "SceneTraversal/AABB.h"
#include "SceneTraversal/Transform.h"

#include <string>

class IMaterial;
struct Intersection;
struct Ray;

/*
* Primitive
*
*   the base class of objects that can be placed in the scene.
*
*   each primitive has a name, transform, a material and an AABB
*   and can be intersected by a ray
*/

class Primitive
{
public:
  enum class Type
  {
    SPHERE,
    DISK,
    MODEL
  };

public:
  Primitive(const std::string& name, const Transform& p2w, IMaterial* mat, Type type)
    :
    name_(name),
    p2w_(p2w),
    mat_(mat),
    type_(type)
  {}

  // intersection functions
  virtual bool IntersectRay(Ray& ray, Intersection& hit) const = 0;
  virtual bool IntersectShadow(Ray& ray) const = 0;
  virtual int32 IntersectDepth(Ray& ray, int32 depth) const = 0;

  // utilities
  virtual void GetRandomHitOnSurface(Intersection& hit) const = 0;
  virtual Float GetSurfaceArea() const = 0;

protected:
  virtual void CalcAABB() = 0;

public:
  std::string name_;
  Transform p2w_;
  IMaterial* mat_;
  AABB aabb_;
  Type type_;
};
