#include "Sphere.h"
#include "SceneTraversal/Intersection.h"
#include "SceneTraversal/Transform.h"
#include "SceneTraversal/Ray.h"
#include "Utilities/MonteCarloUtilities.h"

#include <assert.h>


///////////////////////////////////////////////////////////////////////////////
// class function

Sphere::Sphere(const std::string& name, const Transform& p2w, IMaterial* mat, Float radius)
  :
  Primitive(name, p2w, mat, Type::SPHERE),
  r_(radius)
{
  CalcAABB();
}


///////////////////////////////////////////////////////////////////////////////
// intersection functions

bool Sphere::IntersectRay(Ray& a_ray, Intersection& hitInfo) const
{
  // transform the ray to object space
  Ray r;
  p2w_.GetInverse().TransformRay(a_ray, &r);

  // calculate the possible t values using the power of math
  Float A = Dot(r.d, r.d);
  Float B = kTwoF * (r.d.x * r.o.x + r.d.y * r.o.y + r.d.z * r.o.z);
  Float C = Dot(r.o, r.o) - r_ * r_;
  Float t0, t1;

  // if the equation can't be solved there's no solution
  if (SolveQuadratic(A, B, C, &t0, &t1) == false)
  {
    return false;
  }

  // see if the hits are within range
  if (t0 > r.t || t1 < kZeroF)
  {
    return false;
  }

  // find the closest hit
  Float hit_t = t0;
  if (hit_t < kZeroF)
  {
    hit_t = t1;
    // if this hit is closer than the current ray length, the hit is valid
    if (hit_t > r.t)
    {
      return false;
    }
  }

  // now a hit is certain. calculate UV and other necessary data
  Vec3 hit_pos = r.d * hit_t + r.o;

  // calculate angle phi
  Float max_phi = kTwoPi;
  if (hit_pos.x == kZeroF && hit_pos.y == kZeroF)
  {
    hit_pos.x = kEpsilon;
  }
  Float phi = Atan2(hit_pos.y, hit_pos.x);
  if (phi < kZeroF)
  {
    phi += kTwoPi;
  }

  // calculate UV using angles phi and theta
  Float u = phi / max_phi;
  Float theta = ACos(Clamp(hit_pos.z / r_, -kOneF, kOneF));
  Float v = (theta - kPi) / -kPi;

  // set the ray's t value
  a_ray.t = hit_t;

  // fill in the intersection
  hitInfo = Intersection(a_ray.d * a_ray.t + a_ray.o,
    p2w_.TransformNormal(hit_pos).Normalized(),
    Vec2(kZeroF), this);

  return true;
}

bool Sphere::IntersectShadow(Ray & a_ray) const
{
  // transform the ray to object space
  Ray r;
  p2w_.GetInverse().TransformRay(a_ray, &r);

  // calculate the possible t values using the power of math
  Float A = Dot(r.d, r.d);
  Float B = kTwoF * (r.d.x * r.o.x + r.d.y * r.o.y + r.d.z * r.o.z);
  Float C = Dot(r.o, r.o) - r_ * r_;
  Float t0, t1;

  // solve the equation. If there are no solutions, return false
  if (SolveQuadratic(A, B, C, &t0, &t1) == false)
  {
    return false;
  }

  // use the found t values to determine the closest possible hit
  if (t0 > r.t || t1 < kZeroF)
  {
    return false;
  }
  Float tHit = t0;
  if (tHit < kZeroF)
  {
    tHit = t1;
    if (tHit > r.t)
    {
      return false;
    }
  }

  // if there was a hit greater than 0 and smaller than 
  // the ray's t value, there was a hit
  return true;
}

int32 Sphere::IntersectDepth(Ray & ray, int32 depth) const
{
  assert(false && "depth test called on non bvh entity");
  return 0;
}


///////////////////////////////////////////////////////////////////////////////
// shading utility function

void Sphere::GetRandomHitOnSurface(Intersection& hit) const
{
  // get a random point on the unit spheres
  Vec3 random_point = UniformSampleSphere(Vec2(rng::Float(), rng::Float()));

  // pos and normal
  p2w_.TransformPoint(random_point, &hit.p);
  p2w_.TransformNormal(random_point, &hit.n);
  hit.n = hit.n.Normalized();

  // calculate uv using angles phi and theta
  Float phiMax = kTwoPi;
  if (random_point.x == kZeroF && random_point.y == kZeroF)
  {
    random_point.x = kEpsilon;
  }
  Float phi = Atan2(random_point.y, random_point.x);
  if (phi < kZeroF)
  {
    phi += kTwoPi;
  }

  Float u = phi / phiMax;
  Float theta = ACos(Clamp(random_point.z / r_, -kOneF, kOneF));
  Float v = (theta - kPi) / -kPi;
  hit.uv = Vec2(u, v);

  // last of the data
  hit.prim = this;
}

Float Sphere::GetSurfaceArea() const
{
  return kTwoF * kTwoF * kPi * r_ * r_;
}


///////////////////////////////////////////////////////////////////////////////
// private utility function

void Sphere::CalcAABB()
{
  Vec3 rad = Vec3(r_);
  aabb_ = AABB(rad, -rad);
  p2w_.TransformAABB(aabb_, &aabb_);
}