#pragma once
#include "SceneTraversal/BVH/BVH.h"
#include "Utilities/Misc/Distribution1D.h"

class Triangle;

/**
* Mesh
*  A mesh is a set of triangles
*
*  besides just triangles, a Mesh has a BVH around those triangles,
*  and the areas of that triangle in a distribution function
*  (which is useful for shading)
*/

class Mesh
{
public:
  Mesh(const std::string& name, const std::vector<Triangle>& triangles_);

  // intersection functions
  bool IntersectRay(Ray& ray, Intersection& hitInfo) const;
  bool IntersectShadow(Ray& ray) const;
  int32 IntersectDepth(Ray& r, int32 depth);

  // utility functions
  const AABB& GetAABB();
  const std::vector<Triangle>& GetTriangles();
  void GetRandomHitOnSurface(Intersection& hit) const;

private:
  // this mesh's name
  std::string name_;

  // the list of triangles
  std::vector<Triangle> triangles_;

  // precalculated shading info
  Distribution1D area_distribution_function_;

  // precalculated BVH, which is handy when building a TopLevelBVH
  BVH bvh_;
};

