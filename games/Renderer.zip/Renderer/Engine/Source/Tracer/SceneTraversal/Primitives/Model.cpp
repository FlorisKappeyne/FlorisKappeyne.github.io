#include "Mesh.h"
#include "SceneTraversal/Primitives/Triangle.h"
#include "SceneTraversal/Primitives/Model.h"
#include "SceneTraversal/Intersection.h"
#include "SceneTraversal/Transform.h"
#include "SceneTraversal/Ray.h"
#include "SceneTraversal/BVH/BVHNode.h"

#include <assert.h>


///////////////////////////////////////////////////////////////////////////////
// class function

Model::Model(const std::string& name, const Transform& p2w,
  IMaterial* mat, Mesh* mesh)
  :
  Primitive(name, p2w, mat, Type::MODEL),
  mesh_(mesh)
{
	CalcAABB();
	CalcSurfaceArea();
}


///////////////////////////////////////////////////////////////////////////////
// intersection functions

bool Model::IntersectRay(Ray& ray, Intersection& hitInfo) const
{
	Ray r;
	p2w_.GetInverse().TransformRay(ray, &r);
	bool hit = mesh_->IntersectRay(r, hitInfo);

	if (hit)
	{ 
    ray.t = r.t;
		hitInfo.prim = this;
    hitInfo.p = ray.d * ray.t + ray.o;

    // transform back to world space
    p2w_.TransformNormal(hitInfo.n, &hitInfo.n);

    // because the normal might have been affected by the scale
    hitInfo.n = hitInfo.n.Normalized();

		return true;
	}
	return false;
}

bool Model::IntersectShadow(Ray& ray) const
{
	Ray r;
	p2w_.GetInverse().TransformRay(ray, &r);
	return mesh_->IntersectShadow(r);
}

int32 Model::IntersectDepth(Ray& ray, int32 depth) const
{
  Ray r;
  p2w_.GetInverse().TransformRay(ray, &r);
  return mesh_->IntersectDepth(r, depth);
}


///////////////////////////////////////////////////////////////////////////////
// Shading utility functions

void Model::GetRandomHitOnSurface(Intersection& hit) const
{
  // get a random hit
  mesh_->GetRandomHitOnSurface(hit);

  // transform hit to world space
  p2w_.TransformPoint(hit.p, &hit.p);
  p2w_.TransformNormal(hit.n, &hit.n);
  hit.n = hit.n.Normalized();
  hit.prim = this;
}

Float Model::GetSurfaceArea() const
{
	return surface_area_total_;
}


///////////////////////////////////////////////////////////////////////////////
// utility function
std::vector<Triangle> Model::GetTransformedTriangles()
{
  const std::vector<Triangle>& tris = mesh_->GetTriangles();
  const size_t nTris = tris.size();

  std::vector<Triangle> res;
  res.reserve(nTris);

  for (size_t i = 0; i < nTris; ++i)
  {
    res.push_back(tris[i]);
    for (int j = 0; j < 3; ++j)
    {
      p2w_.TransformPoint(res[i].m_verts[j].p, &res[i].m_verts[j].p);
      p2w_.TransformNormal(res[i].m_verts[j].n, &res[i].m_verts[j].n);
      res[i].m_verts[j].n = res[i].m_verts[j].n.Normalized();
    }
  }
  return res;
}


///////////////////////////////////////////////////////////////////////////////
// private utility functions

void Model::CalcAABB()
{
  aabb_ = p2w_.TransformAABB(mesh_->GetAABB());
}

void Model::CalcSurfaceArea()
{
	surface_area_total_ = kZeroF;
  const std::vector<Triangle>& tris = mesh_->GetTriangles();

	const size_t nTris = tris.size();
  std::vector<Float> areas;
  areas.reserve(nTris);

	for (size_t i = 0; i < nTris; ++i)
	{
		Triangle transTri(tris[i]);
		for (int j = 0; j < 3; ++j)
		{
			p2w_.TransformPoint(transTri.m_verts[j].p, &transTri.m_verts[j].p);
		}
    Float area = transTri.GetSurfaceArea();
		surface_area_total_ += area;
    areas.push_back(area);
	}

  area_distribution_function_.Init(areas.data(), nTris);
}
