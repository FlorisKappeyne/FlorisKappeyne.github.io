#pragma once
#include "Primitive.h"

/*
* Disk - child of primitive
*
*   a disk shaped object (2d sphere) with radius r_out_
*   with a hole in the centre with radius r_in_
*
*   Surface area is in local space, not world, so avoid using scaling transforms
*/

class Disk : public Primitive
{
public:
  Disk(const std::string& name, const Transform& p2w, 
    IMaterial* mat, Float in_radius, Float out_radius);

  // intersection functions
	bool IntersectRay(Ray& ray, Intersection& hitInfo) const override;
	bool IntersectShadow(Ray& ray) const override;
  int32 IntersectDepth(Ray& ray, int32 depth) const override;

  // shading utility functions
  void GetRandomHitOnSurface(Intersection& hit) const override;
	Float GetSurfaceArea() const override;

private:
  // utility function
  void CalcAABB() override;

private:
  // the inner and outer radius
	Float r_in_;
	Float r_out_;
};

