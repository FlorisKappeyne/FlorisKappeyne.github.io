#include "BVH.h"
#include "BVHNode.h"
#include "SceneTraversal/Ray.h"
#include "SceneTraversal/AABB.h"
#include "SceneTraversal/Primitives/Triangle.h"

#include <algorithm>
#include <assert.h>
#include <string>


///////////////////////////////////////////////////////////////////////////////
// class functions

BVH::BVH(std::vector<Triangle>& prims)
  :
  triangles_(prims)
{
  // store usable info for easy reference
  std::vector<BVHPrimInfo> prim_info(triangles_.size());
  for (size_t i = 0; i < triangles_.size(); ++i)
  {
    prim_info[i] = BVHPrimInfo(Int(i), triangles_[i].GetAABB());
  }

  // build tree using temporary build structs
  BVHNode* build_nodes = new BVHNode[triangles_.size() * 2 - 1];
  std::vector<Triangle> ordered_primitives;
  node_count_ = 0;

  ordered_primitives.reserve(triangles_.size());

  // build the tree
  RecursiveBuild(prim_info, &node_count_, 0, (int32)triangles_.size(), build_nodes, ordered_primitives);

  // store the sorted primitives
  triangles_.swap(ordered_primitives);

  // optimize tree. First node is the root_ node
  root_ = (BVHNode*)_aligned_malloc(sizeof(BVHNode) * node_count_, 64);

  memcpy(root_, build_nodes, node_count_ * sizeof(BVHNode));

  // clear allocated build data
  delete[] build_nodes;

#ifdef _DEBUG
  int32 node_size = static_cast<int32>(sizeof(BVHNode));
  assert(IsPowerOf2(node_size));

  Int number_of_prims = 0, number_of_nodes = 0, max_depth = 0;
  bool res = VerifyBVH(number_of_prims, number_of_nodes, max_depth);
#endif
}

BVH::BVH(const BVH & rhs)
  :
  triangles_(rhs.triangles_),
  root_((BVHNode*)_aligned_malloc(rhs.node_count_ * sizeof(BVHNode), 64)),
  node_count_(rhs.node_count_)
{
  memcpy(root_, rhs.root_, node_count_ * sizeof(BVHNode));
}

BVH::BVH(BVH && rhs) noexcept
  :
triangles_(std::move(rhs.triangles_)),
node_count_(rhs.node_count_),
root_(rhs.root_)
{
  rhs.node_count_ = 0;
  rhs.root_ = nullptr;
}

BVH::~BVH()
{
  if (root_ == nullptr)
  {
    return;
  }
  _aligned_free(root_);
}


///////////////////////////////////////////////////////////////////////////////
// intersection functions

bool BVH::Intersect(Ray & ray, Intersection & hit) const
{
  assert(root_ != nullptr);
  bool hit_something = false;
  int32 to_visit_offset = 0, cur_node_idx = 0;
  int32 nodes_to_visit[64];

  while (true)
  {
    const BVHNode* node = &root_[cur_node_idx];
    if (node->Intersect(ray))
    {
      if (node->count > 0) // leaf node
      {
        // do intersection tests on the primitives inside the node
        const Int lastPrim = node->first_right + node->count;
        for (Int i = node->first_right; i < lastPrim; ++i)
        {
          if (triangles_[i].IntersectRay(ray, hit))
          {
            hit_something = true;
          }
        }
        if (to_visit_offset == 0)
        {
          break;
        }
        cur_node_idx = nodes_to_visit[--to_visit_offset];
      }
      else // interior node
      {
        if (ray.dir_is_neg[node->split_axis])
        {
          nodes_to_visit[to_visit_offset++] = cur_node_idx + 1;
          cur_node_idx = (int32)node->first_right;
        }
        else
        {
          cur_node_idx = cur_node_idx + 1;
          nodes_to_visit[to_visit_offset++] = (int32)node->first_right;
        }
      }
    }
    else
    {
      if (to_visit_offset == 0)
      {
        break;
      }
      cur_node_idx = nodes_to_visit[--to_visit_offset];
    }
  }
  return hit_something;
}

bool BVH::IntersectShadow(Ray & ray) const
{
  assert(root_ != nullptr);
  int32 to_visit_offset = 0, cur_node_idx = 0;
  int32 nodes_to_visit[64];

  while (true)
  {
    const BVHNode* node = &root_[cur_node_idx];
    if (node->Intersect(ray))
    {
      if (node->count > 0) // leaf node
      {
        // do intersection tests on the primitives inside the node
        const Int lastPrim = node->first_right + node->count;
        for (Int i = node->first_right; i < lastPrim; ++i)
        {
          if (triangles_[i].IntersectShadow(ray))
          {
            return true;
          }
        }
        if (to_visit_offset == 0)
        {
          break;
        }
        cur_node_idx = nodes_to_visit[--to_visit_offset];
      }
      else // interior node
      {
        if (ray.dir_is_neg[node->split_axis])
        {
          nodes_to_visit[to_visit_offset++] = cur_node_idx + 1;
          cur_node_idx = (int32)node->first_right;
        }
        else
        {
          cur_node_idx = cur_node_idx + 1;
          nodes_to_visit[to_visit_offset++] = (int32)node->first_right;
        }
      }
    }
    else
    {
      if (to_visit_offset == 0)
      {
        break;
      }
      cur_node_idx = nodes_to_visit[--to_visit_offset];
    }
  }
  return false;
}

int32 BVH::IntersectDepth(Ray & ray, int32 depth)
{
  assert(root_ != nullptr);
  int32 max_depth = depth;
  int32 to_visit_offset = 0, cur_node_idx = 0;
  int32 nodes_to_visit[64];

  while (true)
  {
    const BVHNode* node = &root_[cur_node_idx];
    if (node->Intersect(ray))
    {
      if (node->count > 0) // leaf node
      {
        int32 cur_depth = (depth + to_visit_offset);
        max_depth = cur_depth > max_depth ? cur_depth : max_depth;

        if (to_visit_offset == 0)
        {
          break;
        }
        cur_node_idx = nodes_to_visit[--to_visit_offset];
      }
      else // interior node
      {
        if (ray.dir_is_neg[node->split_axis])
        {
          nodes_to_visit[to_visit_offset++] = cur_node_idx + 1;
          cur_node_idx = (int32)node->first_right;
        }
        else
        {
          cur_node_idx = cur_node_idx + 1;
          nodes_to_visit[to_visit_offset++] = (int32)node->first_right;
        }
      }
    }
    else
    {
      if (to_visit_offset == 0)
      {
        break;
      }
      cur_node_idx = nodes_to_visit[--to_visit_offset];
    }
  }
  return max_depth;
}


///////////////////////////////////////////////////////////////////////////////
// get AABB function, used when creating a BVH of BVHs

const AABB& BVH::GetAABB()
{
  return root_->aabb;
}


///////////////////////////////////////////////////////////////////////////////
// The recursive build function

size_t BVH::RecursiveBuild(std::vector<BVHPrimInfo>& prim_info, size_t* node_count,
  int32 start, int32 end, BVHNode* node_pool, std::vector <Triangle>& ordered_prims)
{
  // get the first free node, increment total nodes counter to indicate that the spot is taken
  size_t node_idx = *node_count;
  BVHNode* node = &node_pool[*node_count];
  (*node_count)++;

  // get the split point
  Int prim_count = end - start;
  int32 split_point = (start + end) / 2;

  // get the total AABB
  for (int32 i = start; i < end; ++i)
  {
    node->aabb = prim_info[i].aabb.Union(node->aabb);
  }

  // if you still have enough primitives
  if (prim_count > kPrimsNeededForSAH)
  {
    ///////////////////////////////////////////////////////////////////////////
    // create a branch node
    ///////////////////////////////////////////////////////////////////////////

    // find centre bounds
    AABB centre_bounds;
    for (int32 i = start; i < end; ++i)
    {
      centre_bounds = centre_bounds.Union(prim_info[i].centre);
    }

    // choose split dimension
    int32 best_dim = centre_bounds.MaxExtent();

    // check for broken scene (duplicate triangles)
    if (centre_bounds.max[best_dim] == centre_bounds.min[best_dim])
    {
      // all prims are at the same position, create a leaf node
      // fill in data
      node->count = (HalfInt)prim_count;
      node->split_axis = 3;
      node->first_right = (Int)ordered_prims.size();

      // find your primitives and place it in the ordered prim list
      for (int32 i = start; i < end; ++i)
      {
        ordered_prims.push_back(triangles_[prim_info[i].idx]);
      }

      // sadly return
      return node_idx;
    }

    // set up for binned SAH
    const int32 bucket_count = 
      kTotBuckets < (int32)prim_count ? kTotBuckets : (int32)prim_count;
    Float lowest_cost = INFINITY;

    // find the minimum cost for each dimension
    for (uint32 dim = 0; dim < 3; ++dim)
    {
      // sort primitives from left to right on the current axis
      std::sort(&prim_info[start], &prim_info[end - 1] + 1,
        [dim](const BVHPrimInfo& a, const BVHPrimInfo& b)
      {
        return a.centre[dim] < b.centre[dim];
      });

      // get buckets
      struct BucketInfo
      {
        int32 count = 0;
        AABB aabb;
      };
      BucketInfo buckets[kTotBuckets];

      // initialize buckets
      for (int32 i = start; i < end; ++i)
      {
        // find the bucket this prim belongs in
        int32 b = int32(Float(bucket_count) * centre_bounds.Offset(prim_info[i].centre)[dim]);
        b = (b == bucket_count) ? b - 1 : b;

        // add the primitive's aabb to the bucket's
        buckets[b].count++;
        buckets[b].aabb = buckets[b].aabb.Union(prim_info[i].aabb);
      }

      // find the splitpoint with the lowest cost
      for (int32 i = 0; i < bucket_count - 1; ++i)
      {
        AABB aabb0, aabb1;
        int32 count0 = 0, count1 = 0;

        for (int32 j = 0; j <= i; ++j)
        {
          aabb0 = aabb0.Union(buckets[j].aabb);
          count0 += buckets[j].count;
        }
        for (int32 j = i + 1; j < bucket_count; ++j)
        {
          aabb1 = aabb1.Union(buckets[j].aabb);
          count1 += buckets[j].count;
        }

        // cost formula based on the cost of intersecting 
        /*
        * C = Ct + (Pa * Nia * Ci) + (Pb * Nib * Ci)
        *
        * where C is cost, Ct is the cost for traversing a node,
        * Pa and Pb are the probabilities of intersecting volume a
        * and volume b (a and b are the volume of the node's possible
        * children), Nia and Nib are the number of possible intersections
        * in the volume and Ci is the cost of intersecting
        *
        * I define Ct as relative to Ci so that Ci can be one (i.e.
        * if one intersection is about 0.3 node traversal, then Ct = 0.3
        * and Ci = 1 (effectively dividing the cost by Ci, which doesn't
        * matter since Ci is a constant and C is relative)
        *
        * Pa = SA(a) / SA(v) and Pb = SA(b) / SA(v)
        * where SA() is the surface area of the volume,
        * and v is the volume of the node around a and b
        * therefore, plugging in Pa, Pb and Ci = 1
        * C = Ct + (SA(a) * Nia + SA(b) * Nib) / SA(v)
        */
        Float Ct = Float(0.3);

        // handle the situation where one of the bins is empty
        Float c0aabb0 = count0 * aabb0.SurfaceArea();
        c0aabb0 = c0aabb0 > 0 ? c0aabb0 : 0;
        Float c1aabb1 = count1 * aabb1.SurfaceArea();
        c1aabb1 = c1aabb1 > 0 ? c1aabb1 : 0;

        // calculate cost
        Float cost = Ct + 
          (c0aabb0 + c1aabb1) /
          node->aabb.SurfaceArea();

        // keep track of lowest cost, and update best_dim and the new split_point
        if (cost < lowest_cost)
        {
          lowest_cost = cost;
          best_dim = dim;
          split_point = start + count0;
        }
      }
    }

    // split the primitives
    Float leafCost = Float(prim_count);
    if (lowest_cost < leafCost)
    {
      // sort the primitives. If the z axis is the best dim, it's already sorted
      if (best_dim < 2)
      {
        // sort the elements efficiently
        std::nth_element(&prim_info[start], &prim_info[split_point], &prim_info[end - 1] + 1,
          [best_dim](const BVHPrimInfo& a, const BVHPrimInfo& b)
        {
          return a.centre[best_dim] < b.centre[best_dim];
        });
      }
    }
    else
    {
      // fill in data
      node->count = (HalfInt)prim_count;
      node->first_right = (Int)ordered_prims.size();

      // add the prims to the ordered_prims vec
      for (int32 i = start; i < end; ++i)
      {
        int32 primNum = (int32)prim_info[i].idx;
        ordered_prims.push_back(triangles_[primNum]);
      }
      return node_idx;
    }

    // recursively build children
    RecursiveBuild(prim_info, node_count, start, split_point, node_pool, ordered_prims);
    int32 childIdx = (int32)RecursiveBuild(prim_info, node_count, split_point, end, node_pool, ordered_prims);

    // set node data
    node->count = 0;
    node->split_axis = best_dim;
    node->first_right = childIdx;
  }
  else // if you don't have enough primitives
  {
    ///////////////////////////////////////////////////////////////////////////
    // create a leaf node
    ///////////////////////////////////////////////////////////////////////////

    // fill in data
    node->count = (HalfInt)prim_count;
    node->split_axis = 4;
    node->first_right = (Int)ordered_prims.size();

    // add the prims to the orderedprims vec
    for (int32 i = start; i < end; ++i)
    {
      int32 prim_idx = (int32)prim_info[i].idx;
      ordered_prims.push_back(triangles_[prim_idx]);
    }
  }

  // return your node
  return node_idx;
}


///////////////////////////////////////////////////////////////////////////////
// Debug functions

bool BVH::VerifyBVH(Int& numPrimitives, Int& numNodes, Int& maxDepth)
{
  numPrimitives = 0, maxDepth = 0;
  Int depth = 0;
  return VerifyNodes(root_, numNodes, maxDepth, depth, numPrimitives);
}

bool BVH::VerifyNodes(BVHNode* node, Int& numNodes,
  Int& maxDepth, Int depth, Int& nextPrimOffset)
{
  ++numNodes;
  if (node->count == 0)
  {
    ++depth;
    if (maxDepth < depth)
    {
      maxDepth = depth;
    }
    bool a = VerifyNodes(node + 1, numNodes, maxDepth, depth, nextPrimOffset);
    bool b = VerifyNodes(root_ + node->first_right, numNodes, maxDepth, depth, nextPrimOffset);
    return a && b;
  }
  else
  {
    if (nextPrimOffset != node->first_right)
    {
      return false;
    }
    nextPrimOffset += node->count;
    return true;
  }
}
