#pragma once
#include "Typedefs.h"
#include <vector>

class AABB;
class Triangle;
struct Ray;
struct Intersection;
struct BVHNode;
struct BVHPrimInfo;

/**
* BVH
* Bounding Volume Hierarchy
*
* A ray intersection acceleration structure. It speeds up ray intersections
* over a set of triangles of size n from O(n) to O(log n) by making a tree
* structure of axis aligned bounding boxes around the scene.
*/

class BVH
{
public:
	BVH(std::vector<Triangle>& prims); // normal constructor
  BVH(const BVH& rhs); // copy constructor
  BVH(BVH&& rhs) noexcept; // move constructor
	~BVH();

	// intersection tests
	bool Intersect(Ray& ray, Intersection& hit) const;
	bool IntersectShadow(Ray& ray) const;
	int32 IntersectDepth(Ray& ray, int32 depth);

  // get the AABB around the BVH 
  const AABB& GetAABB();

private:
	// helper functions
	size_t RecursiveBuild(std::vector<BVHPrimInfo>& triInfo,
		size_t* totNodes, int32 start, int32 end, BVHNode* nodePool,
		std::vector<Triangle>& orderedTriangles);

	int32 IntersectNodeDepth(const BVHNode* node, Ray& ray,	int32 curDepth) const;

	// debug functions
	bool VerifyBVH(Int& numPrimitives, Int& numNodes, Int& maxDepth);
	bool VerifyNodes(BVHNode* node, Int& numNodes,
    Int& maxDepth, Int depth, Int& nextPrimOffset);

private:
	// the nodes
  BVHNode* root_;
	size_t node_count_;

  // a reference to the mesh's triangles
	std::vector<Triangle>& triangles_;

  // BVH building constants
	static constexpr uint32 kPrimsNeededForSAH = 4;
  static constexpr int32 kTotBuckets = 12;
};

