#pragma once
#include "SceneTraversal/AABB.h"

/**
* BVHNode
*
* A node in the BVH. Holds the AABB encompassing it,
* the number of objects it holds (count), the axis that
* it's children are divided on (split_axis) and an index
* to either the first primitive (if it's a leaf node) or
* to it's left child (the right one is next to it)
*
* It is a very specific size (32 bytes when
* FLOAT_IS_DOUBLE is not defined, 64 bytes otherwise) to ensure
* proper memory alignment
*
*/
struct BVHNode
{
public:
  BVHNode()
    :
    aabb(),
    count(0),
    first_right(0)
  {}

  bool Intersect(const Ray& ray) const
  {
    return aabb.Intersect(ray);
  }

public:
  union
  {
    struct
    {
      Vec3 min;
      HalfInt count;
      HalfInt split_axis;
      Vec3 max;
      Int first_right;
    };

    AABB aabb;
  };
};


/**
* BVHPrimInfo
*
* A struct that holds simple information that is used when building the BVH
*/
struct BVHPrimInfo
{
  BVHPrimInfo()
    :
    idx(-1),
    centre(INFINITY, INFINITY, INFINITY),
    aabb()
  {}

  BVHPrimInfo(Int index, const AABB& aabb)
    :
    idx(index),
    aabb(aabb),
    centre(aabb.min * kHalfF + aabb.max * kHalfF)
  {}

public:
  AABB aabb;
  Vec3 centre;
  Int idx;
};