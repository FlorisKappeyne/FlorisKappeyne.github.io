#include "AABB.h"
#include "Ray.h"


///////////////////////////////////////////////////////////////////////////////
// change volume functions

AABB AABB::Union(const Vec3& p) const
{
  AABB res;
  res.min = Vec3(
    Min(min.x, p.x - kEpsilon),
    Min(min.y, p.y - kEpsilon),
    Min(min.z, p.z - kEpsilon));
  res.max = Vec3(
    Max(max.x, p.x + kEpsilon),
    Max(max.y, p.y + kEpsilon),
    Max(max.z, p.z + kEpsilon));
  return res;
}

AABB AABB::Union(const AABB& rhs) const
{
  AABB res;
  res.min = Vec3(Min(
    min.x, rhs.min.x),
    Min(min.y, rhs.min.y),
    Min(min.z, rhs.min.z));

  res.max = Vec3(
    Max(max.x, rhs.max.x),
    Max(max.y, rhs.max.y),
    Max(max.z, rhs.max.z));
  return res;
}

void AABB::Expand(Float delta)
{
  Vec3 expander = Vec3(delta, delta, delta);
  min -= expander;
  max += expander;
}


///////////////////////////////////////////////////////////////////////////////
// intersection function
bool AABB::Intersect(const Ray& ray) const
{
#define INTERSECTION_TECHNIQUE 1

#if INTERSECTION_TECHNIQUE == 1
  /// technique 1: simd compute, no branching
  QF t1 = mm_mul(mm_sub(min4, ray.o4), ray.rd4);
  QF t2 = mm_mul(mm_sub(max4, ray.o4), ray.rd4);
  QF vmax4 = mm_max(t1, t2), vmin4 = mm_min(t1, t2);
  Float* vmax = (Float*)&vmax4, *vmin = (Float*)&vmin4;
  Float tmax = Min(vmax[0], Min(vmax[1], vmax[2]));
  Float tmin = Max(vmin[0], Max(vmin[1], vmin[2]));
  return tmax >= tmin && tmax >= 0;

#elif INTERSECTION_TECHNIQUE == 2
  const AABB& aabb = *this;
  /// technique 2: less brenching, more compute
  /// to enable this, add a * operator to Vec3 that multiplies lhs.x with rhs.x etcetera
  Vec3 minPoint = aabb.min;
  Vec3 maxPoint = aabb.max;
  Vec3 minV = (minPoint - ray.o) * invDir;
  Vec3 maxV = (maxPoint - ray.o) * invDir;
  //Generates new direction, so we have to recaclutate min and max point
  Float tmin = Max(Max(Min(minV.x, maxV.x), Min(minV.y, maxV.y)), Min(minV.z, maxV.z));
  Float tmax = Min(Min(Max(minV.x, maxV.x), Max(minV.y, maxV.y)), Max(minV.z, maxV.z));
  return (tmax >= tmin);

#elif INTERSECTION_TECHNIQUE == 3
  const AABB& aabb = *this;
  /// technique 3: more branching, less compute
  // find x and y t max and min
  Float tMin = (aabb[ray.dir_is_neg[0]].x - ray.o.x) * ray.rd.x;
  Float tMax = (aabb[1 - ray.dir_is_neg[0]].x - ray.o.x) * ray.rd.x;
  Float tyMin = (aabb[ray.dir_is_neg[1]].y - ray.o.y) * ray.rd.y;
  Float tyMax = (aabb[1 - ray.dir_is_neg[1]].y - ray.o.y) * ray.rd.y;

  // check if inside the box
  if ((tMin > tyMax) || (tyMin > tMax))
  {
    return false;
  }
  // find the extremes
  if (tyMin > tMin)
  {
    tMin = tyMin;
  }
  if (tyMax < tMax)
  {
    tMax = tyMax;
  }

  // repeat for z axis
  Float tzMin = (aabb[ray.dir_is_neg[2]].z - ray.o.z) * ray.rd.z;
  Float tzMax = (aabb[1 - ray.dir_is_neg[2]].z - ray.o.z) * ray.rd.z;

  if ((tMin > tzMax) || (tzMin > tMax))
  {
    return false;
  }
  if (tzMin > tMin)
  {
    tMin = tzMin;
  }
  if (tzMax < tMax)
  {
    tMax = tzMax;
  }

  // return true if the ray intersects
  if (tMin > ray.t)
  {
    return false;
  }
  if (tMin > 0)
  {
    return true;
  }

  // if tMin is smaller then zero, we need to check if we're in the AABB: 
  //    if not, the box is behind us 

  return Inside(ray.o);
#endif
}
