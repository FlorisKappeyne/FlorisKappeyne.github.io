#include "Loading/Factory.h"
#include "SceneTraversal/Scene.h"
#include "SceneTraversal/Transform.h"
#include "SceneTraversal/Primitives/Mesh.h"
#include "SceneTraversal/Primitives/Triangle.h"
#include "Utilities/Serialization/Serialization.h"

// materials
#include "Shading/Materials/MatteMaterial.h"
#include "Shading/Materials/MirrorMaterial.h"
#include "Shading/Materials/TransparentMaterial.h"


///////////////////////////////////////////////////////////////////////////////
// function to load and instantiate a scene

void LoadSceneFromJsonFile(const std::string& file_path, Scene& scene)
{
  Serializer ser("scene");
  if (ser.Deserialize("Data/Scenes/" + file_path) == false)
  {
    assert(false && "file loading failed in the factory");
    return;
  }
  
  // load the material libraries
  int num_mat_libs = 0;
  ser.Get("number of matlibs", num_mat_libs);
  ser.StepIn("matlibs");
  for (int i = 0; i < num_mat_libs; ++i)
  {
    std::string matlib;
    ser.Get("matlib" + std::to_string(i), matlib);

    // load the materials
    LoadMatLib(matlib, scene);
  }
  ser.StepOut();

  // load
  int num_objects;
  ser.Get("number of objects", num_objects);

  if (num_objects > 0)
  {
    // create default material
    // random sequence at the end to avoid duplicate names
    const std::string def_mat_name = "default_mat_tyVYXmHlSS0pdqiOtYrc";
    if (scene.HasMat(def_mat_name) == false)
    {
      // a red light as default material
      IMaterial* def_mat = new MatteMaterial(RGBf(kOneF, kZeroF, kZeroF), 1.0f);
      scene.AddMat(def_mat_name, def_mat);
    }

    ser.StepIn("objects");
    for (int i = 0; i < num_objects; ++i)
    {
      std::string object_name = "object" + std::to_string(i);
      ser.StepIn(object_name);

      ///////////////////////////////////////
      // Transform
      ///////////////////////////////////////
      Vec3 pos, scale, rot;
      ser.Get("scale", scale);
      ser.Get("rotation", rot);
      ser.Get("position", pos);
      Transform tranny = CreateTransform(scale, rot, pos);

      ///////////////////////////////////////
      // Material
      ///////////////////////////////////////
      std::string material_name;
      ser.Get("material", material_name);
      IMaterial* mat;

      if (scene.HasMat(material_name) == true)
      {
        mat = scene.GetMat(material_name);
      }
      else
      {
        mat = scene.GetMat(def_mat_name);
      }

      ///////////////////////////////////////
      // Object
      ///////////////////////////////////////
      int object_type;
      ser.Get("object type", object_type);

      switch (object_type)
      {
      case 0: // mesh
      {
        // not implemented yet, but I might in the future
      }
      break;
      case 1: // sphere
      {
        float r = 0.0f;
        ser.Get("radius", r);
        CreateSphere(scene, tranny, mat, r);
      }
      break;
      case 2: // disk
      {
        float ir = 0.0f, or = 0.0f;
        ser.Get("inner radius", ir);
        ser.Get("outer radius", or );
        if (ir == kZeroF)
        {
          CreateDisk(scene, tranny, mat, or);
        }
        else
        {
          CreateHalo(scene, tranny, mat, ir, or);
        }
      }
      break;
      case 3: // teapot
      {
        CreateUtahTeapot(scene, tranny, mat);
      }
      break;
      case 4: // bunny
      {
        CreateStanfordBunny(scene, tranny, mat);
      }
      break;
      case 5: // cube
      {
        float w = 0.0f, h = 0.0f, d = 0.0f;
        ser.Get("width", w);
        ser.Get("height", h);
        ser.Get("depth", d);
        tranny = tranny * CreateScale(w, h, d);
        CreateCube(scene, tranny, mat);
      }
      break;
      default:
        assert(false && "invalid object type loaded in factory");
        break;
      }
      ser.StepOut();
    }
  }
}


///////////////////////////////////////////////////////////////////////////////
// function to load materials

// a small utility function to remove duplicate code
template <typename T>
void CreateMat(Scene& scene, const std::string& name, RGBf col, Float lum)
{
  if (scene.HasMat(name) == false)
  {
    IMaterial* mat = new T(col, lum);
    scene.AddMat(name, mat);
  }
}

void LoadMatLib(const std::string & file_path, Scene & scene)
{
  Serializer ser("matlib");
  if (ser.Deserialize("Data/Resources/" + file_path) == false)
  {
    assert(false && "file loading failed in the factory - materials");
    return;
  }

  int mat_count;
  ser.Get("number of materials", mat_count);
  ser.StepIn("materials");
  for (int i = 0; i < mat_count; ++i)
  {
    ser.StepIn("mat" + std::to_string(i));
    int type;
    std::string name;
    RGBf col;
    Float lum;
    ser.Get("type", type);
    ser.Get("name", name);
    ser.Get("color", col);
    ser.Get("luminosity", lum);
    switch (type)
    {
    case 0:
      CreateMat<MatteMaterial>(scene, name, col, lum);
      break;
    case 1:
      CreateMat<MirrorMaterial>(scene, name, col, lum);
      break;
    case 2:
      float ior;
      Vec3 coef;
      ser.Get("beer coefficients", coef);
      ser.Get("ior", ior);
      if (scene.HasMat(name) == false)
      {
        IMaterial* mat = new TransparentMaterial(col, lum, ior, coef);
        scene.AddMat(name, mat);
      }
      break;
    }
    ser.StepOut();
  }
  ser.StepOut();
}


///////////////////////////////////////////////////////////////////////////////
// Create functions that generate geometry and add an instance to the scene

Model* CreateCube(Scene& scene, const Transform& tranny, IMaterial* mat)
{
  const std::string name = "cube";
  if (scene.HasMesh(name) == false)
  {
    // generate vertices
    std::vector<Triangle::Vertex> vertices;
    std::vector<uint32> indices;

    Triangle::Vertex vertex;

    // face 1
    vertex.p = Vec3(-kOneF, -kOneF, kOneF);
    vertex.uv = Vec2(kZeroF, kZeroF);
    vertex.n = Vec3(kZeroF, kZeroF, kOneF);
    vertices.push_back(vertex);

    vertex.p = Vec3(kOneF, -kOneF, kOneF);
    vertex.uv = Vec2(kOneF, kZeroF);
    vertex.n = Vec3(kZeroF, kZeroF, kOneF);
    vertices.push_back(vertex);

    vertex.p = Vec3(kOneF, kOneF, kOneF);
    vertex.uv = Vec2(kOneF, kOneF);
    vertex.n = Vec3(kZeroF, kZeroF, kOneF);
    vertices.push_back(vertex);

    vertex.p = Vec3(-kOneF, kOneF, kOneF);
    vertex.uv = Vec2(kZeroF, kOneF);
    vertex.n = Vec3(kZeroF, kZeroF, kOneF);
    vertices.push_back(vertex);

    indices.push_back(0);
    indices.push_back(1);
    indices.push_back(2);

    indices.push_back(0);
    indices.push_back(2);
    indices.push_back(3);

    // face 2
    vertex.p = Vec3(-kOneF, -kOneF, -kOneF);
    vertex.uv = Vec2(kZeroF, kZeroF);
    vertex.n = Vec3(kZeroF, kZeroF, -kOneF);
    vertices.push_back(vertex);

    vertex.p = Vec3(kOneF, -kOneF, -kOneF);
    vertex.uv = Vec2(kOneF, kZeroF);
    vertex.n = Vec3(kZeroF, kZeroF, -kOneF);
    vertices.push_back(vertex);

    vertex.p = Vec3(kOneF, kOneF, -kOneF);
    vertex.uv = Vec2(kOneF, kOneF);
    vertex.n = Vec3(kZeroF, kZeroF, -kOneF);
    vertices.push_back(vertex);

    vertex.p = Vec3(-kOneF, kOneF, -kOneF);
    vertex.uv = Vec2(kZeroF, kOneF);
    vertex.n = Vec3(kZeroF, kZeroF, -kOneF);
    vertices.push_back(vertex);

    indices.push_back(6);
    indices.push_back(5);
    indices.push_back(4);

    indices.push_back(7);
    indices.push_back(6);
    indices.push_back(4);

    // face 3
    vertex.p = Vec3(-kOneF, kOneF, -kOneF);
    vertex.uv = Vec2(kZeroF, kZeroF);
    vertex.n = Vec3(kZeroF, kOneF, kZeroF);
    vertices.push_back(vertex);

    vertex.p = Vec3(kOneF, kOneF, -kOneF);
    vertex.uv = Vec2(kOneF, kZeroF);
    vertex.n = Vec3(kZeroF, kOneF, kZeroF);
    vertices.push_back(vertex);

    vertex.p = Vec3(kOneF, kOneF, kOneF);
    vertex.uv = Vec2(kOneF, kOneF);
    vertex.n = Vec3(kZeroF, kOneF, kZeroF);
    vertices.push_back(vertex);

    vertex.p = Vec3(-kOneF, kOneF, kOneF);
    vertex.uv = Vec2(kZeroF, kOneF);
    vertex.n = Vec3(kZeroF, kOneF, kZeroF);
    vertices.push_back(vertex);

    indices.push_back(8);
    indices.push_back(9);
    indices.push_back(10);

    indices.push_back(8);
    indices.push_back(10);
    indices.push_back(11);

    // face 4
    vertex.p = Vec3(-kOneF, -kOneF, -kOneF);
    vertex.uv = Vec2(kZeroF, kZeroF);
    vertex.n = Vec3(kZeroF, -kOneF, kZeroF);
    vertices.push_back(vertex);

    vertex.p = Vec3(kOneF, -kOneF, -kOneF);
    vertex.uv = Vec2(kOneF, kZeroF);
    vertex.n = Vec3(kZeroF, -kOneF, kZeroF);
    vertices.push_back(vertex);

    vertex.p = Vec3(kOneF, -kOneF, kOneF);
    vertex.uv = Vec2(kOneF, kOneF);
    vertex.n = Vec3(kZeroF, -kOneF, kZeroF);
    vertices.push_back(vertex);

    vertex.p = Vec3(-kOneF, -kOneF, kOneF);
    vertex.uv = Vec2(kZeroF, kOneF);
    vertex.n = Vec3(kZeroF, -kOneF, kZeroF);
    vertices.push_back(vertex);

    indices.push_back(14);
    indices.push_back(13);
    indices.push_back(12);

    indices.push_back(15);
    indices.push_back(14);
    indices.push_back(12);

    // face 5
    vertex.p = Vec3(kOneF, -kOneF, -kOneF);
    vertex.uv = Vec2(kZeroF, kZeroF);
    vertex.n = Vec3(kOneF, kZeroF, kZeroF);
    vertices.push_back(vertex);

    vertex.p = Vec3(kOneF, kOneF, -kOneF);
    vertex.uv = Vec2(kOneF, kZeroF);
    vertex.n = Vec3(kOneF, kZeroF, kZeroF);
    vertices.push_back(vertex);

    vertex.p = Vec3(kOneF, kOneF, kOneF);
    vertex.uv = Vec2(kOneF, kOneF);
    vertex.n = Vec3(kOneF, kZeroF, kZeroF);
    vertices.push_back(vertex);

    vertex.p = Vec3(kOneF, -kOneF, kOneF);
    vertex.uv = Vec2(kZeroF, kOneF);
    vertex.n = Vec3(kOneF, kZeroF, kZeroF);
    vertices.push_back(vertex);

    indices.push_back(16); // start at 16
    indices.push_back(17);
    indices.push_back(18);

    indices.push_back(19);
    indices.push_back(18);
    indices.push_back(16);

    // face 6
    vertex.p = Vec3(-kOneF, -kOneF, -kOneF);
    vertex.uv = Vec2(kZeroF, kZeroF);
    vertex.n = Vec3(-kOneF, kZeroF, kZeroF);
    vertices.push_back(vertex);

    vertex.p = Vec3(-kOneF, kOneF, -kOneF);
    vertex.uv = Vec2(kOneF, kZeroF);
    vertex.n = Vec3(-kOneF, kZeroF, kZeroF);
    vertices.push_back(vertex);

    vertex.p = Vec3(-kOneF, kOneF, kOneF);
    vertex.uv = Vec2(kOneF, kOneF);
    vertex.n = Vec3(-kOneF, kZeroF, kZeroF);
    vertices.push_back(vertex);

    vertex.p = Vec3(-kOneF, -kOneF, kOneF);
    vertex.uv = Vec2(kZeroF, kOneF);
    vertex.n = Vec3(-kOneF, kZeroF, kZeroF);
    vertices.push_back(vertex);

    indices.push_back(22);
    indices.push_back(21);
    indices.push_back(20);

    indices.push_back(23);
    indices.push_back(22);
    indices.push_back(20);

    // MAKE THIS STEP REDUNDANT PLZZZ

    // use indexes to create triangles_.
    std::vector<Triangle> triangles_;
    const int32 num_triangles = (int32)indices.size() / 3;
    triangles_.reserve(num_triangles);

    for (int32 i = 0; i < num_triangles; ++i)
    {
      triangles_.emplace_back(
        vertices[indices[i * 3 + 0]],
        vertices[indices[i * 3 + 1]],
        vertices[indices[i * 3 + 2]]);
    }

    Mesh* mesh = new Mesh(name, triangles_);
    scene.AddMesh(name, mesh);
  }
  return scene.AddModel(name, tranny, mat);
}

Model* CreateSphere(Scene & scene, const Transform& tranny, IMaterial* mat, Float radius)
{
  const std::string name = "sphere" + std::to_string(radius);
  if (scene.HasMesh(name) == false)
  {
    // number of latitude and longitude division
    const int32 num_lat_div = 36; // latitude is north to south (z is north pole, rotate around x)
    const int32 num_long_div = 72; // longitude is east to west (z is north pole, rotate around z)

    const Float f_num_lat_div = static_cast<Float>(num_lat_div);
    const Float f_num_long_div = static_cast<Float>(num_long_div);

    const Vec3 base = Vec3(kZeroF, kZeroF, radius);
    const Float lat_angle = Float(180.0f) / num_lat_div;
    const Float long_angle = Float(360.0f) / num_long_div;

    // generate vertices
    std::vector<Triangle::Vertex> vertices;
    vertices.reserve((num_lat_div - 1) * num_long_div + 2);
    for (int i_lat = 1; i_lat < num_lat_div; ++i_lat)
    {
      const Vec3 lat_base = CreateRotateX(lat_angle * i_lat).TransformPoint(base);
      for (int32 i_long = 0; i_long < num_long_div; ++i_long)
      {
        Triangle::Vertex v;
        v.p = CreateRotateZ(long_angle * i_long).TransformPoint(lat_base);
        v.n = v.p / radius;
        v.uv = Vec2(
          Float(i_lat) / f_num_lat_div,
          Float(i_long) / f_num_long_div);

        vertices.push_back(v);
      }
    }

    // top and bottom vertices
    Triangle::Vertex north_pole;
    north_pole.p = base;
    north_pole.n = base / radius;
    north_pole.uv = Vec2(kZeroF);
    int32 north_pole_idx = (int32)vertices.size();
    vertices.push_back(north_pole);

    Triangle::Vertex south_pole;
    south_pole.p = -base;
    south_pole.n = -base / radius;
    south_pole.uv = Vec2(kOneF - kEpsilon);
    int32 south_pole_idx = (int32)vertices.size();
    vertices.push_back(south_pole);


    // generate indices
    std::vector<uint32> indices;
    indices.reserve(
      (num_lat_div - 2) * (num_long_div - 1) * 6 +
      (num_lat_div - 2) * 6 +
      (num_long_div - 1) * 6 +
      6);

    const auto CalcIdx = [num_lat_div, num_long_div](int i_lat, int i_long)
    {
      return i_lat * num_long_div + i_long;
    };
    for (int i_lat = 0; i_lat < num_lat_div - 2; ++i_lat)
    {
      for (int i_long = 0; i_long < num_long_div - 1; ++i_long)
      {
        indices.push_back(CalcIdx(i_lat, i_long));
        indices.push_back(CalcIdx(i_lat + 1, i_long));
        indices.push_back(CalcIdx(i_lat, i_long + 1));
        indices.push_back(CalcIdx(i_lat, i_long + 1));
        indices.push_back(CalcIdx(i_lat + 1, i_long));
        indices.push_back(CalcIdx(i_lat + 1, i_long + 1));
      }
      indices.push_back(CalcIdx(i_lat, num_long_div - 1));
      indices.push_back(CalcIdx(i_lat + 1, num_long_div - 1));
      indices.push_back(CalcIdx(i_lat, 0));
      indices.push_back(CalcIdx(i_lat, 0));
      indices.push_back(CalcIdx(i_lat + 1, num_long_div - 1));
      indices.push_back(CalcIdx(i_lat + 1, 0));
    }

    // top indices
    for (int i_long = 0; i_long < num_long_div - 1; ++i_long)
    {
      // top
      indices.push_back(north_pole_idx);
      indices.push_back(CalcIdx(0, i_long));
      indices.push_back(CalcIdx(0, i_long + 1));
    }
    indices.push_back(north_pole_idx);
    indices.push_back(CalcIdx(0, num_long_div - 1));
    indices.push_back(CalcIdx(0, 0));

    // bottom indices
    for (int i_long = 0; i_long < num_long_div - 1; ++i_long)
    {
      // bottom
      indices.push_back(CalcIdx(num_lat_div - 2, i_long + 1));
      indices.push_back(CalcIdx(num_lat_div - 2, i_long));
      indices.push_back(south_pole_idx);
    }
    indices.push_back(CalcIdx(num_lat_div - 2, 0));
    indices.push_back(CalcIdx(num_lat_div - 2, num_long_div - 1));
    indices.push_back(south_pole_idx);

    // TODO: Test to see if storing indices instead of all vertices is more efficient

    // use indexes to create triangles_.
    std::vector<Triangle> triangles_;
    const int32 num_triangles = (int32)indices.size() / 3;
    triangles_.reserve(num_triangles);

    for (int32 i = 0; i < num_triangles; ++i)
    {
      triangles_.emplace_back(
        vertices[indices[i * 3 + 0]],
        vertices[indices[i * 3 + 1]],
        vertices[indices[i * 3 + 2]]);
    }

    Mesh* mesh = new Mesh(name, triangles_);
    scene.AddMesh(name, mesh);
  }
  return scene.AddModel(name, tranny, mat);
}

Model* CreateDisk(Scene & scene, const Transform& tranny, IMaterial* mat, Float radius)
{
  // create the name
  const std::string name = "disk_" + std::to_string(radius);

  if (scene.HasMesh(name) == false)
  {
    const int32 num_div = 72;

    const Float f_num_div = static_cast<Float>(num_div);

    const Vec3 base = Vec3(radius, kZeroF, kZeroF);
    const Vec3 centre = Vec3(kZeroF);
    const Vec3 normal = Vec3(kZeroF, kZeroF, kOneF);
    const Float angle = Float(360.0f) / f_num_div;

    // generate vertices
    std::vector<Triangle::Vertex> vertices;
    vertices.reserve(num_div + 1);

    // centre
    Triangle::Vertex middle;
    middle.p = centre;
    middle.n = normal;
    middle.uv = Vec2(kHalfF, kHalfF);
    vertices.push_back(middle);

    // the outer vertices
    for (int32 i = 0; i < num_div; ++i)
    {
      Triangle::Vertex v;
      v.p = CreateRotateZ(angle * i).TransformPoint(base);
      v.n = normal;
      v.uv = Vec2(
        (v.p.x + kOneF) / kTwoF,
        (v.p.y + kOneF) / kTwoF);

      vertices.push_back(v);
    }

    // generate indices
    std::vector<uint32> indices;
    indices.reserve(num_div * 3);

    for (int32 i = 1; i < num_div; ++i)
    {
      indices.push_back(0);
      indices.push_back(i);
      indices.push_back(i + 1);
    }
    indices.push_back(0);
    indices.push_back(num_div);
    indices.push_back(1);
    
    // MAKE THIS STEP REDUNDANT PLZZZ

    // use indexes to create triangles_.
    std::vector<Triangle> triangles_;
    const int32 num_triangles = (int32)indices.size() / 3;
    triangles_.reserve(num_triangles);

    for (int32 i = 0; i < num_triangles; ++i)
    {
      triangles_.emplace_back(
        vertices[indices[i * 3 + 0]],
        vertices[indices[i * 3 + 1]],
        vertices[indices[i * 3 + 2]]);
    }

    Mesh* mesh = new Mesh(name, triangles_);
    scene.AddMesh(name, mesh);
  }
  return scene.AddModel(name, tranny, mat);
}

Model* CreateHalo(Scene & scene, const Transform& tranny, IMaterial* mat,
  Float inner_radius, Float outer_radius)
{
  // create the name
  const std::string name = "disk_" + 
    std::to_string(inner_radius) + "_" +
    std::to_string(outer_radius);

  if (scene.HasMesh(name) == false)
  {
    const int32 num_div = 72;

    const Float f_num_div = static_cast<Float>(num_div);

    const Vec3 base = Vec3(outer_radius, kZeroF, kZeroF);
    const Vec3 normal = Vec3(kZeroF, kZeroF, kOneF);
    const Float angle = Float(360.0f) / f_num_div;
    Float in_out_ratio = inner_radius / outer_radius;

    // generate vertices
    std::vector<Triangle::Vertex> vertices;
    vertices.reserve(num_div * 2);

    for (int32 i = 0; i < num_div; ++i)
    {
      Triangle::Vertex v_out;
      v_out.p = CreateRotateZ(angle * i).TransformPoint(base);
      v_out.n = normal;
      v_out.uv = Vec2(
        (v_out.p.x + kOneF) / kTwoF,
        (v_out.p.y + kOneF) / kTwoF);

      Triangle::Vertex v_in;
      v_in.p = v_out.p * in_out_ratio;
      v_in.n = normal;
      v_in.uv = Vec2(
        (v_in.p.x + kOneF) / kTwoF,
        (v_in.p.y + kOneF) / kTwoF);

      vertices.push_back(v_out);
      vertices.push_back(v_in);
    }

    // generate indices
    std::vector<uint32> indices;
    indices.reserve(num_div * 3 * 2);

    for (int32 i = 0; i < (num_div - 1) * 2; i += 2)
    {
      indices.push_back(i);
      indices.push_back(i + 2);
      indices.push_back(i + 1);

      indices.push_back(i + 2);
      indices.push_back(i + 3);
      indices.push_back(i + 1);
    }
    int32 num_vertices = (int32)vertices.size();
    indices.push_back(num_vertices - 2);
    indices.push_back(0);
    indices.push_back(num_vertices - 1);

    indices.push_back(0);
    indices.push_back(1);
    indices.push_back(num_vertices - 1);

    // MAKE THIS STEP REDUNDANT PLZZZ

    // use indexes to create triangles_.
    std::vector<Triangle> triangles_;
    const int32 num_triangles = (int32)indices.size() / 3;
    triangles_.reserve(num_triangles);

    for (int32 i = 0; i < num_triangles; ++i)
    {
      triangles_.emplace_back(
        vertices[indices[i * 3 + 0]],
        vertices[indices[i * 3 + 1]],
        vertices[indices[i * 3 + 2]]);
    }

    Mesh* mesh = new Mesh(name, triangles_);
    scene.AddMesh(name, mesh);
  }
  return scene.AddModel(name, tranny, mat);
}
