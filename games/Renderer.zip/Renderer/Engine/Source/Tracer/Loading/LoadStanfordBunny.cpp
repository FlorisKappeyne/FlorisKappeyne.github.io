#include "Loading/Factory.h"
#include "SceneTraversal/Scene.h"
#include "Utilities/Serialization/Serialization.h"

// materials
#include "Shading/Materials/MatteMaterial.h"
#include "Shading/Materials/MirrorMaterial.h"

// scene data
#include "SceneTraversal/Scene.h"
#include "SceneTraversal/Transform.h"
#include "SceneTraversal/Primitives/Mesh.h"
#include "SceneTraversal/Primitives/Triangle.h"

// std
#include <cassert>

// model
#define BUNNY_IMPLEMENTATION
#include "Loading/Models/StanfordBunny.h"
#undef BUNNY_IMPLEMENTATION

///////////////////////////////////////////////////////////////////////////////
// Create function that generates a Stanford bunny and places it in the scene

Model* CreateStanfordBunny(Scene & scene, const Transform& tranny, IMaterial* mat)
{
  const std::string name = "stanford bunny";

  if (scene.HasMesh(name) == false)
  {
    std::vector<Triangle> triangles_;
    triangles_.reserve(BUNNY_NUM_TRIANGLES);

    Vec3 min = Vec3(
      bunny_model_minbounds[0],
      bunny_model_minbounds[1],
      bunny_model_minbounds[2]);

    Vec3 max = Vec3(
      bunny_model_maxbounds[0],
      bunny_model_maxbounds[1],
      bunny_model_maxbounds[2]);

    Vec3 scale = max - min;

    // loop over the faces, create triangles_, add to the scene
    for (int32 i = 0; i < BUNNY_NUM_INDICES; i += 3)
    {
      Triangle::Vertex v[3];
      int32 vIndex = 0;
      for (int32 j = 0; j < 3; ++j, ++vIndex)
      {
        v[vIndex].p = Vec3(
          bunny_vertices[bunny_indices[i + vIndex]][0],
          bunny_vertices[bunny_indices[i + vIndex]][1],
          bunny_vertices[bunny_indices[i + vIndex]][2]);

        v[vIndex].n = Vec3(
          bunny_normals[bunny_indices[i + vIndex]][0],
          bunny_normals[bunny_indices[i + vIndex]][1],
          bunny_normals[bunny_indices[i + vIndex]][2]);

        v[vIndex].uv = Vec2(
          (v[vIndex].p.x - min.x) / scale.x,
          (v[vIndex].p.y - min.y) / scale.y);
      }
      triangles_.push_back(Triangle(v[0], v[1], v[2]));
    }

    Mesh* mesh = new Mesh(name, triangles_);
    scene.AddMesh(name, mesh);
  }
  return scene.AddModel(name, tranny, mat);
}