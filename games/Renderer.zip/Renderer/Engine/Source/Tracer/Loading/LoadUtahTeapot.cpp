#include "Loading/Factory.h"
#include "Utilities/Serialization/Serialization.h"

// materials
#include "Shading/Materials/MatteMaterial.h"
#include "Shading/Materials/MirrorMaterial.h"

// scene data
#include "SceneTraversal/Scene.h"
#include "SceneTraversal/Transform.h"
#include "SceneTraversal/Primitives/Mesh.h"
#include "SceneTraversal/Primitives/Triangle.h"

// std
#include <cassert>

// model
#define _WIN32_WCE
#include "Loading/Models/UtahTeapot.h"
#undef _WIN32_WCE

///////////////////////////////////////////////////////////////////////////////
// Create function that generates a Utah teapot and places it in the scene

Model* CreateUtahTeapot(Scene& scene, const Transform& tranny, IMaterial* mat)
{
  const std::string name = "utah teapot";

  if (scene.HasMesh(name) == false)
  {
    std::vector<Triangle> triangles_;
    triangles_.reserve(numFaces * 3);

    // loop over the faces, create triangles_, add to the scene
    for (int32 i = 0; i < numFaces; ++i)
    {
      Triangle::Vertex v[3];
      int32 vIndex = 0;
      assert(faces[i][0] == 3);
      for (int32 j = 1; j < 4; ++j, ++vIndex)
      {
        v[vIndex].p = Vec3(
          vertices[faces[i][j]][0],
          vertices[faces[i][j]][1],
          vertices[faces[i][j]][2]);

        v[vIndex].n = Vec3(
          normals[faces[i][j + 3]][0],
          normals[faces[i][j + 3]][1],
          normals[faces[i][j + 3]][2]);

        v[vIndex].uv = Vec2((
          vertices[faces[i][j]][0] + Float(4.5)) / Float(9.643),
          vertices[faces[i][j]][1] / Float(4.725));
      }
      triangles_.push_back(Triangle(v[0], v[1], v[2]));
    }

    Mesh* mesh = new Mesh(name, triangles_);
    scene.AddMesh(name, mesh);
  }
  return scene.AddModel(name, tranny, mat);
}
