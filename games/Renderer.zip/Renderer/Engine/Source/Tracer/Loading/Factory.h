#pragma once
#include "Utilities/Math/Vec3.h"
#include <string>

class Scene;
class Model;
class Transform;
class IMaterial;
class RGBf;

/**
* This file contains functions that can be used to create objects into the scene
*
*   LoadSceneFromJsonFile loads an entire scene, but all the other functions
*   return a handle to the created object for further modification if necessary
*/

// load the scene in the json file at the given adres
void LoadSceneFromJsonFile(const std::string& file_path, Scene& scene);

// load the given mat lib into the scene
void LoadMatLib(const std::string& file_path, Scene& scene);

// add a utah teapot mesh to the scene. Implementation in LoadUtahTeapot.cpp
Model* CreateUtahTeapot(Scene& scene, const Transform& tranny, IMaterial* mat);

// add a stanford bunny mesh to the scene. Implementation in LoadStanfordBunny.cpp
Model* CreateStanfordBunny(Scene& scene, const Transform& tranny, IMaterial* mat);

// generate geometry for a cube and place it in the scene
Model* CreateCube(Scene& scene, const Transform& tranny, IMaterial* mat);

// generate geometry for a sphere and place it in the scene.
Model* CreateSphere(Scene& scene, const Transform& tranny, IMaterial* mat, Float radius);

// generate geometry for a disk and place it in the scene
Model* CreateDisk(Scene& scene, const Transform& tranny, IMaterial* mat, Float radius);

// generate geometry for a disk with a hole in the centre (ring, halo) and place it in the scene
Model* CreateHalo(Scene& scene, const Transform& tranny, IMaterial* mat, Float inner_radius, Float outer_radius);
