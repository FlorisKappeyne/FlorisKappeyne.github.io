#pragma once
#include "Samplers/Data/Sample.h"
#include "Misc/RNG.h"


///////////////////////////////////////////////////////////////////////////////
// sampler utitility function to generate a jittered sample

inline Sample GetJitteredSample(uint32 x, uint32 y, Float inv_x, Float inv_y)
{
  Float ndcy = (Float)y * inv_y + rng::Float(kZeroF, inv_y);
  Float ndcx = (Float)x * inv_x + rng::Float(kZeroF, inv_x);
  return Sample(x, y, ndcx, ndcy);
}
