#pragma once
#include "Typedefs.h"


/**
* Matrix
*   Row major implementation of a 4 by 4 matrix.
*/

class Mat44
{
public:
  Mat44()
  {
    m[0][0] = 1.0f;
    m[0][1] = 0.0f;
    m[0][2] = 0.0f;
    m[0][3] = 0.0f;
    m[1][0] = 0.0f;
    m[1][1] = 1.0f;
    m[1][2] = 0.0f;
    m[1][3] = 0.0f;
    m[2][0] = 0.0f;
    m[2][1] = 0.0f;
    m[2][2] = 1.0f;
    m[2][3] = 0.0f;
    m[3][0] = 0.0f;
    m[3][1] = 0.0f;
    m[3][2] = 0.0f;
    m[3][3] = 1.0f;
  }

  Mat44(Float mat[4][4])
  {
    m[0][0] = mat[0][0];
    m[0][1] = mat[0][1];
    m[0][2] = mat[0][2];
    m[0][3] = mat[0][3];
    m[1][0] = mat[1][0];
    m[1][1] = mat[1][1];
    m[1][2] = mat[1][2];
    m[1][3] = mat[1][3];
    m[2][0] = mat[2][0];
    m[2][1] = mat[2][1];
    m[2][2] = mat[2][2];
    m[2][3] = mat[2][3];
    m[3][0] = mat[3][0];
    m[3][1] = mat[3][1];
    m[3][2] = mat[3][2];
    m[3][3] = mat[3][3];
  }

  Mat44(
    Float t00, Float t01, Float t02, Float t03,
    Float t10, Float t11, Float t12, Float t13,
    Float t20, Float t21, Float t22, Float t23,
    Float t30, Float t31, Float t32, Float t33)
  {
    m[0][0] = t00;
    m[0][1] = t01;
    m[0][2] = t02;
    m[0][3] = t03;
    m[1][0] = t10;
    m[1][1] = t11;
    m[1][2] = t12;
    m[1][3] = t13;
    m[2][0] = t20;
    m[2][1] = t21;
    m[2][2] = t22;
    m[2][3] = t23;
    m[3][0] = t30;
    m[3][1] = t31;
    m[3][2] = t32;
    m[3][3] = t33;
  }

  // operators
  const Mat44 operator*(const Mat44& rhs) const
  {
    Mat44 res;
    for (int32 i = 0; i < 4; ++i)
    {
      for (int32 j = 0; j < 4; ++j)
      {
        res.m[i][j] =
          m[i][0] * rhs.m[0][j] +
          m[i][1] * rhs.m[1][j] +
          m[i][2] * rhs.m[2][j] +
          m[i][3] * rhs.m[3][j];
      }
    }
    return res;
  }
  const Mat44& operator*=(const Mat44& rhs)
  {
    Mat44 lhs = *this;
    for (int32 i = 0; i < 4; ++i)
    {
      for (int32 j = 0; j < 4; ++j)
      {
        m[i][j] =
          lhs.m[i][0] * rhs.m[0][j] +
          lhs.m[i][1] * rhs.m[1][j] +
          lhs.m[i][2] * rhs.m[2][j] +
          lhs.m[i][3] * rhs.m[3][j];
      }
    }
    return *this;
  }
  const Float operator[](size_t idx) const
  {
    return (&m[0][0])[idx];
  }

public:
  Float m[4][4];
};

inline Mat44 Transpose(const Mat44& m)
{
  return Mat44(
    m.m[0][0], m.m[1][0], m.m[2][0], m.m[3][0],
    m.m[0][1], m.m[1][1], m.m[2][1], m.m[3][1],
    m.m[0][2], m.m[1][2], m.m[2][2], m.m[3][2],
    m.m[0][3], m.m[1][3], m.m[2][3], m.m[3][3]);
}

inline bool Inverse(const Mat44& m, Mat44* out)
{
  // calculate necessary values for the determinant
  Float
    inv00 =
    m.m[1][1] * m.m[2][2] * m.m[3][3] -
    m.m[1][1] * m.m[2][3] * m.m[3][2] -
    m.m[2][1] * m.m[1][2] * m.m[3][3] +
    m.m[2][1] * m.m[1][3] * m.m[3][2] +
    m.m[3][1] * m.m[1][2] * m.m[2][3] -
    m.m[3][1] * m.m[1][3] * m.m[2][2],

    inv10 =
    -m.m[1][0] * m.m[2][2] * m.m[3][3] +
    m.m[1][0] * m.m[2][3] * m.m[3][2] +
    m.m[2][0] * m.m[1][2] * m.m[3][3] -
    m.m[2][0] * m.m[1][3] * m.m[3][2] -
    m.m[3][0] * m.m[1][2] * m.m[2][3] +
    m.m[3][0] * m.m[1][3] * m.m[2][2],

    inv20 =
    m.m[1][0] * m.m[2][1] * m.m[3][3] -
    m.m[1][0] * m.m[2][3] * m.m[3][1] -
    m.m[2][0] * m.m[1][1] * m.m[3][3] +
    m.m[2][0] * m.m[1][3] * m.m[3][1] +
    m.m[3][0] * m.m[1][1] * m.m[2][3] -
    m.m[3][0] * m.m[1][3] * m.m[2][1],

    inv30 =
    -m.m[1][0] * m.m[2][1] * m.m[3][2] +
    m.m[1][0] * m.m[2][2] * m.m[3][1] +
    m.m[2][0] * m.m[1][1] * m.m[3][2] -
    m.m[2][0] * m.m[1][2] * m.m[3][1] -
    m.m[3][0] * m.m[1][1] * m.m[2][2] +
    m.m[3][0] * m.m[1][2] * m.m[2][1];

  // calculate the determinant
  Float det =
    m.m[0][0] * inv00 +
    m.m[0][1] * inv10 +
    m.m[0][2] * inv20 +
    m.m[0][3] * inv30;

  // return if the determinant is invalid
  if (det == 0)
    return false;

  det = kOneF / det;

  // construct the actual inverse matrix

  out->m[0][0] = inv00 * det;

  out->m[0][1] = (
    -m.m[0][1] * m.m[2][2] * m.m[3][3] +
    m.m[0][1] * m.m[2][3] * m.m[3][2] +
    m.m[2][1] * m.m[0][2] * m.m[3][3] -
    m.m[2][1] * m.m[0][3] * m.m[3][2] -
    m.m[3][1] * m.m[0][2] * m.m[2][3] +
    m.m[3][1] * m.m[0][3] * m.m[2][2]) * det;

  out->m[0][2] = (
    m.m[0][1] * m.m[1][2] * m.m[3][3] -
    m.m[0][1] * m.m[1][3] * m.m[3][2] -
    m.m[1][1] * m.m[0][2] * m.m[3][3] +
    m.m[1][1] * m.m[0][3] * m.m[3][2] +
    m.m[3][1] * m.m[0][2] * m.m[1][3] -
    m.m[3][1] * m.m[0][3] * m.m[1][2]) * det;

  out->m[0][3] = (
    -m.m[0][1] * m.m[1][2] * m.m[2][3] +
    m.m[0][1] * m.m[1][3] * m.m[2][2] +
    m.m[1][1] * m.m[0][2] * m.m[2][3] -
    m.m[1][1] * m.m[0][3] * m.m[2][2] -
    m.m[2][1] * m.m[0][2] * m.m[1][3] +
    m.m[2][1] * m.m[0][3] * m.m[1][2]) * det;

  out->m[1][0] = inv10 * det;

  out->m[1][1] = (
    m.m[0][0] * m.m[2][2] * m.m[3][3] -
    m.m[0][0] * m.m[2][3] * m.m[3][2] -
    m.m[2][0] * m.m[0][2] * m.m[3][3] +
    m.m[2][0] * m.m[0][3] * m.m[3][2] +
    m.m[3][0] * m.m[0][2] * m.m[2][3] -
    m.m[3][0] * m.m[0][3] * m.m[2][2]) * det;

  out->m[1][2] = (
    -m.m[0][0] * m.m[1][2] * m.m[3][3] +
    m.m[0][0] * m.m[1][3] * m.m[3][2] +
    m.m[1][0] * m.m[0][2] * m.m[3][3] -
    m.m[1][0] * m.m[0][3] * m.m[3][2] -
    m.m[3][0] * m.m[0][2] * m.m[1][3] +
    m.m[3][0] * m.m[0][3] * m.m[1][2]) * det;

  out->m[1][3] = (
    m.m[0][0] * m.m[1][2] * m.m[2][3] -
    m.m[0][0] * m.m[1][3] * m.m[2][2] -
    m.m[1][0] * m.m[0][2] * m.m[2][3] +
    m.m[1][0] * m.m[0][3] * m.m[2][2] +
    m.m[2][0] * m.m[0][2] * m.m[1][3] -
    m.m[2][0] * m.m[0][3] * m.m[1][2]) * det;

  out->m[2][0] = inv20 * det;

  out->m[2][1] = (
    -m.m[0][0] * m.m[2][1] * m.m[3][3] +
    m.m[0][0] * m.m[2][3] * m.m[3][1] +
    m.m[2][0] * m.m[0][1] * m.m[3][3] -
    m.m[2][0] * m.m[0][3] * m.m[3][1] -
    m.m[3][0] * m.m[0][1] * m.m[2][3] +
    m.m[3][0] * m.m[0][3] * m.m[2][1]) * det;

  out->m[2][2] = (
    m.m[0][0] * m.m[1][1] * m.m[3][3] -
    m.m[0][0] * m.m[1][3] * m.m[3][1] -
    m.m[1][0] * m.m[0][1] * m.m[3][3] +
    m.m[1][0] * m.m[0][3] * m.m[3][1] +
    m.m[3][0] * m.m[0][1] * m.m[1][3] -
    m.m[3][0] * m.m[0][3] * m.m[1][1]) * det;

  out->m[2][3] = (
    -m.m[0][0] * m.m[1][1] * m.m[2][3] +
    m.m[0][0] * m.m[1][3] * m.m[2][1] +
    m.m[1][0] * m.m[0][1] * m.m[2][3] -
    m.m[1][0] * m.m[0][3] * m.m[2][1] -
    m.m[2][0] * m.m[0][1] * m.m[1][3] +
    m.m[2][0] * m.m[0][3] * m.m[1][1]) * det;

  out->m[3][0] = inv30 * det;

  out->m[3][1] = (
    m.m[0][0] * m.m[2][1] * m.m[3][2] -
    m.m[0][0] * m.m[2][2] * m.m[3][1] -
    m.m[2][0] * m.m[0][1] * m.m[3][2] +
    m.m[2][0] * m.m[0][2] * m.m[3][1] +
    m.m[3][0] * m.m[0][1] * m.m[2][2] -
    m.m[3][0] * m.m[0][2] * m.m[2][1]) * det;

  out->m[3][2] = (
    -m.m[0][0] * m.m[1][1] * m.m[3][2] +
    m.m[0][0] * m.m[1][2] * m.m[3][1] +
    m.m[1][0] * m.m[0][1] * m.m[3][2] -
    m.m[1][0] * m.m[0][2] * m.m[3][1] -
    m.m[3][0] * m.m[0][1] * m.m[1][2] +
    m.m[3][0] * m.m[0][2] * m.m[1][1]) * det;

  out->m[3][3] = (
    m.m[0][0] * m.m[1][1] * m.m[2][2] -
    m.m[0][0] * m.m[1][2] * m.m[2][1] -
    m.m[1][0] * m.m[0][1] * m.m[2][2] +
    m.m[1][0] * m.m[0][2] * m.m[2][1] +
    m.m[2][0] * m.m[0][1] * m.m[1][2] -
    m.m[2][0] * m.m[0][2] * m.m[1][1]) * det;

  return true;
}
