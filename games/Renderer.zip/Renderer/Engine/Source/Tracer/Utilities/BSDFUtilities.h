#pragma once
#include "Shading/rgbf.h"
#include "Utilities/Math/Vec3.h"
#include "Utilities/Math/Vec2.h"


/**
* some functions to calculate values used commonly in
* shading calculations (when evaluating BRDFs, BTDFs or BSDFs)
*/

inline Float CosTheta(const Vec3& w)
{
  return w.z;
}
inline Float Cos2Theta(const Vec3& w)
{
  return w.z * w.z;
}
inline Float AbsCosTheta(const Vec3& w)
{
  return Abs(CosTheta(w));
}
inline Float Sin2Theta(const Vec3& w)
{
  return Max(kZeroF, kOneF - Cos2Theta(w));
}
inline Float SinTheta(const Vec3& w)
{
  return Sqrt(Sin2Theta(w));
}
inline Float TanTheta(const Vec3& w)
{
  return SinTheta(w) / CosTheta(w);
}
inline Float Tan2Theta(const Vec3& w)
{
  return Sin2Theta(w) / Cos2Theta(w);
}
inline Float CosPhi(const Vec3& w)
{
  Float sinTheta = SinTheta(w);
  return (sinTheta == kZeroF) ? kOneF : Clamp(w.x / sinTheta, -kOneF, kOneF);
}
inline Float SinPhi(const Vec3& w)
{
  Float sinTheta = SinTheta(w);
  return (sinTheta == kZeroF) ? kOneF : Clamp(w.y / sinTheta, -kOneF, kOneF);
}
inline Float Cos2Phi(const Vec3& w)
{
  Float cosPhi = CosPhi(w);
  return cosPhi * cosPhi;
}
inline Float Sin2Phi(const Vec3& w)
{
  Float sinPhi = SinPhi(w);
  return sinPhi * sinPhi;
}
inline Float CosDPhi(const Vec3& wa, const Vec3& wb)
{
  return Clamp((wa.x * wb.x + wa.y * wb.y) /
    Sqrt((wa.x * wa.x + wa.y * wa.y) * (wb.x * wb.x + wb.y * wb.y)), -kOneF, kOneF);
}
inline bool SameHemisphere(const Vec3& w, const Vec3& wp)
{
  return w.z * wp.z > kZeroF;
}


/**
* functions to help evaluate material calculations
*/

// Beer's law
static RGBf BeerLambert(const Vec3& absorb_coef, Float depth)
{
  return RGBf(
    Exp(-absorb_coef.x * depth),
    Exp(-absorb_coef.y * depth),
    Exp(-absorb_coef.z * depth));
}

// Fresnel with Conductive materials
static RGBf FrConductor(Float cosThetaI, const RGBf &etai,
  const RGBf &etat, const RGBf &k)
{
  cosThetaI = Clamp<Float>(cosThetaI, -kOneF, kOneF);
  RGBf eta = etat / etai;
  RGBf etak = k / etai;

  Float cosThetaI2 = cosThetaI * cosThetaI;
  Float sinThetaI2 = kOneF - cosThetaI2;
  RGBf eta2 = eta * eta;
  RGBf etak2 = etak * etak;

  RGBf t0 = eta2 - etak2 - sinThetaI2;
  RGBf a2plusb2 = Sqrt(t0 * t0 + eta2 * etak2 * Float(4));
  RGBf t1 = a2plusb2 + cosThetaI2;
  RGBf a = Sqrt((a2plusb2 + t0) * kHalfF);
  RGBf t2 = a * (cosThetaI * kTwoF);
  RGBf Rs = (t1 - t2) / (t1 + t2);

  RGBf t3 = a2plusb2 * cosThetaI2 + sinThetaI2 * sinThetaI2;
  RGBf t4 = t2 * sinThetaI2;
  RGBf Rp = Rs * (t3 - t4) / (t3 + t4);

  return (Rp + Rs) * kHalfF;
}
// Fresnel with Dielectric materials
static Float FrDielectric(Float cos_theta_i, Float eta_i, Float eta_t)
{
  // if we're exiting, swap eta_i and eta_t
  if (cos_theta_i > kZeroF)
  {
    Swap(eta_i, eta_t);
  }

  // compute sin(theta_t) using the trigonometric identity cos^2 = one - sin^2 and Snell's law
  Float sin_theta_i = Sqrt(Max(kZeroF, kOneF - cos_theta_i * cos_theta_i));
  Float sin_theta_t = eta_i / eta_t * sin_theta_i;

  // handle total internal reflection
  if (sin_theta_t >= kOneF)
  {
    return kOneF;
  }

  // compute cos(theta_t) using the trigonometric identity cos^2 = one - sin^2
  Float cos_theta_t = Sqrt(Max(kZeroF, kOneF - sin_theta_t * sin_theta_t));
  cos_theta_i = Abs(cos_theta_i);

  // precalculate coefficients
  Float etci = eta_t * cos_theta_i;
  Float eict = eta_i * cos_theta_t;
  Float etct = eta_t * cos_theta_t;
  Float eici = eta_i * cos_theta_i;

  // calculate parallel reflectance
  Float Rpa = (etci - eict) / (etci + eict);
  // calculate perpendicular reflectance
  Float Rpe = (eici - etct) / (eici + etct);

  // calculate and return total reflectance
  return (Rpa * Rpa + Rpe * Rpe) / kTwoF;
}
// reflects a vector about the given normal 
inline Vec3 Reflect(const Vec3& wi, const Vec3& n)
{
  return wi - kTwoF * Dot(wi, n) * n;
}
// refract the vector using refraction index theta
inline bool Refract(const Vec3& wi, const Vec3& n, Float eta_i, Float eta_t, Vec3* wt)
{
  Vec3 normal = n;
  // compute cos theta t
  Float cos_theta_i = Dot(n, wi);
  if (cos_theta_i < kZeroF)
  {
    cos_theta_i = -cos_theta_i;
  }
  else
  {
    Swap(eta_i, eta_t);
    normal = -normal;
  }
  // Snell's law says sin(theta_i)/sin(theta_t) = eta_i / eta_t
  Float eta = eta_i / eta_t;
  Float sin_2_theta_i = kOneF - cos_theta_i * cos_theta_i;
  Float sin_2_theta_t = eta * eta * sin_2_theta_i;
  if (sin_2_theta_t >= kOneF)
  {
    return false;
  }
  Float cos_theta_t = Sqrt(kOneF - sin_2_theta_t);

  *wt = eta * wi + (eta * cos_theta_i - cos_theta_t) * normal;
  return true;
}

// small define for the index of refraction of air
static constexpr Float kEtaAir = Float(1.000277);