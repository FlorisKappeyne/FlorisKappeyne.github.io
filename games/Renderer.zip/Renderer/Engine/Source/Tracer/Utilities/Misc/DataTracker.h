#pragma once
#include "Utilities/Misc/Timer.h"
#include "Typedefs.h"

class Scene;

/**
* DataTracker
*
*   The DataTracker is a utility class that keeps track of
*   debugging data and prints it to the screen
*/

class DataTracker
{
public:
	DataTracker()
    :
    frame_count(0),
    average_time(kZeroF)
  {
    timer.Reset();
  }

  // update
	void Tick(bool display_tracking, const Scene& scene);

private:
	Timer timer;
	double average_time;
	int64 frame_count;

  static constexpr Float kAverageFactor = 0.8f; 
  static constexpr Float kNewFrameFactor = kOneF - kAverageFactor;
};