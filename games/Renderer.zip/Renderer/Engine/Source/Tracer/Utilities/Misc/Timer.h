#pragma once
#include <cstdint>

/**
* Timer
*
*   a very simple high resolution timer used to measure
*   timings for debug information
*
*   works by measuring processor cycles passed. if the frequency
*   differs over time, the timings will be inaccurate
*/

class Timer
{
public:
	Timer()
  {
    Reset();
  }

  // stopwatch functions
	void Reset();
	double Elapsed();

private:
  // the cycles count 
	int64_t cycle_count_start_;
	double frequency;
};