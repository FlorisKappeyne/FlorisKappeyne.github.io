#include "Log.h"
#include "FW1FontRendering/FW1FontWrapper.h"


// initialize the static log
Logger* Logger::log = nullptr;


///////////////////////////////////////////////////////////////////////////////
// singleton management functions

void Logger::Init(ID3D11Device* device, ID3D11DeviceContext* context)
{

	if (log != nullptr)
	{
		assert(false && "log is already initialized");
		return;
	}
	// allocate the static log
	log = new Logger();
	log->ID3D11_device_context_ = context;
	log->last_y_pos = kLineStartY;

	IFW1Factory *pFW1Factory;
	HRESULT hResult = FW1CreateFactory(FW1_VERSION, &pFW1Factory);

	hResult = pFW1Factory->CreateFontWrapper(device, L"Arial", &log->font_wrapper_);
}

void Logger::Destroy()
{
	delete log;
	log = nullptr;
}


///////////////////////////////////////////////////////////////////////////////
// draw all logs

void Logger::DrawLogs()
{
	// reset data
	log->last_y_pos = kLineStartY;

	// loop through all of the texts
	for (auto& text : log->strings_to_draw_)
	{
		log->font_wrapper_->DrawString(log->ID3D11_device_context_, 
			text.string.c_str(), // String
			static_cast<FLOAT>(text.fontSize),// Font size
			static_cast<FLOAT>(text.pos.x),// X position
			static_cast<FLOAT>(text.pos.y),// Y position
			text.c,// Text color, 0xAaBbGgRr
			0// Flags (for example FW1_RESTORESTATE to keep context states unchanged)
		);
	}

	// clear for the next frame
	log->strings_to_draw_.clear();
}


///////////////////////////////////////////////////////////////////////////////
// print functions

void Logger::PrintString(const std::string& string, RGBf& c)
{
	LogText text;

	// convert the RGBf to an int in their format
	ARGBc col = c.To32Bit();
	int32_t color = col.GetA() << 24 |
		col.GetB() << 16 | col.GetG() << 8 | col.GetR();

	// calculate position
	Vec2 pos = Vec2{ kTextStartPosX, last_y_pos };
	last_y_pos += kLineOffsetY;

	// fill out the data
	text.string = std::wstring(string.begin(), string.end());
	text.fontSize = kLogFontSize;
	text.pos = pos;
	text.c = color;

	// add to the list of texts to draw
	log->strings_to_draw_.push_back(text);
}

void Logger::PrintTwoStrings(const std::string& str1, const std::string& str2, RGBf & c)
{
  LogText str1_text, str2_text;

  // convert the RGBf to an int in their format
  ARGBc col = c.To32Bit();
  int32_t color = col.GetA() << 24 |
    col.GetB() << 16 | col.GetG() << 8 | col.GetR();

  // calculate position
  Vec2 pos = Vec2{ kLineStartY, last_y_pos };
  last_y_pos += kLineOffsetY;

  // fill out the text
  str1_text.string = std::wstring(str1.begin(), str1.end());
  str1_text.fontSize = kLogFontSize;
  str1_text.pos = pos;
  str1_text.c = color;

  // fill out the data
  pos.x = kDataStartPosX;

  // fill out the data
  str2_text.string = std::wstring(str2.begin(), str2.end());
  str2_text.fontSize = kLogFontSize;
  str2_text.pos = pos;
  str2_text.c = color;

  // add to the list of texts to draw
  log->strings_to_draw_.push_back(str1_text);
  log->strings_to_draw_.push_back(str2_text);
}
