#include "Distribution2D.h"
#include "Utilities/MathUtilities.h"


///////////////////////////////////////////////////////////////////////////////
// class function

Distribution2D::Distribution2D(const Float * func, size_t nu, size_t nv)
{
  for (int32 v = 0; v < nv; ++v)
  {
    conditional_v.emplace_back(new Distribution1D(&func[v * nu], nu));
  }
  std::vector<Float> marginal_func(nv);
  for (int32 v = 0; v < nv; ++v)
  {
    marginal_func[v] = conditional_v[v]->GetFuncInt();
  }
  marginal = new Distribution1D(&marginal_func[0], nv);
}


///////////////////////////////////////////////////////////////////////////////
// sample the 2d function

Vec2 Distribution2D::SampleContinuous(const Vec2 & u, Float * pdf) const
{
  Float pdfs[2];
  size_t v;
  Float d1 = marginal->SampleContinuous(u.y, &pdfs[1], &v);
  Float d0 = conditional_v[v]->SampleContinuous(u.x, &pdfs[0], &v);
  *pdf = pdfs[0] * pdfs[1];
  return Vec2(d0, d1);
}


///////////////////////////////////////////////////////////////////////////////
// get the pdf for a given sample p
Float Distribution2D::PDF(const Vec2 &p ) const
{
  size_t iu = Clamp(size_t(p.x * conditional_v[0]->GetCount()),
    (size_t)0, size_t(conditional_v[0]->GetCount() - 1));
  size_t iv = Clamp(size_t(p.y * marginal->GetCount()),
    (size_t)0, size_t(marginal->GetCount() - 1));
  return conditional_v[iv]->GetFuncValue(iu) / (Float)marginal->GetFuncInt();
}
