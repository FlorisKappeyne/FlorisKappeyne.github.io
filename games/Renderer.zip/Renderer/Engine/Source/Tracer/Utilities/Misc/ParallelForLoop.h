#pragma once
#include <functional>
#include "Typedefs.h"

/**
* This file contains my multithreading utilities
*
*   it works by taking a lambda function and running it on threads
*   in batches. The goal is to make it easy to multithread big for loops
*
*   also contains a utility function to get (a guess at) the systemm thread count
*/

// the parallel for loop function.
void ParallelFor(std::function<void(int32)> &func, int32 count, int32 chunkSize);

// sets up the threads that'll keep running in the background
void CreateThreads();
// stop the threads
void ShutDownThreads();

int32 SystemThreadCount();