#include "Parameters.h"
#include "Utilities/Serialization/Serialization.h"


///////////////////////////////////////////////////////////////////////////////
// class functions

Parameters::Parameters()
  :
  scene_name_(DEF_SCENE_NAME),
  output_file_name_(DEF_OUTPUT_FILE_NAME),
  img_width_(DEF_IMG_WIDTH),
  img_height_(DEF_IMG_HEIGHT),
  cam_loc_(DEF_CAM_LOC[0], DEF_CAM_LOC[1], DEF_CAM_LOC[2]),
  cam_rot_(DEF_CAM_ROT[0], DEF_CAM_ROT[1], DEF_CAM_ROT[2]),
  spp_(DEF_SPP),
  quit_when_done_(QUIT_WHEN_DONE),
  show_per_line_(SHOW_PER_LINE),
  debugging_(DEBUGGING)
{
  Serializer ser("params");
  if (ser.Deserialize("Data/parameters.json") == false)
  {
    // we use the default values
    return;
  }

  // handle possible missing values
  std::string scene_name;
  ser.Get("scene_name", scene_name);
  if (scene_name.empty() == false)
  {
    scene_name_ = scene_name;
  }

  std::string output_file_name;
  ser.Get("output_file_name", output_file_name);
  if (output_file_name.empty() == false)
  {
    output_file_name_ = output_file_name;
  }


  size_t img_width = 0;
  ser.Get("img_width", img_width);
  if (img_width > 0)
  {
    img_width_ = (uint32)img_width;
  }

  size_t img_height = 0;
  ser.Get("img_height", img_height);
  if (img_height > 0)
  {
    img_height_ = (uint32)img_height;
  }

  size_t spp = 0;
  ser.Get("spp", spp);
  if (spp > 0)
  {
    spp_ = (uint32)spp;
  }

  // the rest have acceptable defaults
  ser.Get("cam_loc", cam_loc_);
  ser.Get("cam_rot", cam_rot_);
  ser.Get("quit_when_done", quit_when_done_);
  ser.Get("show_per_line", show_per_line_);
  ser.Get("debugging", debugging_);
}
