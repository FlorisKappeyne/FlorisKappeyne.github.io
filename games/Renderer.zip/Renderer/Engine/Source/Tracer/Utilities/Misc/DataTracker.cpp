#include "Utilities/Misc/DataTracker.h"
#include "Utilities/Misc/Log.h"
#include "SceneTraversal/Scene.h"


///////////////////////////////////////////////////////////////////////////////
// update function

void DataTracker::Tick(bool display_tracking, const Scene& scene)
{
	// gather the data
	++frame_count;
	double frame_time = timer.Elapsed();
	average_time = frame_time * kNewFrameFactor + average_time * kAverageFactor;
	timer.Reset();

  int64 ray_count = scene.GetRayCount();
  scene.ResetRayCount();

  if (display_tracking == false)
  {
    return;
  }

	// log the data
	Logger::Get()->PrintString("Start of debug logging: ", RGBf(1.0f, 0.0f, 0.0f));
	Logger::Get()->PrintValue("time this frame in milliseconds: ", (Float)frame_time, RGBf(0.0f, 0.0f, 1.0f));
	Logger::Get()->PrintValue("average frame time: ", (Float)average_time, RGBf(0.0f, 0.0f, 1.0f));
	Logger::Get()->PrintValue("frames passed: ", (int32)frame_count, RGBf(0.0f, 0.0f, 1.0f));
  Logger::Get()->PrintValue("rays this frame: ", (int32)ray_count, RGBf(0.0f, 0.0f, 1.0f));
  Logger::Get()->PrintValue("rays per second: ", (int32)((Float)ray_count / (frame_time / Float(1000))), RGBf(0.0f, 0.0f, 1.0f));
	Logger::Get()->PrintString("End of debug logging", RGBf(1.0f, 0.0f, 0.0f));
}
