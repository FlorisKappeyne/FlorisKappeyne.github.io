#include "Distribution1D.h"
#include "Utilities/MathUtilities.h"

///////////////////////////////////////////////////////////////////////////////
// initialization function

void Distribution1D::Init(const Float * f, size_t n)
{
  func_ = std::vector<Float>(f, f + n); // own copy
  cdf_ = std::vector<Float>(n + 1); // cdf at index in func, last one is 1 for easier code
  count_ = n;

  // compute CDF
  cdf_[0] = 0;
  const Float inv_fn = kOneF / Float(n);
  for (int32 i = 1; i < n + 1; ++i)
  {
    cdf_[i] = cdf_[i - 1] + func_[i - 1] / inv_fn;
  }

  func_int_ = cdf_[n];
  if (func_int_ == kZeroF)
  {
    for (int32 i = 1; i < n + 1; ++i)
    {
      cdf_[i] = static_cast<Float>(i) * inv_fn;
    }
  }
  else
  {
    Float inv_func_int = kOneF / func_int_;
    for (int32 i = 1; i < n + 1; ++i)
    {
      cdf_[i] *= inv_func_int;
    }
  }
}


///////////////////////////////////////////////////////////////////////////////
// sample functions

Float Distribution1D::SampleContinuous(Float u, Float * pdf, size_t* idx) const
{
  // find the CDF segment, and its idx
  *idx = FindInterval(count_, [&](size_t idx)
  {
    return cdf_[idx] <= u; 
  });

  Float du = u - cdf_[*idx];
  Float cdf_offset = cdf_[(*idx) + 1] - cdf_[*idx];
  if (cdf_offset > kZeroF)
  {
    du /= cdf_offset;
  }

  *pdf = func_[*idx] / func_int_;

  return (static_cast<Float>(*idx) + du) / static_cast<Float>(count_);
}

size_t Distribution1D::SampleDiscrete(Float u, Float * pdf, Float * u_remapped) const
{
  // find the CDF segment, and its idx
  size_t offset = FindInterval(count_, [&](size_t idx)
  {
    return cdf_[idx] <= u;
  });

  *pdf = DiscretePDF(offset);
  *u_remapped = (u - cdf_[offset]) / (cdf_[offset + 1] - cdf_[offset]);

  return offset;
}
