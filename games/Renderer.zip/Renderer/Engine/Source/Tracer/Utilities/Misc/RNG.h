#pragma once
#include "Typedefs.h"
#include "Utilities/MathUtilities.h"
#include <thread>


/**
* This file contains functions for generating random numbers
*
*   the functions are thread safe and don't need to be seeded
*   they use the hashed thread ID as a seed
*
*   I use the xor shift algorithm, which is more than enough 
*   for what I need and very efficient
*/

namespace rng
{
  ///////////////////////////////////////////////////////////////////////////////
  // get a random unsigned integer in a specified range

  inline uint32 Uint()
  {
    // get a unique seed per thread
    static thread_local uint32 seed =
      (uint32)std::hash<std::thread::id>()(std::this_thread::get_id());
    seed ^= (seed << 17);
    seed ^= (seed >> 13);
    seed ^= (seed << 5);
    return seed;
  }
  inline uint32 Uint(uint32 max)
  {
    return Uint() % max;

    /* the code below is more correct,
    but I don't need anything that precise

    ::uint32 threshold = (~max + 1u) % max;
    while (true)
    {
    ::uint32 r = Uint();
    if (r >= threshold) return r % max;
    }
    */
  }
  inline uint32 Uint(uint32 min, uint32 max)
  {
    return ::uint32(max - min) + min;
  }

  ///////////////////////////////////////////////////////////////////////////////
  // get a random floating point value in a specified range

  inline ::Float Float()
  {
    return Min(OneMinusEpsilon,
      ::Float(Uint() * ::Float(2.3283064365386963e-10)));
  }
  inline ::Float Float(::Float max)
  {
    return Float() * max;
  }
  inline ::Float Float(::Float min, ::Float max)
  {
    return Float() * (max - min) + min;
  }
}
