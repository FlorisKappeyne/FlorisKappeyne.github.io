#pragma once
#include "Distribution1D.h"
#include "Utilities/Math/Vec2.h"


/**
* Distribution2D
*
*   The same idea as a Distribution1D, but 2 dimensional
*
*   can be used to sample triangles in meshes, where there is
*   a list of meshes and a list of triangles per mesh
*/

class Distribution2D
{
public:
  Distribution2D()
    :
    marginal(nullptr)
  {
  }

  // constructor
  // takes:
  //   an array of floats, into corresponding Distribution1D
  //   the size of that array's dimensions
  Distribution2D(const Float* func, size_t nu, size_t nv);

  // sample the function continuously
  Vec2 SampleContinuous(const Vec2& u, Float* pdf) const;

  // get the pdf that goes with a sample u
  Float PDF(const Vec2& u) const;

private:
  // 2d vector of distributions
  std::vector<Distribution1D*> conditional_v;

  // margin of each distribution, as a distribution
  Distribution1D* marginal;
};