#include "Utilities/Misc/ParallelForLoop.h"
#include "Typedefs.h"
#include "Utilities/MathUtilities.h"
#include <thread>
#include <mutex>

// forward declerations
void WorkerThreadFunc(int32 index);

// the parallelforloop class, holds which loops still need to be executed
class ParallelForLoop
{
public:
  ParallelForLoop(std::function<void(int32)> func, int64 max_idx, int32 chunk_size)
    :
    func(std::move(func)),
    max_idx_(max_idx),
    chunk_size_(chunk_size)
  {}

  bool Finished()
  {
    return next_idx_ >= max_idx_ &&
      active_workers_ == 0;
  }

public:
  // const data
  std::function<void(int32)> func;
  const int64 max_idx_;
  const int32 chunk_size_;

  // dynamic data
  int64 next_idx_ = 0;
  int32 active_workers_ = 0;
  ParallelForLoop* next_ = nullptr;
};

// the threads and wether they should die or not
static std::vector<std::thread> threads;
static bool shutdown_threads = false;

// the index of the current thread running the WorkerThreadFunc()
extern thread_local int32 thread_index = 0;

// the loops you have to go through. Can be a linked list, but is usually all by itself
static ParallelForLoop* work_list = nullptr;

// the mutex you must hold to access the work list
std::mutex work_list_mutex;

// the condition that the threads check to see if there's work
std::condition_variable work_list_condition;

// the big boy, the function that's actually used
void ParallelFor(std::function<void(int32)>& func, int32 count, int32 chunkSize)
{
  // handle input for which no multithreading is necessary
  if (count < chunkSize)
  {
    // do the work on the calling thread
    for (int32 i = 0; i < count; ++i)
    {
      func(i);
    }
    return;
  }

  // open up worker threads if none exist yet
  CreateThreads();

  // create the loop
  ParallelForLoop loop(func, count, chunkSize);
  work_list_mutex.lock();
  loop.next_ = work_list;
  work_list = &loop;
  work_list_mutex.unlock();

  // notify workers of work to be done
  std::unique_lock<std::mutex> lock(work_list_mutex);
  work_list_condition.notify_all();

  // do the actual work (per thread)
  while (loop.Finished() == false)
  {
    // find iteration range
    int64 start_idx = loop.next_idx_;
    int64 end_idx = Min(start_idx + loop.chunk_size_, loop.max_idx_);

    // update the loop
    loop.next_idx_ = end_idx;
    if (loop.next_idx_ == loop.max_idx_)
    {
      work_list = loop.next_;
    }
    loop.active_workers_++;

    // run your own work
    lock.unlock();
    if (loop.func)
    {
      for (int64 i = start_idx; i < end_idx; i++)
      {
        loop.func((int32)i);
      }
    }
    lock.lock();

    // make sure the loop knows you're done
    loop.active_workers_--;
  }
}

void CreateThreads()
{
  if (threads.size() == 0)
  {
    int32 loops = SystemThreadCount();
    for (int32 i = 0; i < loops - 1; ++i)
    {
      // WorkerThreadFunc is the function that runs continuously on all threads
      threads.push_back(std::thread(WorkerThreadFunc, i + 1));
    }
  }
}

void ShutDownThreads()
{
  // tell each thread to shutdown
  std::unique_lock<std::mutex> lock(work_list_mutex);
  shutdown_threads = true;
  work_list_condition.notify_all();
  lock.unlock();

  // detach each thread so they can shutdown on their own
  for (int32 i = 0; i < threads.size(); ++i)
  {
    threads[i].detach();
  }
}

static void WorkerThreadFunc(int32 index)
{
  // set the thread index
  thread_index = index;
  // create a local lock using the workListMutex
  std::unique_lock<std::mutex> lock(work_list_mutex);

  // the while loop this function is in permanently
  while (shutdown_threads == false)
  {
    if (!work_list)
    {
      // sleep untill there is work for me
      work_list_condition.wait(lock);
    }
    else
    {
      // get work from the workList and run my own iterations
      ParallelForLoop& loop = *work_list;

      // find iteration range
      int64 start_idx = loop.next_idx_;
      int64 end_idx = Min(start_idx + loop.chunk_size_, loop.max_idx_);

      // update the loop
      loop.next_idx_ = end_idx;
      if (loop.next_idx_ == loop.max_idx_)
      {
        work_list = loop.next_;
      }
      loop.active_workers_++;

      // run your own work
      lock.unlock();
      if (loop.func)
      {
        for (int64 i = start_idx; i < end_idx; i++)
        {
          loop.func((int32)i);
        }
      }
      lock.lock();

      // make sure the loop knows you're done
      loop.active_workers_--;

      // notify the rest if the loop is finished
      if (loop.Finished())
      {
        work_list_condition.notify_all();
      }
    }
  }
}

// get the number of cpu threads (note - not guaranteed to work) 
int32 SystemThreadCount()
{
  return Max(1u, std::thread::hardware_concurrency());
}

