#pragma once
#include "Typedefs.h"

#include <vector>


/**
* Distribution1D
*   A class that represents a stepwise distribution function
*
*   useful for randomly sampling lights with varying brightness
*   or randomly sampling triangles based on their areas
*/

class Distribution1D
{
public:
  Distribution1D()
    :
    count_(0)
  {
  }
  Distribution1D(const Float* f, size_t n)
  {
    Init(f, n);
  }

  // the function that initializes everything
  void Init(const Float* f, size_t n);

  // continuously samples the distribution.
  // takes: 
  //   a (random) value in [0,1)
  //
  // returns: 
  //   the distribution value, continuously sampled
  //   the pdf of that value
  //   the idx into the array of values
  Float SampleContinuous(Float u, Float* pdf, size_t* idx) const;

  // discretely samples the distribution
  // takes:
  //   a (random) value in [0, 1)
  // returns:
  //   the index in the distribution that relates with u
  //   the pdf of that index
  //   the remapped value of u, to exactly match the index location
  size_t SampleDiscrete(Float u, Float* pdf, Float* u_remapped) const;

  // returns the pdf at the given discrete index
  Float DiscretePDF(size_t idx) const
  {
    return func_[idx] / (func_int_ * count_);
  }

  // simple getters
  size_t GetCount()
  {
    return count_;
  }
  Float GetFuncInt()
  {
    return func_int_;
  }
  Float GetFuncValue(size_t idx)
  {
    return func_[idx];
  }

private:
  // the function
  std::vector<Float> func_, cdf_;

  // integral of the function
  Float func_int_;

  // number of steps in the function
  size_t count_;
};
