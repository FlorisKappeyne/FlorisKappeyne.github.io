#include "utilities/Misc/Timer.h"
#define WIN32_LEAN_AND_MEAN
#include <windows.h>


///////////////////////////////////////////////////////////////////////////////
// stopwatch functions

void Timer::Reset()
{
	LARGE_INTEGER integer;

  // get frequency in milliseconds
	QueryPerformanceFrequency(&integer);
	frequency = double(integer.QuadPart) / 1000.0;

  // query the current cycle count
	QueryPerformanceCounter(&integer);
	cycle_count_start_ = integer.QuadPart;
}

double Timer::Elapsed()
{
	LARGE_INTEGER cycle_count_now;
	QueryPerformanceCounter(&cycle_count_now);
	return double(cycle_count_now.QuadPart - cycle_count_start_) / frequency;
}
