#pragma once
#include "Shading/rgbf.h"
#include "Utilities/Math/Vec2.h"

#include <string>
#include <vector>

class LogText;
struct ID3D11Device;
struct ID3D11DeviceContext;
struct IFW1FontWrapper;


/**
* Logger
*
*   a static instance of this class gathers logs to be printed,
*   and prints them after rendering ends each frame
* 
*   it used the FW1FontWrapper library to render the text
*/


class Logger
{
	struct LogText
	{
		std::wstring string;
		float fontSize;
		Vec2 pos;
		int32_t c;
	};

private:
  friend class Game;
  friend class Graphics;

  // singleton management functions
  static void Init(ID3D11Device* device, ID3D11DeviceContext* context);
  static void Destroy();

  // render all logs
  static void DrawLogs();

public:
  // get the singleton instance
	static Logger* Get()
  {
    assert(log != nullptr && "the log wasn't initialized yet, please call init first");
    return log;
  }

  // print functions
	void PrintString(const std::string& string, RGBf& c = RGBf(1.0f, 1.0f, 1.0f));
  void PrintTwoStrings(const std::string& str1, const std::string& str2,
    RGBf& c = RGBf(1.0f, 1.0f, 1.0f));

  // prints values that can be converted to string to the screen
  template <typename T>
	void PrintValue(const std::string& string, T data, RGBf& c = RGBf(1.0f, 1.0f, 1.0f))
  {
    PrintTwoStrings(string, std::to_string(data), c);
  }

  // print a newline
	void NewLine()
  {
    last_y_pos += kLineOffsetY;
  }

private:
	// lib data
	IFW1FontWrapper* font_wrapper_;
	ID3D11DeviceContext* ID3D11_device_context_;

  // the last line's y position
	Float last_y_pos;

	// list to log
	std::vector<LogText> strings_to_draw_;

	// singleton instance
	static Logger* log;

  // positioning data
  static constexpr Float kLineStartY = 5.0f;
  static constexpr Float kLineOffsetY = 15.0f;
  static constexpr Float kTextStartPosX = 5.0f;
  static constexpr Float kDataStartPosX = 200.0f;
  static constexpr Float kLogFontSize = 12;
};