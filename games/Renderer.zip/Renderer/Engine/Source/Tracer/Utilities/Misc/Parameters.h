#pragma once
#include "Utilities/Math/Vec3.h"
#include "Typedefs.h"
#include <string>


/**
* Parameters
* 
*   The render parameters, stored for easy access
*   The parameters are read from parameters.json, 
*   or filled with default values if it is missing
*   
*   The parameters include:
*     - scene name (json)
*     - output file name (png)
*     - resolution
*     - camera location and rotation
*     - samples per pixel
*/

class Parameters
{
public:
  Parameters();

public:
  // getters
  const std::string& GetSceneName()
  {
    return scene_name_;
  }
  const std::string& GetFileName()
  {
    return output_file_name_;
  }
  uint32 GetImgWidth()
  {
    return img_width_;
  }
  uint32 GetImgHeight()
  {
    return img_height_;
  }
  uint32 GetSPP()
  {
    return spp_;
  }
  const Vec3& GetCamLoc()
  {
    return cam_loc_;
  }
  const Vec3& GetCamRot()
  {
    return cam_rot_;
  }
  bool GetQuitWhenDone()
  {
    return quit_when_done_;
  }
  bool GetShowPerLine()
  {
    return show_per_line_;
  }
  bool GetDebugging()
  {
    return debugging_;
  }

private:
  // image param values
  std::string scene_name_;
  std::string output_file_name_;
  uint32 img_width_;
  uint32 img_height_;
  uint32 spp_;
  Vec3 cam_loc_;
  Vec3 cam_rot_;

  // render execution param values
  bool quit_when_done_;
  bool show_per_line_;
  bool debugging_;

private:
  // Default values image params
  static constexpr char* DEF_SCENE_NAME = "Data/Scenes/bunny_scene.json";
  static constexpr char* DEF_OUTPUT_FILE_NAME = "output";
  static constexpr uint32 DEF_IMG_WIDTH = 800;
  static constexpr uint32 DEF_IMG_HEIGHT = 600;
  static constexpr uint32 DEF_SPP = 16;
  static constexpr Float DEF_CAM_LOC[3] = { 0.0f, 0.0f, 0.0f };
  static constexpr Float DEF_CAM_ROT[3] = { 0.0f, 0.0f, 0.0f };

  // default values render execution
  static constexpr bool QUIT_WHEN_DONE = false;
  static constexpr bool SHOW_PER_LINE = true;
  static constexpr bool DEBUGGING = false;
};