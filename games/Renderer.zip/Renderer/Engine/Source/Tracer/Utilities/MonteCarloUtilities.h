#pragma once
#include "Math/Vec3.h"
#include "Math/Vec2.h"
#include "Utilities/MathUtilities.h"
#include "Utilities/Misc/RNG.h"


/**
* This file contains functions used to randomly sample points
* on objects
*
* These samples are used in monte carlo integration
*/

// disk
inline Vec2 UniformSampleDisk(const Vec2& u)
{
  Float r = Sqrt(u.x);
  Float theta = kTwoPi * u.y;
  return Vec2(r * Cos(theta), r * Sin(theta));
}
inline Vec2 ConcentricSampleDisk(const Vec2& u)
{
  Vec2 u_remapped = kTwoF * u - Vec2(kOneF);
  if (u_remapped.x == kZeroF && u_remapped.y == kZeroF)
  {
    return Vec2(kZeroF);
  }
  Float theta, r;
  if (Abs(u_remapped.x) > Abs(u_remapped.y))
  {
    r = u_remapped.x;
    theta = kFourOverPi * (u_remapped.y / u_remapped.x);
  }
  else
  {
    r = u_remapped.y;
    theta = kTwoOverPi - kFourOverPi * (u_remapped.x / u_remapped.y);
  }
  return r * Vec2(Cos(theta), Sin(theta));
}
inline Vec2 RejectionSampleDisk()
{
  Vec2 res;
  do
  {
    res.x = kOneF - kTwoF * rng::Float();
    res.y = kOneF - kTwoF * rng::Float();
  } while (res.x * res.x + res.y * res.y > kOneF);
  return res;
}
inline Float UniformDiskPDF()
{
  return kInvPi;
}

// hemisphere
inline Vec3 UniformSampleHemisphere(const Vec2& u)
{
  Float z = u.x;
  Float sin_theta = Sqrt(Max(kZeroF, kOneF - z * z));
  Float phi = kTwoPi * u.y;
  return Vec3(sin_theta * Cos(phi), sin_theta * Sin(phi), z);
}
inline Vec3 CosineSampleHemisphere(const Vec2& u)
{
  Vec2 d = ConcentricSampleDisk(u);
  Float z = Sqrt(Max(kZeroF, kOneF - d.x * d.x - d.y * d.y));
  return Vec3(d.x, d.y, z);
}
inline Float UniformHemispherePDF()
{
  return kInvTwoPi;
}
inline Float CosineHempispherePDF(Float cos_theta)
{
  return cos_theta * kInvPi;
}

// sphere
inline Vec3 UniformSampleSphere(const Vec2& u)
{
  Float z = kOneF - kTwoF * u.x;
  Float sin_theta = Sqrt(Max(kZeroF, kOneF - z * z));
  Float phi = kTwoPi * u.y;
  return Vec3(sin_theta * Cos(phi), sin_theta * Sin(phi), z);
}
inline Float UniformSpherePDF()
{
  return kInvFourPi;
}

// cone
inline Vec3 UniformSampleCone(const Vec2& u, Float cos_theta_max)
{
  Float cos_theta = (kOneF - u.x) + u.x * cos_theta_max;
  Float sin_theta = Sqrt(kOneF - cos_theta * cos_theta);
  Float phi = u.y * kTwoPi;
  return Vec3(Cos(phi) * sin_theta, Sin(phi) * sin_theta, cos_theta);
}
inline Float UniformConePDF(Float cos_theta_max)
{
  return kOneF / (kTwoPi * (kOneF - cos_theta_max));
}

// triangle
inline Vec2 UniformSampleTriangle(const Vec2& u)
{
  Float su0 = Sqrt(u.x);
  return Vec2(kOneF - su0, u.y * su0);
}
inline Float UniformTrianglePDF(Float area)
{
  return kOneF / area;
}

// Heuristics
inline Float BalanceHeuristic(int32 nf, Float fPDF, int32 ng, Float gPDF)
{
  return (nf * fPDF) / (nf * fPDF + ng * gPDF);
}

inline Float PowerHeuristic(int32 nf, Float fPDF, int32 ng, Float gPDF)
{
  Float f = nf * fPDF, g = ng * gPDF;

  // hardcoded power value of 2, which should be fine
  return (f * f) / (f * f + g * g);
}