#pragma once
#include <string>

/**
* FileWriter
*   a class that can write content to a file
*/

class FileWriter
{
public:
	FileWriter() {};
	FileWriter(const std::string& a_rFileName)
  {
    Open(a_rFileName);
  }
	~FileWriter()
  {
    Close();
  }

  // file writing functions
	const bool Open(const std::string& a_rFileName);
	const bool Close();
	const bool Write(void* a_pBuf, size_t a_size, size_t a_pos);
	const bool Append(void* a_pBuf, size_t a_size);
	const bool OpenEmpty(const std::string& a_rFileName);

private:
	FILE* file_;
	size_t file_size_;
};