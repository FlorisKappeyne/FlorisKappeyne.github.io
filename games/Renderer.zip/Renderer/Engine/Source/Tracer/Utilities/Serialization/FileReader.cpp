#include "Utilities/Serialization/FileReader.h"
#include <fstream>
#include <cassert>


///////////////////////////////////////////////////////////////////////////////
// read file function

FileHandle ReadFile(const std::string& file_name)
{
  FileHandle ret;

  FILE* file = fopen(file_name.c_str(), "rb");
  // confirm the file was opened
  if (file == nullptr)
  {
    assert(false && "could not open the file");
    return ret;
  }

  // get the size of the file
  fseek(file, 0, SEEK_END);
  ret.size_ = ftell(file);

  // return to the beginning of the file
  fseek(file, 0, SEEK_SET);

  // allocate memory for the file
  ret.handle_ = std::shared_ptr<char>(new char[ret.size_],
    std::default_delete<char[]>());

  // copy the file contents into the allocated handle
  fread(ret.handle_.get(), sizeof(char), ret.size_, file);

  // close the file
  fclose(file);

  return ret;
}
