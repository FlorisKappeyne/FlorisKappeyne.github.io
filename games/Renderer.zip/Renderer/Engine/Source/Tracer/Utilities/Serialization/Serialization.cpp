#include "Serialization.h"
#include "FileWriter.h"
#include "FileReader.h"
#include "Shading/rgbf.h"

#include "Utilities/Serialization/Json/json.h"


///////////////////////////////////////////////////////////////////////////////
// class functions

Serializer::Serializer(const std::string& root)
  :
  root_(root)
{
  values_.push(new Json::Value());
  StepIn(root);
}

Serializer::~Serializer()
{
  while (values_.size() > 1)
  {
    values_.pop();
  }
  delete values_.top();
  values_.pop();
}


///////////////////////////////////////////////////////////////////////////////
// file IO

bool Serializer::Serialize(const std::string& file_path)
{
  FileWriter writer;
  if (true != writer.OpenEmpty(file_path))
  {
    return false;
  }

  Json::StyledWriter json_writer;

  // Restore root
  if (values_.empty() == true)
  {
    return false;
  }
  while (values_.size() > 1)
  {
    values_.pop();
  }

  // Open root
  std::string buf = json_writer.write(Root());
  size_t size = buf.size();

  writer.Write((void*)buf.c_str(), size, 0);
  writer.Close();

  // Step back into root
  StepIn(root_.c_str());

  return true;
}

bool Serializer::Deserialize(const std::string& file_path)
{
  FileHandle handle = ReadFile(file_path);

  if (handle.handle_ == nullptr)
  {
    return false;
  }

  Json::Reader Jsonreader;

  // Clear stack
  while (values_.size() > 1)
  {
    values_.pop();
  }

  // Write from root_
  if (Jsonreader.parse(handle.handle_.get(), handle.handle_.get() + handle.size_, Root()) == false)
  {
    return false;
  }

  // Step back into root_
  StepIn(root_.c_str());

  return true;
}


///////////////////////////////////////////////////////////////////////////////
// step functions

void Serializer::StepIn(const std::string& name)
{
  Json::Value* pNewRoot = &(Root())[name];
  values_.push(pNewRoot);
}

void Serializer::StepOut()
{
  // Preserve absolute root_
  if (values_.size() == 1) return;

  values_.pop();
}


///////////////////////////////////////////////////////////////////////////////
// add values

void Serializer::Add(const std::string& name, float value)
{
  Root()[name] = value;
}

void Serializer::Add(const std::string& name, bool value)
{
  Root()[name] = value;
}

void Serializer::Add(const std::string& name, double value)
{
  Root()[name] = value;
}

void Serializer::Add(const std::string& name, int value)
{
  Root()[name] = value;
}

void Serializer::Add(const std::string& name, size_t value)
{
  Root()[name] = value;
}

void Serializer::Add(const std::string& name, const Vec2& value)
{
  StepIn(name);

  Root()["x"] = value.x;
  Root()["y"] = value.y;

  StepOut();
}

void Serializer::Add(const std::string& name, const Vec3& value)
{
  StepIn(name);

  Root()["x"] = value.x;
  Root()["y"] = value.y;
  Root()["z"] = value.z;

  StepOut();
}

void Serializer::Add(const std::string& name, const RGBf & value)
{
  StepIn(name);

  Root()["r"] = value.r;
  Root()["g"] = value.g;
  Root()["b"] = value.b;

  StepOut();
}

void Serializer::Add(const std::string& name, const std::string& value)
{
  Root()[name] = value;
}


///////////////////////////////////////////////////////////////////////////////
// get values

void Serializer::Get(const std::string& name, float& value)
{
  value = Root()[name].asFloat();
}

void Serializer::Get(const std::string& name, bool& value)
{
  value = Root()[name].asBool();
}

void Serializer::Get(const std::string& name, double& value)
{
  value = Root()[name].asDouble();
}

void Serializer::Get(const std::string& name, int& value)
{
  value = Root()[name].asInt();
}

void Serializer::Get(const std::string& name, size_t& value)
{
  value = (size_t)Root()[name].asInt64();
}

void Serializer::Get(const std::string& name, Vec2& value)
{
  StepIn(name);

  value.x = Root()["x"].asFloat();
  value.y = Root()["y"].asFloat();

  StepOut();
}

void Serializer::Get(const std::string& name, Vec3& value)
{
  StepIn(name);

  value.x = Root()["x"].asFloat();
  value.y = Root()["y"].asFloat();
  value.z = Root()["z"].asFloat();

  StepOut();
}

void Serializer::Get(const std::string& name, RGBf & value)
{
  StepIn(name);

  value.r = Root()["r"].asFloat();
  value.g = Root()["g"].asFloat();
  value.b = Root()["b"].asFloat();

  StepOut();
}

void Serializer::Get(const std::string& name, std::string& value)
{
  value = Root()[name].asString();
}
