#pragma once
#include "Utilities/Math/Vec3.h"
#include "Utilities/Math/Vec2.h"
#include <string>
#include <stack>

class RGBf;

namespace Json
{
  class Value;
}

/**
* Serializer
*
*   class for serializing and deserializing json data.
*
*   The user can read the contents of the file using Deserialize(), and
*   then modify and receive this data using the Add() and Get() functions.
*   finally, Serialize() can be called to write the data to a file
*/
class Serializer
{
public:
  Serializer(const std::string& root);
  ~Serializer();

  bool Serialize(const std::string& file_path);
  bool Deserialize(const std::string& file_path);

  void StepIn(const std::string& name);
  void StepOut();

  void Add(const std::string& name, float value);
  void Add(const std::string& name, bool value);
  void Add(const std::string& name, double value);
  void Add(const std::string& name, int value);
  void Add(const std::string& name, size_t value);
  void Add(const std::string& name, const Vec2& value);
  void Add(const std::string& name, const Vec3& value);
  void Add(const std::string& name, const RGBf& value);
  void Add(const std::string& name, const std::string& value);


  // defaults are: string = "", float = 0.0, int = 0, bool = false
  void Get(const std::string& name, float& value);
  void Get(const std::string& name, bool& value);
  void Get(const std::string& name, double& value);
  void Get(const std::string& name, int& value);
  void Get(const std::string& name, size_t& value);
  void Get(const std::string& name, Vec2& value);
  void Get(const std::string& name, Vec3& value);
  void Get(const std::string& name, RGBf& value);
  void Get(const std::string& name, std::string& value);

private:
  inline Json::Value& Root()
  {
    return *values_.top();
  }
  std::stack<Json::Value*> values_;
  std::string root_;
};