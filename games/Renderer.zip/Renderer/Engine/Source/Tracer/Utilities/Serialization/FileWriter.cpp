#include "Utilities/Serialization/FileWriter.h"
#include <cassert>


///////////////////////////////////////////////////////////////////////////////
// file management functions

const bool FileWriter::Open(const std::string& file_name)
{
  file_ = fopen(file_name.c_str(), "ab+");

  if (file_ == nullptr)
  {
    assert(false && "could not open file");
    return false;
  }

  fseek(file_, 0, SEEK_END);
  file_size_ = ftell(file_);
  fseek(file_, 0, SEEK_SET);
  return true;
}

const bool FileWriter::Close()
{
  if (file_)
  {
    fclose(file_);
    file_ = nullptr;
    return true;
  }
  return false;
}

const bool FileWriter::Write(void * buff, size_t size, size_t pos)
{
  if (pos > file_size_)
  {
    assert(false && "tried to write past the end of the file");
    return false;
  }

  fseek(file_, (long)pos, SEEK_SET);
  fwrite(buff, size, 1, file_);
  file_size_ += pos + size - file_size_;
  return true;
}

const bool FileWriter::Append(void * buff, size_t size)
{
  fwrite(buff, size, 1, file_);
  file_size_ += size;
  return true;
}

const bool FileWriter::OpenEmpty(const std::string& file_name)
{
  file_ = fopen(file_name.c_str(), "w");

  if (file_ == nullptr)
  {
    assert(false && "could not open file");
    return false;
  }

  fseek(file_, 0, SEEK_END);
  file_size_ = ftell(file_);
  fseek(file_, 0, SEEK_SET);
  return true;
}
