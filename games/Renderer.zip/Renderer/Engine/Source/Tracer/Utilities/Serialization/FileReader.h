#pragma once
#include <memory>
#include <string>


/**
* FileHandle
*   a struct that contains the contents of a file,
*   after reading it with ReadFile
*/

struct  FileHandle
{
	std::shared_ptr<char> handle_;
	size_t size_;
};

FileHandle ReadFile(const std::string& file_name);