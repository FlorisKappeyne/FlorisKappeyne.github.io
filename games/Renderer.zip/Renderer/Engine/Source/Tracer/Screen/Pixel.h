#pragma once
#include "Shading/rgbf.h"

/**
* Pixel
*
*   represents a pixel in the film
*   it holds a color and a value representing its weight
*/

class Pixel
{
public:
  Pixel(RGBf c = RGBf(), Float filter_weight_sum = 0.0f)
    :
    c_(c),
    weight_(filter_weight_sum)
  {}

  // get functions
  const RGBf& GetColor()
  {
    return c_;
  }
  ARGBc Get32Bit()
  {
    return GetColor().GetClamped().To32Bit();
  }

  // add a sample while keeping the color normalized
  void AddSample(RGBf& color, Float filter_weight)
  {
    Float new_weight = weight_ + filter_weight;
    c_ = c_ * (weight_ / (new_weight)) +
      color * (filter_weight / new_weight);
    weight_ = new_weight;
  }

  // operators to make life a little easier
  Pixel operator+(Pixel& rhs)
  {
    Pixel res = *this;
    res.AddSample(rhs.c_, rhs.weight_);
    return res;
  }
  Pixel operator+(RGBf& rhs)
  {
    Pixel res = *this;
    res.AddSample(rhs, kOneF);
    return res;
  }
  Pixel operator+=(Pixel& rhs)
  {
    AddSample(rhs.c_, rhs.weight_);
    return *this;
  }
  Pixel operator+=(RGBf& rhs)
  {
    AddSample(rhs, kOneF);
    return *this;
  }
  Pixel operator=(RGBf& rhs)
  {
    c_ = rhs;
    weight_ = 1.0f;
    return *this;
  }

private:
  RGBf c_;
  Float weight_;
};