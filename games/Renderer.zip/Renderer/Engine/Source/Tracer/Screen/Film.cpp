#include "Film.h"
#include "Screen.h"
#include "Pixel.h"
#include "Samplers/ISampler.h"
#include "Samplers/Data/Sample.h"
#include "Utilities/MathUtilities.h"
#include "Utilities/Misc/ParallelForLoop.h"
#include "TinyPngOut/TinyPngOut.hpp"

#include <fstream>
#include <iostream>
#include <memory>


///////////////////////////////////////////////////////////////////////////////
// class functions

Film::Film(const Screen& screen)
  :
  scr_(screen)
{
  // buffer of high quality image including weight (4 Floats = 128 bits)
  pixel_buffer_ = new Pixel[scr_.num_pixels];
  // a8r8g8b8 color buffer (32 bits)
  chili_buffer_ = new ARGBc[scr_.num_pixels];

  // set all the buffers to a default value
  Clear();
}

Film::~Film()
{
  delete[] pixel_buffer_;
  delete[] chili_buffer_;
}


///////////////////////////////////////////////////////////////////////////////
// clear function

void Film::Clear()
{
  memset(pixel_buffer_, 0, scr_.num_pixels * sizeof(Pixel));
  memset(chili_buffer_, 0, scr_.num_pixels * sizeof(ARGBc));
}


///////////////////////////////////////////////////////////////////////////////
// add sample functions

void Film::OverwritePixel(const Sample& s, RGBf & c)
{
  // calculate buffer loc
  uint32 loc = s.y * scr_.width + s.x;

  // assign new value
  pixel_buffer_[loc] = c; // overwrite the pixel
}

void Film::AddWeightedPixel(const Sample & s, RGBf & c)
{
  uint32 loc = s.y * scr_.width + s.x;
  pixel_buffer_[loc] += c; // add the color with a weight of 1
}


///////////////////////////////////////////////////////////////////////////////
// get prepared buffer

ARGBc* Film::GetCurFilm()
{
  // convert all pixels multithreaded
  std::function<void(int32)> func = [&](int32 i)
  {
    RGBf tmp = pixel_buffer_[i].GetColor();
    tmp.Limit(kOneF);
    chili_buffer_[i] = tmp.To32Bit();
  };
  ParallelFor(func, scr_.num_pixels, kChunkSize);

  return chili_buffer_;
}


///////////////////////////////////////////////////////////////////////////////
// export the current image

void Film::PrintToImage(const std::string& name)
{
  // prepare the film
  GetCurFilm();
  
  // allocate memory for the pixels
  uint8* colors = new uint8[scr_.num_pixels * 3];

  // convert all pixels multithreaded
  std::function<void(int32)> func = [&](int32 i)
  {
    colors[i * 3    ] = chili_buffer_[i].GetR();
    colors[i * 3 + 1] = chili_buffer_[i].GetG();
    colors[i * 3 + 2] = chili_buffer_[i].GetB();
  };
  ParallelFor(func, scr_.num_pixels, kChunkSize);

  try {
    std::ofstream out(name + ".png", std::ios::binary);
    TinyPngOut pngout(scr_.width, scr_.height, out);
    pngout.write(colors, scr_.num_pixels);
    delete[] colors;

  }
  catch (const char *msg) {
    delete[] colors;
    std::cerr << msg << std::endl;
  }
  
  //// Write image to PPM file. Can be opened with Gimp
  //FILE *f = fopen("image.ppm", "w");          
  //fprintf(f, "P3\n%d %d\n%d\n", scr_.width, scr_.height, 255);
  //for (uint32 i = 0; i < scr_.num_pixels; i++)
  //{
  //  fprintf(f, "%d %d %d ",
  //    chili_buffer_[i].GetR(),
  //    chili_buffer_[i].GetG(),
  //    chili_buffer_[i].GetB());
  //}
  //fclose(f);
}
