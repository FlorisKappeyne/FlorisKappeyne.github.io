#pragma once
#include "Typedefs.h"
#include <vector>

class RGBf;
class ARGBc;
class Pixel;
struct Screen;
struct Sample;

/**
* Film
*
*   the film class holds the color buffers
*   it represents the film in the back of an analog camera
*
*
*   The film handles adding samples to the buffers,
*   and prints to an image at the end of the render
*/

class Film
{
public:
  Film(const Screen& screen);
  ~Film();

public:
  // clear the current buffers
  void Clear();

  // Add a pixel value
  void OverwritePixel(const Sample& s, RGBf& c);
  void AddWeightedPixel(const Sample& s, RGBf& c);
  
  // buffer getters
  ARGBc* GetCurFilm(); // fully prepares the image

  // prints whatever's in the chilibuffer right now to an image
  void PrintToImage(const std::string& name);

private:
  // reference to screen
  const Screen& scr_; 

  // buffers
  Pixel* pixel_buffer_; // the buffer holding the high detail image
  ARGBc* chili_buffer_; // the buffer that holds the colors in chili format

  // the chunksize for multithreading (this many pixels per chunk per thread)
  static constexpr uint32 kChunkSize = 1 << 13;
};