#include "Screen.h"
#include "ScreenTile.h"
#include "utilities/MathUtilities.h"


///////////////////////////////////////////////////////////////////////////////
// class functions

Screen::Screen(uint32 x, uint32 y)
  :
  width(x),
  height(y),
  widthF(Float(x)),
  heightF(Float(y))
{
  // precalculate common variables
  num_pixels = width * height;
  inv_x = kOneF / widthF;
  inv_y = kOneF / heightF;
  aspect = widthF / heightF;
  inv_aspect = heightF / widthF;

  /////////////////////////////////////////////////////////////////////////////
  // Generate screen tiles
  /////////////////////////////////////////////////////////////////////////////
  uint32 num_tile_rows = height / ScreenTile::kTileSize;
  uint32 row_left_over = height % ScreenTile::kTileSize;
  uint32 extra_row = row_left_over > 0;

  uint32 num_tile_columns = width / ScreenTile::kTileSize;
  uint32 col_left_over = width % ScreenTile::kTileSize;
  uint32 extra_col = col_left_over > 0;

  // get total number of tiles (including leftovers)
  grid_height = num_tile_rows + extra_row;
  grid_width = num_tile_columns + extra_col;
  num_tiles = grid_height * grid_width;

  // allocate memory for the tiles
  tiles = new ScreenTile[num_tiles];

  // fill each tile with the information describing it
  uint32 idx = 0;
  for (uint32 row = 0; row < num_tile_rows; ++row)
  {
    for (uint32 col = 0; col < num_tile_columns; ++col, ++idx)
    {
      tiles[idx].height = ScreenTile::kTileSize;
      tiles[idx].width = ScreenTile::kTileSize;
      tiles[idx].grid_x = col;
      tiles[idx].grid_y = row;
    }
    // handle width that's not dividable by kTileSize
    if (extra_col)
    {
      tiles[idx].height = ScreenTile::kTileSize;
      tiles[idx].width = col_left_over;
      tiles[idx].grid_x = num_tile_columns;
      tiles[idx].grid_y = row;
      ++idx;
    }
  }

  // handle height that's not dividable by kTileSize
  if (extra_row)
  {
    for (uint32 col = 0; col < num_tile_columns; ++col, ++idx)
    {
      tiles[idx].height = row_left_over;
      tiles[idx].width = ScreenTile::kTileSize;
      tiles[idx].grid_x = col;
      tiles[idx].grid_y = num_tile_rows;
    }
    // handle width that's not dividable by kTileSize
    if (extra_col)
    {
      tiles[idx].height = row_left_over;
      tiles[idx].width = col_left_over;
      tiles[idx].grid_x = num_tile_columns;
      tiles[idx].grid_y = num_tile_rows;
    }
  }
}

Screen::~Screen()
{
  delete tiles;
}
