#pragma once
#include "Typedefs.h"

struct ScreenTile;

/**
* Screen
*
*   a simple struct that holds the width and the height
*   of the image we are rendering. 
*   it also holds some precalculated values that
*   can be used throughout the renderer
*/

struct Screen
{
  Screen(uint32 x, uint32 y);
  ~Screen();

  uint32 width, height;
  Float widthF, heightF;
  uint32 num_pixels;
  Float inv_x, inv_y;
  Float aspect;
  Float inv_aspect;

  uint32 num_tiles;
  uint32 grid_width;
  uint32 grid_height;
  ScreenTile* tiles;
};