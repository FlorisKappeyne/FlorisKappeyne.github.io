#pragma once
#include "Typedefs.h"


/**
* Screentile
*
*   represents a tile of pixels in a buffer
*/

struct ScreenTile
{
  uint32 width;
  uint32 height;
  uint32 grid_x;
  uint32 grid_y;

  uint32 GetNumPixels() 
  { 
    return width * height;
  }

  static constexpr uint32 kTileSize = 16u; // render in 16 by 16 tiles
};
