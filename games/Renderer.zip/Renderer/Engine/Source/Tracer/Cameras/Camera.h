#pragma once
#include "SceneTraversal/Transform.h"
#include "Utilities/Math/Vec3.h"

class MainWindow;
struct Ray;
struct Sample;
struct Screen;

/*
* Camera
*
*   a class that holds the camera's transform and uses
*     it to transform rays from sample space to world space
*   it also handles movement input for debugging
*/

class Camera
{
public:
  Camera(const Screen& screen);

  // ray generation
  Ray GenerateRay(const Sample& s) const;

  // sets the position and rotation
  void SetPosAndRot(const Vec3& pos, const Vec3& rot);

  // movement functions for debugging
  void HandleInput(const MainWindow& wnd);
  void MoveBy(const Vec3& movement);

private:
  // utility function to hide movement speed
  void Move(const Vec3& movement);

private:
  // ray generations
  Transform c2w_; // camera to world
  const Screen& scr_;
  Vec3 p0_, p1_, p2_; // view plane

  // hardcoded distance from the camera to the view plane
  static constexpr Float kDistance = Float(1.8);

  // movement
  bool moves_fast_;
  static constexpr Float kRotateSpeed = kTwoF;
  static constexpr Float kMoveSpeedSlow = Float(0.01);
  static constexpr Float kMoveSpeedFast = Float(0.05);
};
