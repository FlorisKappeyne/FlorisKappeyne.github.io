#include "Cameras/Camera.h"
#include "MainWindow.h"
#include "Samplers/Data/Sample.h"
#include "Screen/Screen.h"
#include "SceneTraversal/Ray.h"


///////////////////////////////////////////////////////////////////////////////
// class functions

Camera::Camera(const Screen& screen)
  :
  c2w_(),
  scr_(screen),
  p0_(-kOneF, scr_.inv_aspect, -kDistance),
  p1_(kOneF, scr_.inv_aspect, -kDistance),
  p2_(-kOneF, -scr_.inv_aspect, -kDistance)
{
  moves_fast_ = false;
}


///////////////////////////////////////////////////////////////////////////////
// ray generation

Ray Camera::GenerateRay(const Sample& s) const
{
  // calculate the ray (from (0,0,0) to point on viewplane
  Vec3 planepos = p0_ + (p1_ - p0_) * s.ndcX + (p2_ - p0_) * s.ndcY;
  Ray ray = Ray(planepos.Normalized(), Vec3(kZeroF), INFINITY);

  // return transformed ray. Normal doesn't need to be normalized, camera doesn't have scale
  return c2w_.TransformRay(ray);
}


///////////////////////////////////////////////////////////////////////////////
// set position and rotation, ignoring current position

void Camera::SetPosAndRot(const Vec3& pos, const Vec3& rot)
{
  c2w_ =
    CreateTranslate(pos) *
    CreateRotateXYZ(rot);
}


///////////////////////////////////////////////////////////////////////////////
// movement functions for debugging

void Camera::HandleInput(const MainWindow& wnd)
{
#pragma region shift key
  //////////////////////////////////////////////////////////////
  // SPEED INCREASE
  //////////////////////////////////////////////////////////////
  if (wnd.kbd.KeyIsPressed(VK_SHIFT))
  {
    // can check the input bool for speed increase
    moves_fast_ = true;
  }
  else
  {
    moves_fast_;
  }
#pragma endregion Speed increase

#pragma region wasd
  //////////////////////////////////////////////////////////////
  // ROTATE UP
  //////////////////////////////////////////////////////////////
  if (wnd.kbd.KeyIsPressed((char)KeyCode::S))
  {
    c2w_ *= CreateRotateX(kRotateSpeed);
  }

  //////////////////////////////////////////////////////////////
  // ROTATE DOWN
  //////////////////////////////////////////////////////////////
  if (wnd.kbd.KeyIsPressed((char)KeyCode::W))
  {
    c2w_ *= CreateRotateX(-kRotateSpeed);
  }

  //////////////////////////////////////////////////////////////
  // ROTATE LEFT
  //////////////////////////////////////////////////////////////
  if (wnd.kbd.KeyIsPressed((char)KeyCode::A))
  {
    c2w_ *= CreateRotateY(kRotateSpeed);
  }

  //////////////////////////////////////////////////////////////
  // ROTATE RIGHT
  //////////////////////////////////////////////////////////////
  if (wnd.kbd.KeyIsPressed((char)KeyCode::D))
  {
    c2w_ *= CreateRotateY(-kRotateSpeed);
  }
#pragma endregion Rotation

#pragma region arrows f g
  //////////////////////////////////////////////////////////////
  // MOVE FORWARD
  //////////////////////////////////////////////////////////////
  if (wnd.kbd.KeyIsPressed(VK_UP))
  {
    Move(Vec3(0.0f, 0.0f, -1.0f));
  }

  //////////////////////////////////////////////////////////////
  // MOVE BACKWARD
  //////////////////////////////////////////////////////////////
  if (wnd.kbd.KeyIsPressed(VK_DOWN))
  {
    Move(Vec3(0.0f, 0.0f, 1.0f));
  }

  //////////////////////////////////////////////////////////////
  // MOVE RIGHT
  //////////////////////////////////////////////////////////////
  if (wnd.kbd.KeyIsPressed(VK_RIGHT))
  {
    Move(Vec3(1.0f, 0.0f, 0.0f));
  }

  //////////////////////////////////////////////////////////////
  // MOVE LEFT
  //////////////////////////////////////////////////////////////
  if (wnd.kbd.KeyIsPressed(VK_LEFT))
  {
    Move(Vec3(-1.0f, 0.0f, 0.0f));
  }

  //////////////////////////////////////////////////////////////
  // MOVE UP
  //////////////////////////////////////////////////////////////
  if (wnd.kbd.KeyIsPressed((uint32)KeyCode::R))
  {
    Move(Vec3(0.0f, 1.0f, 0.0f));
  }

  //////////////////////////////////////////////////////////////
  // MOVE DOWN
  //////////////////////////////////////////////////////////////
  if (wnd.kbd.KeyIsPressed((uint32)KeyCode::F))
  {
    Move(Vec3(0.0f, -1.0f, 0.0f));
  }
#pragma endregion Translation
}

void Camera::MoveBy(const Vec3 & movement)
{
  c2w_ *= CreateTranslate(movement);
}

void Camera::Move(const Vec3& movement)
{
  Vec3 t;
  if (moves_fast_)
  {
    t = movement * kMoveSpeedFast;
  }
  else
  {
    t = movement * kMoveSpeedSlow;
  }
  c2w_ *= CreateTranslate(t);
}
