/******************************************************************************************
 *	Chili DirectX Framework Version 16.07.50											  *
 *	Game.cpp																			  *
 *	Copyright 5016 PlanetChili.net <http://www.planetchili.net>							  *
 *																						  *
 *	This file is part of The Chili DirectX Framework.									  *
 *																						  *
 *	The Chili DirectX Framework is free software: you can redistribute it and/or modify	  *
 *	it under the terms of the GNU General Public License as published by				  *
 *	the Free Software Foundation, either version 3 of the License, or					  *
 *	(at your option) any later version.													  *
 *																						  *
 *	The Chili DirectX Framework is distributed in the hope that it will be useful,		  *
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of						  *
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the						  *
 *	GNU General Public License for more details.										  *
 *																						  *
 *	You should have received a copy of the GNU General Public License					  *
 *	along with The Chili DirectX Framework.  If not, see <http://www.gnu.org/licenses/>.  *
 ******************************************************************************************/

 // chili
#include "MainWindow.h"
#include "Game.h"

 // render parameters
#include "Utilities/Misc/Parameters.h"

 // factory
#include "Loading/Factory.h"

// materials
#include "Shading/Materials/MatteMaterial.h"
#include "Shading/Materials/MirrorMaterial.h"

// sample buffer
#include "Samplers/Data/SampleBuffer.h"

// utilities
#include "Utilities/Misc/Log.h"
#include "Utilities/Misc/ParallelForLoop.h"

// intersection
#include "SceneTraversal/Intersection.h"


///////////////////////////////////////////////////////////////////////////////
// class functions

Game::Game(MainWindow& wnd, Parameters& params)
  :
  // chili
  wnd(wnd),
  gfx(wnd, params.GetImgWidth(), params.GetImgHeight()),

  // execution flow
  is_done_(false),

  // render parameters
  params_(params),

  // screen rep variables
  screen_(Screen(params.GetImgWidth(), params.GetImgHeight())),
  camera_(screen_),
  film_(screen_),

  // renderers
  renderer_(&path_tracer_),
  path_tracer_(screen_, &film_),
  ray_tracer_(screen_, &film_),
  normals_tracer_(screen_, &film_),
  bvh_depth_tracer_(screen_, &film_),

  // input
  left_mouse_click_(false),
  right_mouse_click_(false),

  // data tracking
  tracker(),
  display_tracking_(true),

  // screen section
  draw_full_frame_(false),
  rendering_section_(false),
  section_start_(0, 0),
  section_cur_(0, 0),

  // samplers
  strat_sampler_(screen_),
  jitt_sampler_(screen_)
{
  // init debugging
  Logger::Init(gfx.pDevice.Get(), gfx.pImmediateContext.Get());
  display_tracking_ = params_.GetDebugging();

  // set up the threads
  CreateThreads();

  // set up input
  memset(input_bools_, 0, sizeof input_bools_);

  // init samplers
  multidepth_sampler_ = &jitt_sampler_;

  // init renderers
  renderers_[ITracer::TracerType::PT] = &path_tracer_;
  renderers_[ITracer::TracerType::RT] = &ray_tracer_;
  renderers_[ITracer::TracerType::DN] = &normals_tracer_;
  renderers_[ITracer::TracerType::DD] = &bvh_depth_tracer_;

  // prepare the scene
  Load();
  SetUp();
}

Game::~Game()
{
  ShutDownThreads();
  Logger::Destroy();
}


///////////////////////////////////////////////////////////////////////////////
// Chili's game loop functions

void Game::Go()
{
  gfx.BeginFrame();
  UpdateModel();
  ComposeFrame();
  gfx.EndFrame();
}

void Game::ComposeFrame()
{
  // let the renderer do its job
  Render();

  // draw the resulting frame to the screen
  Draw();

  // gather data and draw it
  tracker.Tick(display_tracking_, scene_);
}

void Game::UpdateModel()
{
  HandleInput();
}


///////////////////////////////////////////////////////////////////////////////
// initialization functions

void Game::Load()
{
  LoadSceneFromJsonFile(params_.GetSceneName(), scene_);
}

void Game::SetUp()
{
  camera_.SetPosAndRot(params_.GetCamLoc(), params_.GetCamRot());
  scene_.Accelerate();
}


///////////////////////////////////////////////////////////////////////////////
// loop functions

void Game::HandleInput()
{
  // we ignore all input when not debugging
  if (params_.GetDebugging() == false)
  {
    return;
  }

  /*
  * Movement:
  *   WASD -> rotate camera
  *   Arrows -> move camera
  *   R -> move camera up
  *   F -> move camera down

  * Fancy options:
  *   J -> cycle through renderers
  *   I -> toggle drawing full frame or per tile
  *   T -> toggle display tracking
  *   left mouse click + hold + dragging -> only render selected portion
  *   right mouse click -> render full screen_ (resets screen selection rendering)
  */

  // camera input
  camera_.HandleInput(wnd);

  // renderers
  if (wnd.kbd.KeyIsPressed((char)KeyCode::J))
  {
    if (input_bools_[(uint32)KeyCode::J] == false)
    {
      input_bools_[(uint32)KeyCode::J] = true;

      // clear the film
      film_.Clear();

      // get the next renderer
      renderer_ = renderers_[(renderer_->GetType() + 1) % ITracer::TracerType::SUM];
    }
  }
  else
  {
    input_bools_[(uint32)KeyCode::J] = false;
  }

  // toggle per frame or per tile rendering
  if (wnd.kbd.KeyIsPressed((char)KeyCode::I))
  {
    if (input_bools_[(uint32)KeyCode::I] == false)
    {
      input_bools_[(uint32)KeyCode::I] = true;

      draw_full_frame_ = !draw_full_frame_;
    }
  }
  else
  {
    input_bools_[(uint32)KeyCode::I] = false;
  }

  // toggle display tracking
  if (wnd.kbd.KeyIsPressed((char)KeyCode::T))
  {
    if (input_bools_[(uint32)KeyCode::T] == false)
    {
      input_bools_[(uint32)KeyCode::T] = true;

      display_tracking_ = !display_tracking_;
    }
  }
  else
  {
    input_bools_[(uint32)KeyCode::T] = false;
  }

  // screen section selection
  if (wnd.mouse.LeftIsPressed())
  {
    rendering_section_ = true;
    section_cur_ = { wnd.mouse.GetPosX(), wnd.mouse.GetPosY() };
    if (left_mouse_click_ == false)
    {
      left_mouse_click_ = true;
      section_start_ = { wnd.mouse.GetPosX(), wnd.mouse.GetPosY() };
    }
  }
  else
  {
    left_mouse_click_ = false;
  }

  // reset screen section selection
  if (wnd.mouse.RightIsPressed())
  {
    if (right_mouse_click_ == false)
    {
      right_mouse_click_ = true;
      rendering_section_ = false;
    }
  }
  else
  {
    right_mouse_click_ = false;
  }
}

void Game::Render()
{
  // the sample buff to be filled
  SampleBuffer sample_buff;

  // the sampler to use
  ISampler* sampler = renderer_->GetIsSingleDepth() ?
    &strat_sampler_ : multidepth_sampler_;

  if (params_.GetDebugging() == false)
  {
    // get the correct sampling buffer
    if (params_.GetShowPerLine() == false)
    {
      // get the samples
      sample_buff = sampler->GetSamplesScreen(params_.GetSPP());
    }
    else
    {
      // Get the samples
      sample_buff = sampler->GetSamplesLines(1, params_.GetSPP());
    }

  }
  else
  {
    // get the correct sampling buffer
    if (rendering_section_)
    {
      // calculate the section
      Vec2I min, max;
      min.x = section_start_.x < section_cur_.x ? section_start_.x : section_cur_.x;
      min.y = section_start_.y < section_cur_.y ? section_start_.y : section_cur_.y;
      max.x = section_start_.x > section_cur_.x ? section_start_.x : section_cur_.x;
      max.y = section_start_.y > section_cur_.y ? section_start_.y : section_cur_.y;

      // get the samples
      sample_buff = sampler->GetSamplesSection(min, max);
    }
    else if (draw_full_frame_)
    {
      // get the samples
      sample_buff = sampler->GetSamplesScreen(1);
    }
    else
    {
      // Get the samples
      sample_buff = sampler->GetSamplesLines(1);
    }
  }

  // render the calculated samples
  renderer_->RenderSampleBuffer(scene_, camera_, sample_buff);

  // if debugging, move on with your live
  if (params_.GetDebugging() == true)
  {
    return;
  }

  // is the renderer done?
  bool print = params_.GetShowPerLine() ? sampler->FinishedScreen() : true;

  // print the image to a file
  if (print == true)
  {
    film_.PrintToImage(params_.GetFileName());
    if (params_.GetQuitWhenDone() == true)
    {
      is_done_ = true;
    }
  }
}

void Game::Draw()
{
  // get a buffer that can be printed to the screen
  ARGBc* buff = film_.GetCurFilm();

  // draw each pixel
  uint32 offset = 0;
  for (uint32 y = 0; y < screen_.height; ++y)
  {
    for (uint32 x = 0; x < screen_.width; ++x, ++offset)
    {
      gfx.PutPixel(x, y, buff[offset]);
    }
  }

  // draw the tracker background
  if (display_tracking_)
  {
    int32
      height = 130 < params_.GetImgHeight() ? 130 : params_.GetImgHeight(),
      width = 350 < params_.GetImgWidth() ? 350 : params_.GetImgWidth();
    for (int32 y = 0; y < height; ++y)
    {
      for (int32 x = 0; x < width; ++x)
      {
        gfx.PutPixel(x, y, ChiliColors::Gray);
      }
    }
  }

  // draw lines around the rendered section
  if (rendering_section_)
  {
    Vec2I min, max;
    min.x = section_start_.x < section_cur_.x ? section_start_.x : section_cur_.x;
    min.y = section_start_.y < section_cur_.y ? section_start_.y : section_cur_.y;
    max.x = section_start_.x > section_cur_.x ? section_start_.x : section_cur_.x;
    max.y = section_start_.y > section_cur_.y ? section_start_.y : section_cur_.y;

    // draw the horizontal lines
    for (int32 x = min.x; x < max.x; ++x)
    {
      gfx.PutPixel(x, min.y, ChiliColors::Green);
      gfx.PutPixel(x, max.y, ChiliColors::Green);
    }

    // draw the vertical lines
    for (int32 y = min.y; y < max.y; ++y)
    {
      gfx.PutPixel(min.x, y, ChiliColors::Green);
      gfx.PutPixel(max.x, y, ChiliColors::Green);
    }
  }
}
